# Item modifiers, loot tables and number providers

An item modifier (`data/<ns>/item_modifier/<name>.json`) is one loot function object or a list of them. The same functions appear in loot table entries and pools. Apply modifiers with `item modify`, use loot tables with `loot` or as mob/chest/block drops. Fields: `pw schema loot_function <name>`.

## Loot functions (1.21.8)

| Function | Does |
|---|---|
| `set_components` | merge components (`"!minecraft:x":{}` removes) |
| `set_name` | `name`, `target` = `custom_name` (default) or `item_name`, optional `entity` for resolving selectors/scores |
| `set_lore` | `lore` list, `mode` = `replace_all`/`replace_section`/`insert`/`append` (+ `offset`, `size`) |
| `set_count` | `count` (number provider), `add` |
| `set_damage` | `damage` 0..1 fraction of durability remaining, `add` |
| `set_custom_data` | merge `tag` (SNBT string or object) into `custom_data` |
| `copy_custom_data` | copy from `source` (`context` entity/block or `storage`) with `ops` (`replace`, `append`, `merge`) |
| `copy_components` | copy components from a block entity |
| `copy_name` | `source:"this"/"killer"/"block_entity"...` |
| `set_attributes` | add attribute modifiers (`modifiers` with `attribute`, `id`, `amount`, `operation`, `slot`) |
| `set_enchantments` | `enchantments:{"minecraft:sharpness":3}`, `add` |
| `enchant_randomly`, `enchant_with_levels` | random enchanting (`options`, `levels`) |
| `set_custom_model_data` | `floats/flags/strings/colors` each `{values:[..],mode:..}` |
| `toggle_tooltips` | show/hide tooltip parts per component |
| `set_item` | change the item type, keeping components |
| `filtered` | apply `modifier` only if `item_filter` matches |
| `modify_contents` | apply a modifier to every item inside `container`/`bundle_contents`/`charged_projectiles` |
| `sequence`, `reference` | group functions / call another item modifier |
| `limit_count`, `explosion_decay`, `furnace_smelt`, `apply_bonus`, `enchanted_count_increase`, `set_potion`, `set_stew_effect`, `set_instrument`, `set_fireworks`, `set_firework_explosion`, `set_banner_pattern`, `set_book_cover`, `set_written_book_pages`, `set_writable_book_pages`, `set_loot_table`, `set_ominous_bottle_amplifier`, `exploration_map`, `fill_player_head`, `copy_state` | specialised |

Every function accepts `conditions` (loot conditions, see `datapack/predicates.md`).

## Item modifier examples

```json item_modifier
[{"function":"minecraft:set_name","target":"item_name","name":{"text":"Storm Blade +1","color":"aqua"}},{"function":"minecraft:set_lore","mode":"replace_all","lore":[{"text":"Upgraded","color":"green","italic":false}]},{"function":"minecraft:set_components","components":{"minecraft:enchantment_glint_override":true}}]
```

```json item_modifier
{"function":"minecraft:filtered","item_filter":{"items":"#minecraft:swords"},"modifier":{"function":"minecraft:set_enchantments","enchantments":{"minecraft:sharpness":1},"add":true}}
```

A counter stored on the held item, driven by a score:

```json item_modifier
{"function":"minecraft:copy_custom_data","source":{"type":"minecraft:storage","source":"pw:tmp"},"ops":[{"source":"kills","target":"pw.kills","op":"replace"}]}
```

```mcfunction
execute store result storage pw:tmp kills int 1 run scoreboard players get @s pw.kills
item modify entity @s weapon.mainhand pw:copy_kills
```

Dynamic lore that shows a score (resolved for the `entity`):

```json item_modifier
{"function":"minecraft:set_lore","entity":"this","mode":"replace_all","lore":[[{"text":"Kills: ","color":"gray","italic":false},{"score":{"name":"@s","objective":"pw.kills"},"color":"gold","italic":false}]]}
```

`entity:"this"` resolves `@s` to the entity running `item modify`, so run it `as` the player.

## Loot tables

`data/<ns>/loot_table/<path>.json`. Mob drops are replaced by overriding `minecraft:entities/<mob>`, block drops by `minecraft:blocks/<block>`, chests by `minecraft:chests/<name>`. A custom mob can use `DeathLootTable:"pw:boss/drops"` in its NBT.

```json loot_table
{"type":"minecraft:entity","pools":[{"rolls":1,"entries":[{"type":"minecraft:item","name":"minecraft:nether_star","functions":[{"function":"minecraft:set_components","components":{"minecraft:custom_data":{"pw":{"id":"boss_core"}},"minecraft:item_name":{"text":"Boss Core","color":"light_purple"}}}]}]},{"rolls":{"type":"minecraft:uniform","min":2,"max":4},"entries":[{"type":"minecraft:item","name":"minecraft:diamond","weight":3},{"type":"minecraft:item","name":"minecraft:emerald","weight":1,"functions":[{"function":"minecraft:set_count","count":{"type":"minecraft:uniform","min":1,"max":5}}]}]},{"rolls":1,"conditions":[{"condition":"minecraft:random_chance_with_enchanted_bonus","enchantment":"minecraft:looting","unenchanted_chance":0.1,"enchanted_chance":{"type":"minecraft:linear","base":0.15,"per_level_above_first":0.05}}],"entries":[{"type":"minecraft:loot_table","value":"pw:rare/relics"}]}]}
```

Entry types: `item`, `tag` (`expand`), `loot_table` (`value` id or inline table), `dynamic`, `empty`, `alternatives`, `group`, `sequence`. Entries have `weight`, `quality`, `conditions`, `functions`.

Loot table `type` (`entity`, `block`, `chest`, `fishing`, `gift`, `archaeology`, `vault`, `equipment`, `command`, `generic`...) controls which context (`this`, `killer`, `tool`, `origin`) is available.

## Number providers

`3`, `{"type":"minecraft:uniform","min":1,"max":3}`, `{"type":"minecraft:binomial","n":5,"p":0.3}`, `{"type":"minecraft:constant","value":2}`, `{"type":"minecraft:score","target":"this","score":"pw.level","scale":0.5}`, `{"type":"minecraft:storage","storage":"pw:cfg","path":"bonus"}`, `{"type":"minecraft:enchantment_level","amount":{...}}`.

`score` and `storage` providers let loot depend on game state: drop count scaled by a player's level, damage from config storage, etc.
