# Custom items: identity, input detection and hooks

## Identify your item

Put an id in `custom_data` and test it with item predicates. Never identify items by name.

```mcfunction
give @s minecraft:carrot_on_a_stick[custom_data={pw:{id:"storm_blade"}},item_model="minecraft:diamond_sword",item_name={text:"Storm Blade",color:"aqua"},unbreakable={},tooltip_display={hidden_components:["minecraft:unbreakable"]}]
execute if items entity @s weapon.mainhand *[custom_data~{pw:{id:"storm_blade"}}] run say holding the blade
execute if items entity @s weapon.offhand *[custom_data~{pw:{id:"storm_blade"}}] run say in offhand
```

Predicate file form (reusable in selectors with `predicate=`):

```json predicate
{"condition":"minecraft:entity_properties","entity":"this","predicate":{"equipment":{"mainhand":{"predicates":{"minecraft:custom_data":{"pw":{"id":"storm_blade"}}}}}}}
```

## Input detection methods

| Input | Method | Notes |
|---|---|---|
| Right click (any item look) | base item `carrot_on_a_stick` or `warped_fungus_on_a_stick` + objective `minecraft.used:minecraft.carrot_on_a_stick` | fires once per click, also in air; reset the score each tick; restyle with `item_model` |
| Right click, hold, release (charge) | `consumable` with long `consume_seconds` + advancement trigger `using_item` | trigger fires every tick while held; detect release when it stops |
| Right click finishes (cast time) | `consumable` with `consume_seconds` + trigger `consume_item` | the item is consumed unless `use_remainder` gives it back |
| Attack an entity | trigger `player_hurt_entity`, or enchantment `post_attack` with `run_function` | enchantment gives both attacker and victim context |
| Kill | trigger `player_killed_entity`, stat `minecraft.custom:minecraft.mob_kills` | |
| Sneak | `minecraft.custom:minecraft.sneak_time` (increases while sneaking) or predicate `flags.is_sneaking` | combine with right click for alternate skills |
| Jump | `minecraft.custom:minecraft.jump` | |
| Drop (Q) | `minecraft.dropped:minecraft.<item>` + find the item entity and give it back | lets Q be a skill key |
| Swap hands (F) | item appears in `weapon.offhand`: move it back with `item replace` and run the skill | |
| Hotbar scroll | compare `SelectedItemSlot` (player NBT read) with a stored score | read NBT sparingly |
| Hit a block | enchantment `hit_block` effect, or `minecraft.mined:` stats | |
| Shoot a projectile | enchantment `projectile_spawned`, trigger `shot_crossbow`, stat `minecraft.used:minecraft.bow` | |
| Look at / near something | raycast (`patterns/raycast.md`) or `execute if entity @e[distance=..]` | |
| Interact with a custom "button" | `interaction` entity + trigger `player_interacted_with_entity` or `on target` | see entities/display-interaction-marker.md |
| Every tick while wearing/holding | enchantment `tick` effect with `run_function` | runs as the wearer |

## Pattern: carrot on a stick right click

```mcfunction
scoreboard objectives add pw.click minecraft.used:minecraft.carrot_on_a_stick
execute as @a[scores={pw.click=1..}] at @s if items entity @s weapon.mainhand *[custom_data~{pw:{id:"storm_blade"}}] run function pw:blade/use
scoreboard players reset @a[scores={pw.click=1..}] pw.click
```

The first line belongs in the load function, the other two in the tick function. Sneak + click can branch: `execute if predicate pw:sneaking run function pw:blade/alt`.

## Pattern: using_item (charge and release)

Item: `minecraft:stick[consumable={consume_seconds:100000,animation:"bow",has_consume_particles:false},custom_data={pw:{id:"charge_staff"}},max_stack_size=1]`

```json advancement
{"criteria":{"using":{"trigger":"minecraft:using_item","conditions":{"item":{"predicates":{"minecraft:custom_data":{"pw":{"id":"charge_staff"}}}}}}},"rewards":{"function":"pw:staff/using"}}
```

`pw:staff/using` (runs as the player every tick while held):

```mcfunction
advancement revoke @s only pw:staff/using
scoreboard players add @s pw.charge 1
scoreboard players set @s pw.held 2
```

Tick function: count down `pw.held`; when it reaches 0 with a charge, the button was released.

```mcfunction
scoreboard players remove @a[scores={pw.held=1..}] pw.held 1
execute as @a[scores={pw.held=0,pw.charge=1..}] at @s run function pw:staff/release
```

`pw:staff/release` reads `pw.charge` (ticks held), fires, then `scoreboard players set @s pw.charge 0`.

## Pattern: custom enchantment as an event hook

A hidden enchantment can run a function when the holder attacks, every tick, when a projectile is fired or a block is hit. The function runs as the `affected` entity at its position.

```json enchantment
{"description":"Storm","supported_items":"#minecraft:enchantable/weapon","weight":1,"max_level":1,"min_cost":{"base":1,"per_level_above_first":0},"max_cost":{"base":1,"per_level_above_first":0},"anvil_cost":0,"slots":["mainhand"],"effects":{"minecraft:post_attack":[{"enchanted":"attacker","affected":"victim","effect":{"type":"minecraft:run_function","function":"pw:blade/on_hit"}}],"minecraft:tick":[{"effect":{"type":"minecraft:run_function","function":"pw:blade/tick"}}]}}
```

Give it with `enchantments={"pw:storm":1}` plus `tooltip_display={hidden_components:["minecraft:enchantments"]}`. Put custom hook enchantments into no vanilla tags so they never appear on enchanting tables.

Inside `post_attack` with `affected:"victim"`, `@s` is the victim; `execute on attacker` reaches the player. Other built-in entity effects need no function at all: `apply_mob_effect`, `damage_entity`, `explode`, `ignite`, `play_sound`, `spawn_particles`, `summon_entity`, `replace_block`, `replace_disk`, `set_block_properties`, `change_item_damage`, `all_of`.

## Cooldowns and charges on items

- Vanilla overlay: `use_cooldown={seconds:N,cooldown_group:"pw:x"}` only for `consumable`/usable items; it also blocks reuse.
- Score cooldown (any item): set `pw.cd` to N ticks on use, decrement in tick, `return` from the use function while `pw.cd=1..`.
- Charges stored on the item: `item modify entity @s weapon.mainhand` with `set_custom_data`/`copy_custom_data`, read them with `execute store result score @s pw.tmp run data get entity @s SelectedItem.components."minecraft:custom_data".pw.charges`.

## Visuals without a resource pack

`item_model` can point at any vanilla model (`minecraft:blaze_rod`, `minecraft:trident`, `minecraft:mace`). With a resource pack, `item_model="pw:storm_blade"` uses `assets/pw/items/storm_blade.json`, and `custom_model_data` can switch textures by state (floats/flags/strings).
