# Item components (1.21.8)

An item is an id plus components. Components decide name, look, behavior, combat stats, food, equipment, cooldowns and tooltips. Any component can be put on any item; this is how custom items are built without mods.

- Syntax in commands: `id[name=value,...]` (SNBT values). In JSON (loot `set_components`, recipe results, advancement icons): `"components":{"minecraft:name":value}`. To remove a default: `!name` in commands, `"!minecraft:name":{}` in JSON.
- Exact fields: `pw schema component <name>`. Defaults of an item: `pw item <id>`.
- All 96 component types: `pw schema component`.

## Identity and display

| Component | Use |
|---|---|
| `custom_name` | renameable display name (italic unless `italic:false`) |
| `item_name` | base name, not italic, not changed by anvils |
| `lore` | list of text lines (max 256) |
| `rarity` | `common uncommon rare epic` name colour |
| `item_model` | which item model to render (`"minecraft:blaze_rod"` or a resource pack model `pw:wand`) |
| `custom_model_data` | `{floats:[..],flags:[..],strings:[..],colors:[..]}` read by resource pack item model definitions |
| `enchantment_glint_override` | `true` forces glint, `false` hides it |
| `tooltip_display` | `{hide_tooltip:true}` or `{hidden_components:["attribute_modifiers","enchantments",...]}` |
| `tooltip_style` | resource pack tooltip sprite id |
| `custom_data` | arbitrary SNBT for your logic; the game ignores it |
| `dyed_color` | leather colour (int RGB) |
| `profile` | player head skin: `"Name"` or `{name:..,id:[I;..],properties:[..]}` |
| `trim` | armor trim `{material:"minecraft:gold",pattern:"minecraft:spire"}` |

```mcfunction
give @s minecraft:blaze_rod[item_name={text:"Ember Staff",color:"gold"},lore=[{text:"Right click: Fireball",color:"gray",italic:false}],rarity="epic",enchantment_glint_override=true,custom_data={pw:{id:"ember_staff"}},max_stack_size=1]
give @s minecraft:paper[item_model="minecraft:nether_star",custom_model_data={strings:["badge_gold"]},tooltip_display={hidden_components:["minecraft:custom_model_data"]}]
give @s minecraft:leather_chestplate[dyed_color=16711680,trim={material:"minecraft:gold",pattern:"minecraft:spire"},tooltip_display={hidden_components:["minecraft:dyed_color","minecraft:trim"]}]
```

## Stack, durability, repair

| Component | Use |
|---|---|
| `max_stack_size` | 1..99; cannot combine with `max_damage` |
| `max_damage`, `damage` | durability and current damage |
| `unbreakable` | `{}` never loses durability |
| `repairable` | `{items:"#minecraft:diamond_tool_materials"}` anvil repair material |
| `enchantable` | `{value:15}` makes it enchantable at a table with that enchantability |
| `repair_cost` | anvil cost accumulator |
| `damage_resistant` | `{types:"#minecraft:is_fire"}` item entity immune to these damage types |
| `use_remainder` | item left after being used up, e.g. `{id:"minecraft:glass_bottle",count:1}` |

## Use behavior

| Component | Use |
|---|---|
| `consumable` | makes any item usable by holding right click: `consume_seconds`, `animation` (`none eat drink block bow spear crossbow spyglass toot_horn brush bundle`; `spear` is the trident pose in 1.21.8), `sound`, `has_consume_particles`, `on_consume_effects` |
| `food` | `{nutrition:4,saturation:2.4,can_always_eat:true}`; needs `consumable` to be eaten (food items have it by default) |
| `use_cooldown` | `{seconds:3,cooldown_group:"pw:staff"}` shows the vanilla cooldown overlay after a successful use |
| `death_protection` | totem behavior with `death_effects` (consume effects) |
| `glider` | `{}` elytra-style gliding while the item is worn (combine with `equippable`) |
| `jukebox_playable` | music disc |
| `instrument` | goat horn sound |

Consume effects (`on_consume_effects`, `death_effects`): `apply_effects` (`effects`, `probability`), `remove_effects` (`effects`), `clear_all_effects`, `teleport_randomly` (`diameter`), `play_sound` (`sound`).

```mcfunction
give @s minecraft:apple[consumable={consume_seconds:0.8,animation:"eat",on_consume_effects:[{type:"minecraft:apply_effects",effects:[{id:"minecraft:regeneration",amplifier:1,duration:100}]}]},food={nutrition:6,saturation:6,can_always_eat:true},item_name="Healing Apple"]
give @s minecraft:echo_shard[consumable={consume_seconds:1.5,animation:"bow",sound:"minecraft:entity.illusioner.cast_spell",has_consume_particles:false},use_cooldown={seconds:5,cooldown_group:"pw:blink"},custom_data={pw:{spell:"blink"}},max_stack_size=1,use_remainder={id:"minecraft:echo_shard",count:1,components:{"minecraft:custom_data":{pw:{spell:"blink"}},"minecraft:use_cooldown":{seconds:5,cooldown_group:"pw:blink"}}}]
give @s minecraft:totem_of_undying[death_protection={death_effects:[{type:"minecraft:clear_all_effects"},{type:"minecraft:apply_effects",effects:[{id:"minecraft:fire_resistance",duration:400}]}]}]
```

A `consumable` item that finishes being used fires the `consume_item` advancement trigger and is consumed (count -1) unless `use_remainder` returns something. While the use button is held, the `using_item` trigger fires every tick. See `items/custom-items.md`.

## Combat and tools

| Component | Use |
|---|---|
| `attribute_modifiers` | list of `{type,id,amount,operation,slot,display}`; slots `any mainhand offhand hand head chest legs feet armor body saddle` |
| `weapon` | `{item_damage_per_attack:1,disable_blocking_for_seconds:5}` makes it count as a weapon for durability and stats |
| `tool` | `{rules:[{blocks:"#minecraft:mineable/pickaxe",speed:8,correct_for_drops:true}],default_mining_speed:1,damage_per_block:1,can_destroy_blocks_in_creative:false}` |
| `blocks_attacks` | shield behavior: `block_delay_seconds`, `damage_reductions`, `item_damage`, `block_sound`, `disabled_sound`, `bypassed_by` |
| `enchantments` | `{sharpness:5,"minecraft:looting":3}` level 1..255 |
| `stored_enchantments` | enchanted book contents |
| `charged_projectiles`, `intangible_projectile` | crossbow load |
| `potion_contents` | `{potion:"minecraft:strong_healing"}` or `{custom_color:..,custom_effects:[..]}` |
| `potion_duration_scale` | multiplier for potion effect durations |
| `break_sound` | sound when it breaks |

```mcfunction
give @s minecraft:iron_sword[attribute_modifiers=[{type:"minecraft:attack_damage",id:"pw:blade_damage",amount:9,operation:"add_value",slot:"mainhand"},{type:"minecraft:attack_speed",id:"pw:blade_speed",amount:-2.0,operation:"add_value",slot:"mainhand"},{type:"minecraft:movement_speed",id:"pw:blade_move",amount:0.1,operation:"add_multiplied_base",slot:"mainhand"}],weapon={item_damage_per_attack:1}]
give @s minecraft:stick[tool={rules:[{blocks:"#minecraft:mineable/shovel",speed:12,correct_for_drops:true}],damage_per_block:0},max_damage=500]
give @s minecraft:netherite_ingot[blocks_attacks={block_delay_seconds:0.1,damage_reductions:[{base:0,factor:0.6}]},equippable={slot:"offhand"}]
```

Attribute modifier rules: `id` must be unique per item and should be namespaced. The player base attack damage is 1 and base attack speed 4, so a weapon showing "10 damage, 1.6 speed" uses `amount:9` and `amount:-2.4`. The tooltip of `attribute_modifiers` can be changed per modifier with `display:{type:"hidden"}` or `{type:"override",value:<text>}` (1.21.6).

## Equipment

`equippable`: `slot` (`head chest legs feet body mainhand offhand saddle`), `asset_id` (resource pack equipment model), `equip_sound`, `camera_overlay` (texture, like pumpkin blur), `allowed_entities`, `dispensable`, `swappable`, `damage_on_hurt`, `equip_on_interact`, `can_be_sheared` (1.21.6).

```mcfunction
give @s minecraft:diamond[equippable={slot:"head",equip_sound:"minecraft:item.armor.equip_diamond"},attribute_modifiers=[{type:"minecraft:max_health",id:"pw:crown_hp",amount:10,operation:"add_value",slot:"head"}],item_name="Crown"]
give @s minecraft:phantom_membrane[equippable={slot:"chest"},glider={}]
```

## Containers and placed data

| Component | Use |
|---|---|
| `container` | `[{slot:0,item:{id:"minecraft:apple",count:3}}]` contents of shulker boxes, chests (as items) |
| `bundle_contents` | bundle items |
| `container_loot` | `{loot_table:"pw:chest"}` loot rolled when placed and opened |
| `block_entity_data` | NBT merged into the placed block entity (`id` required) |
| `block_state` | `{facing:"north"}` placed block states |
| `entity_data` | spawn egg / armor stand / item frame / painting entity NBT (`id` required) |
| `bucket_entity_data` | fish in buckets |
| `lock` | item predicate a container requires as key |
| `can_place_on`, `can_break` | adventure mode block predicates |
| `writable_book_content`, `written_book_content` | books |
| `map_*`, `lodestone_tracker`, `firework_explosion`, `fireworks`, `banner_patterns`, `base_color`, `pot_decorations`, `bees`, `note_block_sound`, `recipes`, `debug_stick_state`, `ominous_bottle_amplifier`, `suspicious_stew_effects` | special items |
| `<mob>/variant`, `<mob>/color`, `wolf/collar`, `salmon/size` ... | variant of the mob a spawn egg or bucket creates (1.21.5) |

```mcfunction
give @s minecraft:zombie_spawn_egg[entity_data={id:"minecraft:zombie",Tags:["pw.minion"],equipment:{head:{id:"minecraft:golden_helmet",count:1}}},item_name="Minion Egg"]
give @s minecraft:chest[container_loot={loot_table:"minecraft:chests/simple_dungeon"},item_name="Mystery Chest"]
give @s minecraft:written_book[written_book_content={title:"Guide",author:"Server",pages:[{raw:"Welcome!"},{raw:{text:"Page 2",color:"blue"}}]}]
give @s minecraft:diamond_pickaxe[can_break={blocks:"#minecraft:mineable/pickaxe"},can_place_on={blocks:"minecraft:stone"}]
```

## Recipes of combination

- Custom right-click weapon: `item_model` + `custom_data` (id) + `consumable` (`animation:"none"`, huge `consume_seconds`) or a `carrot_on_a_stick` base + `use_cooldown` + `tooltip_display`.
- Custom armor piece with stats: `equippable` + `attribute_modifiers` with the armor slot + `enchantable`/`repairable`.
- Food with effects: `food` + `consumable.on_consume_effects`.
- Unstackable unique items: `max_stack_size=1` or distinct `custom_data`.
- Items that cannot be lost to fire/lava: `damage_resistant`.
