# Math with scores and the world

All scoreboard math is 32-bit integer. Use fixed point (x1000) for decimals, and keep constants on fake players (`#2 pw.const`).

## Basics

```mcfunction
scoreboard players operation #a pw.tmp > #0 pw.const
scoreboard players operation #a pw.tmp < #100 pw.const
execute if score #a pw.tmp matches ..-1 run scoreboard players operation #a pw.tmp *= #-1 pw.const
scoreboard players operation #r pw.tmp = #a pw.tmp
scoreboard players operation #r pw.tmp %= #10 pw.const
execute store result score #roll pw.tmp run random value 0..99
```

- clamp: `> #min` then `< #max`; abs: multiply negatives by -1; percent: `*= #100` then `/= #max`.
- Rounding a fixed-point value to the nearest integer: add half the scale, then divide.
- Overflow wraps around silently; keep intermediate products below about 2.1e9.

## Reading positions and rotations

```mcfunction
execute store result score @s pw.x run data get entity @s Pos[0] 100
execute store result score @s pw.y run data get entity @s Pos[1] 100
execute store result score @s pw.z run data get entity @s Pos[2] 100
execute store result score @s pw.yaw run data get entity @s Rotation[0] 10
```

Writing back (non-players): `execute store result entity @s Pos[1] double 0.01 run scoreboard players get @s pw.y`.

## Distance between two entities

Squared distance avoids square roots: `(dx*dx + dy*dy + dz*dz)` with positions in units of 1/100 block, compare with `range*range*10000`. For simple checks prefer selectors: `execute at A if entity B[distance=..8]`.

## Square root (integer Newton iteration)

`pw:math/sqrt` with input `#in pw.math` (0 or more), output `#out pw.math` = the root rounded down:

```mcfunction
execute if score #in pw.math matches ..1 run return run scoreboard players operation #out pw.math = #in pw.math
scoreboard players operation #out pw.math = #in pw.math
scoreboard players operation #out pw.math /= #2 pw.const
scoreboard players add #out pw.math 1
function pw:math/sqrt_iter
```

`pw:math/sqrt_iter` takes one Newton step, `next = (out + in / out) / 2`, and repeats while the estimate keeps shrinking (at most about 20 steps for the largest inputs):

```mcfunction
scoreboard players operation #next pw.math = #in pw.math
scoreboard players operation #next pw.math /= #out pw.math
scoreboard players operation #next pw.math += #out pw.math
scoreboard players operation #next pw.math /= #2 pw.const
execute unless score #next pw.math < #out pw.math run return 0
scoreboard players operation #out pw.math = #next pw.math
function pw:math/sqrt_iter
```

Starting at `in / 2 + 1` keeps every sum below 2^31. A fixed number of steps is only accurate for small inputs, so the loop runs until the estimate stops shrinking.

## Trigonometry and vectors without math

The world does the trigonometry: `^ ^ ^` coordinates are local to the rotation. A marker at the origin turned toward a direction and moved `^ ^ ^1` holds the unit vector in its `Pos`:

```mcfunction
execute rotated as @s positioned 0.0 0.0 0.0 run tp @e[type=minecraft:marker,tag=pw.vec,limit=1] ^ ^ ^1
execute store result score #vx pw.math run data get entity @e[type=minecraft:marker,tag=pw.vec,limit=1] Pos[0] 1000
execute store result score #vz pw.math run data get entity @e[type=minecraft:marker,tag=pw.vec,limit=1] Pos[2] 1000
```

`#vx` = -sin(yaw)*cos(pitch)*1000, `#vz` = cos(yaw)*cos(pitch)*1000. For any angle, `execute rotated <yaw> 0 positioned 0.0 0.0 0.0 run tp <marker> ^ ^ ^1` gives sin and cos.

- Direction from A to B: `execute at A facing entity B feet run ...` (rotation), then `^ ^ ^n` to move toward B.
- Circles and rings: rotate by a fixed angle per step (`rotated ~30 0`) and place at `^ ^ ^r`.
- Spirals: increase the radius per step; helix: also add `~0.1` height per step.

```mcfunction
execute rotated 0 0 run particle minecraft:end_rod ^ ^ ^3 0 0 0 0 1
execute rotated 45 0 run particle minecraft:end_rod ^ ^ ^3 0 0 0 0 1
execute rotated 90 0 run particle minecraft:end_rod ^ ^ ^3 0 0 0 0 1
```

A ring generator with a recursion counter:

```mcfunction
scoreboard players add #i pw.math 1
particle minecraft:soul_fire_flame ^ ^ ^4 0 0 0 0 1 force
execute if score #i pw.math matches ..35 rotated ~10 ~ run function pw:fx/ring_step
```

Set `#i` to 0 and call `execute rotated 0 0 run function pw:fx/ring_step` to draw 36 points.

## Random choices

```mcfunction
execute store result score #pick pw.tmp run random value 1..3
execute if score #pick pw.tmp matches 1 run function pw:boss/attack/slam
execute if score #pick pw.tmp matches 2 run function pw:boss/attack/volley
execute if score #pick pw.tmp matches 3 run function pw:boss/attack/summon
```

Weighted: roll 1..100 and use ranges (`1..50`, `51..80`, `81..100`). Random entity: `@e[...,sort=random,limit=1]` or `@r` for players. Random position: `spreadplayers` on a marker, or roll offsets and apply with a macro.
