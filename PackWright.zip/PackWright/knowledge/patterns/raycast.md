# Raycasting

A raycast walks from the eyes along the look direction in small steps until it hits a block, an entity, or the maximum distance. It is a recursive function using `positioned ^ ^ ^<step>`.

## Block and entity raycast

`pw:ray/start` (run as the player):

```mcfunction
scoreboard players set #steps pw.tmp 0
tag @s add pw.ray_src
execute anchored eyes positioned ^ ^ ^0.5 run function pw:ray/step
tag @s remove pw.ray_src
```

`pw:ray/step`:

```mcfunction
scoreboard players add #steps pw.tmp 1
particle minecraft:electric_spark ~ ~ ~ 0 0 0 0 1
execute as @e[type=!#pw:ray_ignore,tag=!pw.ray_src,dx=0,dy=0,dz=0] positioned ~-0.99 ~-0.99 ~-0.99 if entity @s[dx=0,dy=0,dz=0] positioned ~0.99 ~0.99 ~0.99 run return run function pw:ray/hit_entity
execute unless block ~ ~ ~ #pw:ray_passable run return run function pw:ray/hit_block
execute if score #steps pw.tmp matches 100.. run return 0
execute positioned ^ ^ ^0.25 run function pw:ray/step
```

- Step 0.25 blocks x 100 steps = 25 blocks. Smaller steps are more precise and cost more.
- `dx=0,dy=0,dz=0` selects entities whose hitbox overlaps the 1x1x1 box starting at the position. Testing it again shifted by `-0.99` leaves only entities whose hitbox touches the current point, an exact hitbox test. `distance=..0.7` is a cheaper, rougher alternative. In `hit_entity`, `@s` is the entity that was hit.
- `#pw:ray_passable` is your own block tag (air, water, grass, flowers...); `#pw:ray_ignore` an entity type tag (markers, displays, items, experience orbs).
- `return run` stops the recursion at the first hit; the hit functions run at the hit position (`execute ... positioned` context is kept).

```json tags/block
{"values":["#minecraft:air","minecraft:water","minecraft:short_grass","minecraft:tall_grass","#minecraft:flowers","minecraft:light"]}
```

```json tags/entity_type
{"values":["minecraft:marker","minecraft:item_display","minecraft:block_display","minecraft:text_display","minecraft:item","minecraft:experience_orb","minecraft:area_effect_cloud"]}
```

## Cheaper alternatives

- Aimed entity within 100 blocks: predicate `type_specific.player.looking_at` (see datapack/predicates.md).
- Nearest entity in a cone: `execute as @e[distance=..10] facing entity @s eyes positioned as @s ...` with a rotation comparison, or `positioned ^ ^ ^5` + `@e[distance=..3]` for a sphere in front of the player.
- Line effects only (no hit detection): a loop that draws particles each step with no checks.

## Beam with damage along the whole path

Replace the hit return with damage at every step and keep going:

```mcfunction
execute as @e[type=!#pw:ray_ignore,tag=!pw.ray_src,distance=..1,tag=!pw.ray_hit] run damage @s 6 minecraft:magic by @p[tag=pw.ray_src]
tag @e[distance=..1,tag=!pw.ray_src] add pw.ray_hit
```

Remove `pw.ray_hit` from everything after the ray finishes so each entity is hit once per cast.

## Moving projectiles (tick based)

For a slow visible projectile, keep a marker and advance it a few steps per tick:

```mcfunction
execute as @e[type=minecraft:marker,tag=pw.bolt] at @s run function pw:bolt/tick
```

`pw:bolt/tick` advances with `tp @s ^ ^ ^0.5`, repeats the block/entity checks, counts lifetime in a score and kills itself on hit or timeout. The marker's rotation is set once at spawn: `execute rotated as <caster> run summon minecraft:marker ~ ~ ~ {...}` then `tp @s ~ ~ ~ ~ ~` keeps it.
