# Timers, cooldowns, resources and player feedback

## Per-player cooldown (score countdown)

```mcfunction
scoreboard players remove @a[scores={pw.cd=1..}] pw.cd 1
```

In the skill function:

```mcfunction
execute if score @s pw.cd matches 1.. run return run function pw:ui/on_cooldown
scoreboard players set @s pw.cd 100
function pw:skill/thunder_dash
```

`pw:ui/on_cooldown` shows the remaining seconds:

```mcfunction
scoreboard players operation @s pw.tmp = @s pw.cd
scoreboard players add @s pw.tmp 19
scoreboard players operation @s pw.tmp /= #20 pw.const
title @s actionbar [{text:"Cooldown ",color:"gray"},{score:{name:"@s",objective:"pw.tmp"},color:"red"},{text:"s",color:"gray"}]
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.5
```

Only one actionbar message shows at a time and the next `title ... actionbar` replaces it. If a HUD rewrites the actionbar every few ticks, a one-off message such as this warning is gone within that interval: let the HUD print it (a score that keeps the message alive for ~30 ticks), or use title, chat or just the sound.

## Several skills, several cooldowns

One objective per skill (`pw.cd_dash`, `pw.cd_nova`) or one objective per slot (`pw.cd1`, `pw.cd2`, `pw.cd3`). Decrement all in one function run for players that have any cooldown.

## Game-time cooldowns (no ticking)

```mcfunction
execute store result score #now pw.tmp run time query gametime
execute if score #now pw.tmp < @s pw.ready_at run return fail
scoreboard players operation @s pw.ready_at = #now pw.tmp
scoreboard players add @s pw.ready_at 100
```

No per-tick work at all, which scales to many players.

## Vanilla cooldown overlay

Items with `use_cooldown={seconds:5,cooldown_group:"pw:dash"}` show the white sweep on the hotbar and block reuse automatically. It applies when the item is used successfully (consumable, ender pearl-like behavior). Combine: the item shows the overlay, the function enforces its own score cooldown for non-consumable triggers.

## Mana / energy bar

```mcfunction
execute if score @s pw.mana < @s pw.mana_max run scoreboard players add @s pw.mana 1
title @s actionbar [{text:"Mana ",color:"aqua"},{score:{name:"@s",objective:"pw.mana"},color:"white"},{text:" / ",color:"gray"},{score:{name:"@s",objective:"pw.mana_max"},color:"white"}]
```

Run regeneration every 10 ticks from a scheduled loop. Spend: `execute if score @s pw.mana matches 30.. run function ...` then `scoreboard players remove @s pw.mana 30`.

Visual bars without a resource pack: build a text from fixed segments, e.g. 10 functions or a macro that prints `"||||||||||"` slices, or use the experience bar (`xp set @s <level> levels` and `xp set @s <points> points`) as a second meter.

## Feedback toolkit

| Want | Use |
|---|---|
| short status line | `title @s actionbar ...` (refresh every 10-20 ticks) |
| big announcement | `title @a title/subtitle` with `title @a times 5 40 10` |
| boss health | `bossbar add/set ... value/max/players/color/style`, `execute store result bossbar pw:boss value run ...` |
| persistent HUD numbers | sidebar objective with `numberformat` and display names |
| world labels | `text_display` with `billboard:"center"` |
| sound cues | `playsound` with pitch (0.5..2) to signal success/failure |
| particles | `particle` with `force` for long range visibility |
| menus | dialogs (`datapack/dialogs.md`) or clickable `tellraw` with `trigger` |
| screen effects | `effect give @s minecraft:darkness`/`nausea`/`blindness`, `camera_overlay` on equipped items, freezing `TicksFrozen` |

## Timed sequences

For cutscenes and boss attacks, a timer score and `matches` lines make a timeline:

```mcfunction
scoreboard players add #cast pw.timer 1
execute if score #cast pw.timer matches 1 run title @a title {text:"The sky darkens",color:"dark_gray"}
execute if score #cast pw.timer matches 20 run weather thunder 200
execute if score #cast pw.timer matches 40..80 run particle minecraft:electric_spark ~ ~3 ~ 3 1 3 0 20 force
execute if score #cast pw.timer matches 80 run function pw:boss/attack/storm_strike
execute if score #cast pw.timer matches 100.. run scoreboard players set #cast pw.timer 0
```

Or chain `schedule function pw:seq/step2 20t`, `pw:seq/step3 ...` when steps are long and no per-tick work is needed.
