# Multi-skill weapons

A complete working pack: `examples/storm-blade/` (`pw check examples/storm-blade` passes). Read it before building a similar item.

## Design checklist

1. Base item: `carrot_on_a_stick` (reliable right-click stat) or any item with `consumable` (hold/charge/cast-time mechanics). Restyle with `item_model`, name with `item_name`, describe skills in `lore`.
2. Identity: `custom_data={<ns>:{id:"<item>"}}`, checked with `execute if items entity @s weapon.mainhand *[custom_data~{...}]`.
3. Stats: `attribute_modifiers` for damage/speed/movement in `mainhand`; `unbreakable` or `max_damage`; `enchantment_glint_override`; `rarity`.
4. Inputs mapped to skills (see items/custom-items.md): right click, sneak + right click, `input` predicate keys (forward/back/left/right/jump), drop key, swap-hands key, on-hit and passive hooks via a hidden enchantment.
5. Each skill: cooldown gate -> resource cost -> effect -> feedback (sound, particles, actionbar).
6. Single definition: a loot table `<ns>:items/<item>` used by `loot give`, the recipe result mirrors it.
7. HUD: a 5-10 tick loop showing cooldowns while the item is held.
8. Clean up temporary tags (`caster`, `hit`) in the same function.

## Input dispatch (from the example)

```mcfunction
scoreboard players reset @s storm.click
execute unless items entity @s weapon.mainhand *[custom_data~{storm:{id:"blade"}}] run return fail
execute if predicate storm:sneaking run return run function storm:skill/nova/try
function storm:skill/dash/try
```

Directional variant with the `input` predicate (1.21.2+): a predicate file per direction (`type_specific:{type:"minecraft:player",input:{backward:true}}`) and `execute if predicate <ns>:input_back run return run function <ns>:skill/backstep`.

## Skill building blocks

| Effect | Commands |
|---|---|
| Dash / blink | stepwise `tp @s ^ ^ ^0.5` with block checks (example `skill/dash/step`), or a raycast to find the landing spot then `tp` |
| Line damage | dash or ray steps that `damage` entities within `distance=..1.5` once each (tag them) |
| Area damage | `execute as @e[type=!#<ns>:ignore,type=!player,tag=!<ns>.caster,distance=..6] run damage @s N <type> by @p[tag=<ns>.caster]` (keep `type=!player` unless PvP is intended; the example's `ignore.json` lists every non-living entity type plus armor stands, so only mobs are hit) |
| Crowd control | `effect give` slowness/levitation/weakness, `TicksFrozen` for the freeze overlay, `Motion` knockback on mobs |
| Projectile | summon a projectile with the vector technique (entities/motion-and-projectiles.md) or a marker moved per tick |
| Summons | `summon` allies with `Tags`, `Team`, a lifetime score, `Owner` for tameables |
| Buffs | `effect give @s ... true`, temporary `attribute ... modifier add <ns>:buff` removed by a scheduled function |
| Shields | `absorption` effect, `resistance`, or `damage_resistant`-like logic with scores |
| Visuals | particle rings (`fx/ring` recursion with `rotated ~5 0`), `dust` colors, `flash`, `electric_spark`, `sonic_boom`, display entities with interpolation |
| Sounds | `playsound` combinations with pitch for identity (`entity.breeze.wind_burst`, `entity.lightning_bolt.impact`, `block.glass.break`, `entity.warden.sonic_boom`, `item.trident.thunder`) |

## Damage attribution

`damage <target> <amount> <type> by <player>` gives kill credit, triggers `player_killed_entity`, angers mobs and drops player-only loot. Mark the caster with a tag (`<ns>.caster`) before forking `as` other entities, and refer to it as `@p[tag=<ns>.caster]`; remove the tag at the end of the skill.

## Passive and on-hit

A hidden enchantment on the item (`post_attack` with `run_function`, a `random_chance` requirement for procs) handles on-hit effects with the victim as `@s`. `tick` effects run every tick while held: throttle with `periodic_tick` in the requirements. See datapack/enchantments.md.

## Ultimate / charge mechanics

- Charge meter: a score that grows on hits (`post_attack` function adds to the attacker via `execute on attacker`) and is spent by a special input.
- Hold-to-charge: `consumable` + `using_item` advancement (count ticks held), release fires (items/custom-items.md).
- Combo chains: a combo step score and a short timeout score; each input advances the step if the timeout is still running.

## Balancing defaults

- Cooldowns 3-15 s, ultimate 30-60 s. Damage per skill 4-12 (player max health is 20).
- Area radius 4-8, dash 6-8 blocks, ray range 20-30 blocks.
- Always give audible and visible feedback for "on cooldown" and "not enough resource".
- Players swap items while a skill recharges, so judge a skill by its burst, not by damage per second of one weapon. Hits on one target within 10 ticks are swallowed by the hurt cooldown (pitfalls.md, Damage).
