# Pack architecture

## Layout for a feature-rich pack

```text
data/pw/function/
  load.mcfunction            objectives, teams, bossbars, storage defaults, schedule slow loops
  tick.mcfunction            one dispatcher line per system
  uninstall.mcfunction
  player/tick.mcfunction     runs as each player
  item/<name>/use.mcfunction, item/<name>/skill/<skill>.mcfunction
  boss/<name>/spawn|tick|phase/*|attack/*|death.mcfunction
  util/raycast/*, util/vec/*, util/fx/*
data/pw/advancement/events/*.json     hidden listeners
data/pw/predicate/*.json
data/pw/item_modifier/*.json
data/pw/loot_table/items/*.json       one loot table per custom item (give, drops, shops)
data/pw/enchantment/*.json            hidden hook enchantments
data/pw/tags/function/*.json          your own events (#pw:on_kill)
data/minecraft/tags/function/load.json, tick.json
```

## Conventions

- Namespace everything: objectives `pw.<name>`, entity tags `pw.<name>`, storage `pw:<name>`, bossbars `pw:<name>`, teams `pw.<name>`, attribute modifier ids `pw:<name>`.
- Custom items are created from loot tables (`loot give @s loot pw:items/storm_blade`) so `give`, drops and shops share one definition. A recipe result cannot call a loot table: repeat the item there and keep it identical.
- Identify custom items by `custom_data` (`pw:{id:"storm_blade"}`), never by name or model.
- One tick function: `execute as @a at @s run function pw:player/tick` plus `execute as @e[type=...,tag=pw.boss] at @s run function pw:boss/tick`. Inside, gate with cheap tests. Tick, load and scheduled functions have no executor and run at the world spawn, so every entity-related line needs its own `as`/`at`.
- Per-player numbers in scores, per-entity extras in tags/scores/`data`, global state on fake players (`#phase pw.boss`) and in storage.
- Use `#minecraft:load` for setup that must survive `/reload`; mark first-time setup with a storage flag (`execute unless data storage pw:state installed run function pw:install`).
- Slow systems on `schedule` loops (every 5, 10, 20 ticks) instead of every tick.

## load and uninstall template

```mcfunction
scoreboard objectives add pw.tmp dummy
scoreboard objectives add pw.const dummy
scoreboard objectives add pw.cd dummy
scoreboard objectives add pw.mana dummy
scoreboard objectives add pw.click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add pw.sneak minecraft.custom:minecraft.sneak_time
scoreboard players set #20 pw.const 20
scoreboard players set #100 pw.const 100
forceload add 0 0
execute unless data storage pw:state installed run function pw:install
schedule function pw:slow_loop 10t replace
```

```mcfunction
scoreboard objectives remove pw.tmp
scoreboard objectives remove pw.const
scoreboard objectives remove pw.cd
scoreboard objectives remove pw.mana
scoreboard objectives remove pw.click
scoreboard objectives remove pw.sneak
kill @e[tag=pw.entity]
data remove storage pw:state installed
schedule clear pw:slow_loop
```

## Performance budget

- 20 ticks per second, 50 ms each, shared with the whole game. A pack should spend well under a few ms.
- Most expensive: `@e` without `type=`/`tag=`/`distance=`, `nbt=` selectors, `data get` on players, raycasts every tick for every player, macro lines in hot loops, very many display entities updating each tick.
- Cheap: scores, tags, `@s`, `@a` (few entities), `execute if items`, predicates without NBT.
- Prefer event triggers (advancements, enchantment hooks, stats) to polling.
- Use `execute if entity @a[...]` gates so systems sleep when nobody is near.
- Check with `/tick query` and the F3 tick graph; `/debug function pw:x` logs one call (singleplayer/operators).

## State machines

Bosses, quests and skills are easiest as state machines: a state score (`pw.state`), a timer score (`pw.timer`), and one function per state.

```mcfunction
scoreboard players add @s pw.timer 1
execute if score @s pw.state matches 0 run function pw:boss/state/idle
execute if score @s pw.state matches 1 run function pw:boss/state/charge
execute if score @s pw.state matches 2 run function pw:boss/state/slam
```

Each state function decides when to switch: set `pw.state` and reset `pw.timer` to 0.
