# Boss fights

A complete working boss: `examples/storm-king/` (`pw check examples/storm-king` passes). It shows spawning, bossbar, two phases, three attacks with telegraphs, minions, arena leash, idle despawn, death detection (a hidden advancement tells a player kill from a boss that merely vanished), loot, an advancement, and putting the weather back afterwards.

## Anatomy

| Part | How |
|---|---|
| Body | a vanilla mob with `Tags`, `CustomName`, `PersistenceRequired`, `attributes` (`max_health`, `attack_damage`, `movement_speed`, `knockback_resistance`, `scale`, `follow_range`, `armor`), `equipment` with `drop_chances` 0, `DeathLootTable` |
| Or a custom body | `item_display`/`block_display` models riding or following an invisible `husk`/`zombie` (`active_effects` invisibility) or an `interaction` hitbox; move the visuals with `teleport_duration` |
| Global state | fake player scores: `#alive`, `#phase`, `#attack` timer, `#idle` timer |
| Health bar | `bossbar add`, `bossbar set ... max/value/players/color/style`, `execute store result bossbar <id> value run data get entity @s Health` |
| Phases | compare health (stored in a score) to thresholds; one function per transition (title, sound, attribute changes, resistance burst) |
| Attack loop | timer score + `random value` picks an attack; faster in later phases |
| Telegraphs | markers at target positions show particles for 20-30 ticks before the hit, so players can dodge |
| Arena | a marker at the spawn point; leash the boss back with `tp` if it strays; only target players within a radius |
| Death | the boss entity is gone while the arena marker is loaded -> boss defeated; call it a victory only if a player got the kill (a `player_killed_entity` advancement that sets a flag), because `/kill`, the void and despawning also remove it; clean up minions, markers, bossbar |
| Reset | no players nearby for N seconds -> despawn without loot (switch `DeathLootTable` to an empty table first) |

## Tick structure (from the example)

```mcfunction
execute store result bossbar king:hp value run data get entity @s Health
bossbar set king:hp players @a[distance=..48]
execute if score #phase king.data matches 1 store result score #hp king.data run data get entity @s Health
execute if score #phase king.data matches 1 if score #hp king.data matches ..200 run function king:boss/phase2
scoreboard players add #attack king.timer 1
execute if score #phase king.data matches 1 if score #attack king.timer matches 100.. run function king:boss/choose_attack
execute if score #phase king.data matches 2 if score #attack king.timer matches 60.. run function king:boss/choose_attack
```

## Telling a kill from a disappearance

The boss is gone from the world in every case (kill by a player, `/kill`, void, despawn). A hidden advancement fires only for a player kill; its reward function sets a flag and revokes the advancement so it can fire again:

```json advancement
{"criteria":{"kill":{"trigger":"minecraft:player_killed_entity","conditions":{"entity":{"type":"minecraft:wither_skeleton","nbt":"{Tags:[\"king.boss\"]}"}}}},"rewards":{"function":"king:boss/slain"}}
```

```mcfunction
scoreboard players set #slain king.data 1
advancement revoke @s only king:events/slain
```

When the boss entity is missing, read `#slain`: 1 means victory, anything else means it vanished.

## Attack ideas with vanilla commands

| Attack | Implementation |
|---|---|
| Targeted lightning | marker per player, warning particles, `summon minecraft:lightning_bolt` after a delay |
| Shockwave / slam | particle ring, `damage` + `levitation 1 4` for players in radius, `playsound entity.warden.sonic_boom` |
| Charge | face a player (`rotate @s facing entity @p`), set `Motion` toward it, damage on contact for a few ticks |
| Projectile volley | summon `small_fireball`/`wither_skull`/`arrow` with motion toward players, or `shulker_bullet` homing |
| Summon minions | cap with `execute store result score #n ... if entity @e[tag=minion]`; vex `life_ticks` for auto despawn |
| Ground hazards | `area_effect_cloud` with harmful `potion_contents`, `fill` fire/powder snow temporarily, magma via `setblock` and a cleanup schedule |
| Beam | raycast from the boss's eyes toward a player with particles each step and damage at the end (patterns/raycast.md) |
| Teleport | `spreadplayers` the boss within the arena or `tp` behind the target (`execute at @p rotated as @p run tp @s ^ ^ ^-2`) |
| Pull / push | non-player `Motion`; for players `levitation`, explosions without block damage, or `tp` steps |
| Enrage | below 20 % health: shorter timer, `attribute` buffs, particles every tick |
| Invulnerable windows | `data merge entity @s {Invulnerable:true}` during transitions, or `effect give resistance 4` |

## Fairness and polish

- Telegraph every big hit (sound + particles + 0.75-1.5 s delay).
- Scale with player count: count players in the arena into a score and multiply attack frequency or health (`attribute ... base set` via macro).
- Make sure the boss cannot be cheesed: `knockback_resistance`, leash to the arena, `PersistenceRequired`, `follow_range`, immunity to suffocation by checking blocks around it, removing the `fall_distance`.
- Bossbar color per phase; a short title on phase change; music via `playsound` in the `record` category.
- Award kill credit by dealing scripted damage `by` the nearest player when appropriate.
- Clean up everything on victory, despawn and `/reload` (load should hide stale bossbars).
- Global changes such as `weather`, game rules and `time` outlive the fight: remember the old value or leave them alone.
- Targeting rules that skip creative or spectator players also make a creative-mode test look broken (no attacks, the boss despawns): mention it or add a debug switch.
