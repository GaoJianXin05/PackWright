# Knowledge index

Open the files a task needs, not all of them. `pw find <words>` searches every file by section.

| File | Read when |
|---|---|
| version-1.21.8.md | always first for anything you remember from older versions; numbers, what does not exist yet, stale -> current syntax |
| pitfalls.md | before building any multi-part system; logic mistakes the checker cannot see |
| **commands/** | |
| commands/execute.md | context (`as`/`at`/`positioned`/`rotated`/`facing`/`anchored`/`on`/`summon`), conditions, `store`, forking, `return` |
| commands/scoreboard.md | objectives and criteria, operations, `trigger` buttons, random, linking entities to players |
| commands/selectors.md | `@a/@e/@s/@p/@r/@n` arguments, ranges, sorting, performance |
| commands/data-nbt-storage.md | SNBT rules, `/data`, NBT paths, storage, converting scores <-> NBT |
| commands/text-components.md | `tellraw`/`title`/names/lore: content types, style, `click_event`, `hover_event` |
| commands/item-commands.md | item stack syntax, slots, item predicates, `/item`, `/loot`, `clear` |
| commands/world-and-entity-commands.md | summon, tp, damage, effect, attribute, particle, playsound, bossbar, fill, game rules, dialog, waypoint |
| **items/** | |
| items/components.md | every useful item component grouped by purpose |
| items/custom-items.md | identity, every input detection method, right click and charge patterns, enchantment hooks, cooldowns |
| items/item-modifiers-and-loot.md | loot functions, item modifiers, loot tables, number providers |
| **datapack/** | |
| datapack/structure.md | pack.mcmeta, folders, ids, load/tick, tags, installing |
| datapack/functions-and-macros.md | functions, return values, macros, schedule, function quality |
| datapack/advancements.md | advancement shape, hidden event listeners, all 57 triggers |
| datapack/predicates.md | loot conditions, entity predicate fields, player input, examples |
| datapack/enchantments.md | custom enchantments and effect components as event hooks |
| datapack/dialogs.md | dialogs (1.21.6+): types, inputs, actions, menus and forms |
| datapack/recipes-and-registries.md | recipes, damage types, other data-driven registries |
| **entities/** | |
| entities/entity-nbt.md | entity data fields in 1.21.8 and how to change them |
| entities/display-interaction-marker.md | display entities, interpolation, interaction hitboxes, markers |
| entities/motion-and-projectiles.md | motion vectors, projectiles, hit detection |
| **patterns/** | |
| patterns/architecture.md | layout, naming, load/uninstall, performance budget, state machines |
| patterns/raycast.md | block and entity raycasts, beams, tick-based projectiles |
| patterns/timers-cooldowns-ui.md | cooldowns, mana, HUD, feedback, timelines |
| patterns/math.md | fixed point, positions, distances, sqrt, vectors from rotation, random choices |
| patterns/skill-weapons.md | multi-skill weapons; full example in `examples/storm-blade/` |
| patterns/boss-fights.md | bosses with phases and attacks; full example in `examples/storm-king/` |

## Ground truth beyond these notes

| Question | Tool |
|---|---|
| exact syntax of a command | `pw usage <command> [words]` |
| does this id/block state/tag exist | `pw id`, `pw block`, `pw tag` |
| fields of a component, trigger, loot function, entity, dialog, ... | `pw schema <kind> <key>` |
| how vanilla does it | `pw vanilla <path or words>`, `pw vanilla --grep <text>` |
| an error message or translation key | `pw lang <words>` |
| do several packs of one map fit together (functions, objectives, tags across packs) | `pw check --merge <pack> <pack> ...` |
