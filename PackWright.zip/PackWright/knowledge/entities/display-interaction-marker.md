# Display, interaction and marker entities

These three are the building blocks of custom visuals, hitboxes and logic anchors. None of them has AI or physics.

## Display entities

`block_display`, `item_display`, `text_display`. Rendered client-side, no hitbox, can be scaled, rotated and smoothly animated.

Shared fields (`pw schema entity item_display --flat`):

| Field | Meaning |
|---|---|
| `transformation` | `{translation:[x,y,z],left_rotation:[x,y,z,w],scale:[x,y,z],right_rotation:[x,y,z,w]}` or a 16-float matrix; rotations may also be `{angle:<rad>,axis:[x,y,z]}` |
| `interpolation_duration`, `start_interpolation` | ticks to animate the next transformation change, and delay before it starts (0 = next tick) |
| `teleport_duration` | 0..59 ticks to smooth position/rotation changes from `tp` |
| `billboard` | `fixed` `vertical` `horizontal` `center` (face the camera) |
| `brightness` | `{sky:15,block:15}` override light |
| `view_range`, `shadow_radius`, `shadow_strength`, `width`, `height` (culling box), `glow_color_override` | rendering |

Type fields: `block_state:{Name:..,Properties:{..}}` (block), `item:{id:..,count:1,components:{..}}` + `item_display` (`none thirdperson_lefthand thirdperson_righthand firstperson_lefthand firstperson_righthand head gui ground fixed`) (item), `text`, `line_width`, `background` (ARGB int), `default_background`, `text_opacity`, `shadow`, `see_through`, `alignment` (`center left right`) (text).

```mcfunction
summon minecraft:item_display ~ ~1 ~ {Tags:["pw.orb"],item:{id:"minecraft:heart_of_the_sea",count:1},billboard:"center",brightness:{sky:15,block:15},transformation:{translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],scale:[0.6f,0.6f,0.6f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:block_display ~ ~ ~ {Tags:["pw.wall"],block_state:{Name:"minecraft:blue_stained_glass"},transformation:{translation:[-1.5f,0f,-0.05f],left_rotation:[0f,0f,0f,1f],scale:[3f,3f,0.1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:text_display ~ ~2.3 ~ {Tags:["pw.hp_label"],text:[{text:"Storm King ",color:"aqua"},{text:"300",color:"red"}],billboard:"center",background:1073741824,see_through:false}
```

Animate: change the transformation and set the interpolation in the same tick.

```mcfunction
data merge entity @e[type=minecraft:item_display,tag=pw.orb,limit=1] {start_interpolation:0,interpolation_duration:10,transformation:{translation:[0f,1f,0f],left_rotation:{angle:3.14159f,axis:[0f,1f,0f]},scale:[1.2f,1.2f,1.2f],right_rotation:[0f,0f,0f,1f]}}
data merge entity @e[type=minecraft:item_display,tag=pw.orb,limit=1] {teleport_duration:3}
execute as @e[type=minecraft:item_display,tag=pw.orb] at @s run tp @s ~ ~ ~ ~10 ~
```

Tips:

- When you `summon`, write all four `transformation` fields (`translation`, `left_rotation`, `scale`, `right_rotation`) or none. The compound is decoded as a whole, so a partial one is rejected (the game logs an error) and the display keeps its default size. `data merge` on an existing display may name just the fields that change.
- Displays render relative to their position; `translation` offsets the model, `scale` grows it around the origin (a block display's origin is its corner, so translate by `-scale/2` to centre).
- Ride a display on a mob (`Passengers`) to attach visuals that follow it smoothly, or `tp` it every tick with `teleport_duration`.
- Text displays are the cheapest floating labels and damage numbers. Update text with `data modify entity @s text set value {...}`.
- Kill displays when done; they never despawn.

## Interaction entity

Invisible hitbox (`width`, `height`) that records the last player who attacked or right-clicked it.

| Field | Meaning |
|---|---|
| `width`, `height` | hitbox size (centred horizontally, grows upward) |
| `response` | `true` plays the arm swing and stops the click going through |
| `attack` | `{player:[I;..],timestamp:L}` last left click |
| `interaction` | `{player:[I;..],timestamp:L}` last right click |

```mcfunction
summon minecraft:interaction ~ ~ ~ {Tags:["pw.button"],width:1.0f,height:1.0f,response:true}
execute as @e[type=minecraft:interaction,tag=pw.button] if data entity @s interaction run function pw:button/pressed
execute as @e[type=minecraft:interaction,tag=pw.button] if data entity @s attack run function pw:button/hit
```

In `pw:button/pressed`, `execute on target run ...` runs as the player who right-clicked and `on attacker` as the last attacker. Then clear the record: `data remove entity @s interaction`. Advancement triggers `player_interacted_with_entity` and `player_hurt_entity` also fire for interactions, running directly as the player.

Uses: clickable buttons and NPCs, custom hitboxes for display-entity bosses, large hitboxes for small mobs, left-click detection in a fixed area.

## Marker

`marker` has only base NBT and `data`. It is not sent to clients and costs almost nothing. Use it for:

- remembering positions (spawn points, waypoints, portal links),
- raycast and projectile cursors (`tp` it step by step),
- per-object state (`data:{pw:{owner:12,ticks:40}}`) and scores,
- running `execute at` from a fixed place.

```mcfunction
summon minecraft:marker ~ ~ ~ {Tags:["pw.portal","pw.new"],data:{pw:{target:"nether_hub"}}}
scoreboard players operation @e[type=minecraft:marker,tag=pw.new] pw.id = @s pw.id
tag @e[type=minecraft:marker,tag=pw.new] remove pw.new
```

Markers survive chunk unloads (they are saved) but do nothing in unloaded chunks; `execute as @e[type=marker]` only finds markers in loaded chunks.
