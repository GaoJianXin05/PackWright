# Entity data (NBT) in 1.21.8

All fields per entity: `pw schema entity <id> --flat`. Summonable ids: `pw id entity_type`. `player` and `fishing_bobber` cannot be summoned.

## Every entity

`Pos` [3 doubles], `Motion` [3 doubles], `Rotation` [yaw, pitch floats], `Tags` [strings], `CustomName` (text component), `CustomNameVisible`, `Silent`, `NoGravity`, `Glowing`, `Invulnerable`, `OnGround`, `Fire` (ticks, short), `HasVisualFire`, `Air`, `fall_distance` (double), `PortalCooldown`, `TicksFrozen`, `Passengers` [entities with `id`], `UUID` [I;4 ints], `data` (free compound for your own data, saved with the entity; commands cannot write player NBT, so use it on other entities).

## Living entities and mobs

| Field | Meaning |
|---|---|
| `Health`, `AbsorptionAmount` | float |
| `attributes` | `[{id:"minecraft:max_health",base:100d,modifiers:[{id:"pw:x",amount:..,operation:".."}]}]` |
| `active_effects` | `[{id:"minecraft:slowness",amplifier:1b,duration:200,show_particles:false}]` |
| `equipment` | `{mainhand:{..},offhand:{..},head:{..},chest:{..},legs:{..},feet:{..},body:{..},saddle:{..}}` (1.21.5) |
| `drop_chances` | `{mainhand:0.0f,head:0.0f}` 0..1; >1 always drops undamaged |
| `NoAI`, `PersistenceRequired`, `CanPickUpLoot`, `LeftHanded` | behavior flags |
| `DeathLootTable`, `DeathLootTableSeed` | custom drops |
| `Team` | team on spawn |
| `home_pos`, `home_radius` | restriction area (1.21.6) |
| `leash` | `{UUID:[I;..]}` or block position |
| `Brain.memories` | AI memories (advanced) |

Mob-specific highlights: zombie `IsBaby`, `CanBreakDoors`; creeper `Fuse`, `ExplosionRadius`, `powered`, `ignited`; slime/magma cube `Size`; enderman `carriedBlockState`; wither `Invul`; ender dragon `DragonPhase`; vex `life_ticks`, `owner`, `bound_pos`; villager `VillagerData`, `Offers`; iron golem `PlayerCreated`; tamed animals `Owner`, `Sitting`; ghast `ExplosionPower`; phantom `size`; warden `anger`; breeze, bogged, creaking, armadillo, happy_ghast exist in 1.21.8.

```mcfunction
summon minecraft:wither_skeleton ~ ~ ~ {Tags:["pw.boss","pw.storm_king"],CustomName:{text:"Storm King",color:"aqua",bold:true},CustomNameVisible:true,PersistenceRequired:true,Health:300f,attributes:[{id:"minecraft:max_health",base:300d},{id:"minecraft:attack_damage",base:12d},{id:"minecraft:movement_speed",base:0.3d},{id:"minecraft:knockback_resistance",base:1d},{id:"minecraft:scale",base:1.5d}],equipment:{mainhand:{id:"minecraft:netherite_sword",count:1},head:{id:"minecraft:lightning_rod",count:1}},drop_chances:{mainhand:0.0f,head:0.0f},DeathLootTable:"pw:boss/storm_king"}
summon minecraft:zombie ~ ~ ~ {IsBaby:true,active_effects:[{id:"minecraft:speed",amplifier:2b,duration:-1,show_particles:false}],Silent:true}
summon minecraft:creeper ~ ~ ~ {powered:true,Fuse:10s,ExplosionRadius:5b,ignited:true}
summon minecraft:slime ~ ~ ~ {Size:8,NoAI:true,Invulnerable:true}
```

`Health` above the default max needs the `max_health` attribute in the same NBT (`attributes` is read before `Health`). A max health that comes from `attribute_modifiers` on worn equipment or from an effect is applied on the first tick after the entity exists, so `Health` is clamped to the base max at spawn: put the value in `attributes` instead, or raise `Health` a tick later. `duration:-1` is infinite.

## Non-living utility entities

| Entity | Key fields |
|---|---|
| `marker` | only base fields + `data`; invisible, never ticks, never sent to clients. Best for positions, anchors, state holders |
| `armor_stand` | `Invisible`, `Marker` (no hitbox), `NoBasePlate`, `ShowArms`, `Small`, `Pose`, `DisabledSlots`, `equipment` |
| `item` | `Item` (stack), `PickupDelay` (32767 = never), `Age` (-32768 = never despawn), `Owner`, `Thrower` |
| `falling_block` | `BlockState:{Name:..,Properties:{..}}`, `Time`, `DropItem`, `HurtEntities`, `FallHurtAmount`, `FallHurtMax`, `CancelDrop`, `TileEntityData` |
| `area_effect_cloud` | `Radius`, `Duration`, `WaitTime`, `RadiusPerTick`, `RadiusOnUse`, `ReapplicationDelay`, `potion_contents`, `custom_particle`, `Owner` |
| `tnt` | `fuse`, `explosion_power` (0..128), `block_state`, `owner` |
| `lightning_bolt` | spawns fire and damage; `execute summon minecraft:lightning_bolt` |
| `experience_orb` | `Value`, `Count` |
| `evoker_fangs` | `Warmup`, `Owner` |
| `end_crystal` | `ShowBottom`, `beam_target` [I;x,y,z] |
| `firework_rocket` | `FireworksItem`, `LifeTime`, `ShotAtAngle` |
| display entities, `interaction` | see display-interaction-marker.md |
| projectiles | see motion-and-projectiles.md |

```mcfunction
summon minecraft:item ~ ~1 ~ {Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_data":{pw:{loot:true}}}},PickupDelay:20,Motion:[0.0d,0.3d,0.0d]}
summon minecraft:falling_block ~ ~10 ~ {BlockState:{Name:"minecraft:anvil"},Time:1,DropItem:false,HurtEntities:true,FallHurtAmount:6f,FallHurtMax:40}
summon minecraft:area_effect_cloud ~ ~ ~ {Radius:4f,Duration:100,WaitTime:0,RadiusPerTick:-0.02f,potion_contents:{custom_effects:[{id:"minecraft:poison",amplifier:1b,duration:60}]},custom_particle:{type:"minecraft:dust",color:[0.2,0.9,0.2],scale:1.5}}
summon minecraft:tnt ~ ~ ~ {fuse:40s,explosion_power:6f}
summon minecraft:armor_stand ~ ~ ~ {Invisible:true,Marker:true,NoGravity:true,Tags:["pw.anchor"]}
summon minecraft:marker ~ ~ ~ {Tags:["pw.spawn_point"],data:{pw:{wave:1}}}
```

## Changing entities

- `data merge entity <non-player> {...}` and `data modify entity ...` for NBT.
- Attributes at runtime: `attribute` command (works on players too).
- Effects: `effect give`.
- Equipment: `item replace entity <e> weapon.mainhand|armor.head|... with <item>`.
- Position and rotation: `tp`, `rotate`; velocity: `data modify entity @s Motion set value [..]`.
- Removing without death animation or drops: `tp @s ~ -1000 ~` then `kill`, or just `kill` for markers/displays.
