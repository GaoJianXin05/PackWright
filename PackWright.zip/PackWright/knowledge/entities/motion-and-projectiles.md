# Motion and projectiles

## Motion for non-player entities

`Motion:[dx,dy,dz]` in blocks per tick (doubles). Gravity and drag apply afterwards each tick (`NoGravity:true` disables gravity).

Launching an entity where a player looks: use a helper marker near the world origin (keep `0 0` force-loaded) to turn rotation into a vector.

```mcfunction
forceload add 0 0
summon minecraft:marker 0.0 0.0 0.0 {Tags:["pw.vec"]}
execute rotated as @s positioned 0.0 0.0 0.0 run tp @e[type=minecraft:marker,tag=pw.vec,limit=1] ^ ^ ^1.5
execute anchored eyes positioned ^ ^ ^1 run summon minecraft:snowball ~ ~ ~ {Tags:["pw.proj","pw.new"],Item:{id:"minecraft:snowball",count:1}}
data modify entity @e[type=minecraft:snowball,tag=pw.new,limit=1] Motion set from entity @e[type=minecraft:marker,tag=pw.vec,limit=1] Pos
tag @e[tag=pw.new] remove pw.new
```

The first two lines go in the load function. `^ ^ ^1.5` sets the speed (1.5 blocks/tick). Owner credit: `data modify entity <projectile> Owner set from entity @s UUID`.

## Players

Player `Motion` cannot be written. Ways to move a player:

- `tp @s ^ ^ ^3` (instant, no momentum, can clip into walls: check blocks first),
- `effect give @s minecraft:levitation 1 10 true` for upward lift, `minecraft:slow_falling` for gliding,
- an explosion with no block damage at the player's feet: summon `minecraft:wind_charge` with fast downward `Motion` right above the feet, or a `tnt` with `explosion_power` small and `fuse:0s` (damages),
- `attribute` changes: `jump_strength`, `gravity`, `movement_speed`, `step_height`, `safe_fall_distance`, `scale`,
- riding: mount the player on an invisible entity with Motion, then dismount.

## Projectile entities

| Entity | Notes |
|---|---|
| `arrow`, `spectral_arrow` | `damage` (base 2.0), `crit`, `PierceLevel`, `pickup` (0 none, 1 allowed, 2 creative), `life`, `item`, `weapon`, `SoundEvent`; arrows `potion_contents` for tipped |
| `trident` | `item`, `DealtDamage`, `pickup` |
| `snowball`, `egg`, `ender_pearl`, `experience_bottle`, `splash_potion`, `lingering_potion` | `Item` (the rendered/used item) |
| `fireball` | `ExplosionPower`, `acceleration_power` (constant thrust along Motion), `Item` |
| `small_fireball`, `dragon_fireball`, `wither_skull` (`dangerous`), `wind_charge`, `breeze_wind_charge` | `acceleration_power` |
| `shulker_bullet` | homing: `Target`, `Steps`, `TXD/TYD/TZD` |
| `llama_spit`, `firework_rocket` (`ShotAtAngle`, `LifeTime`) | |

All projectiles: `Owner` (UUID ints), `HasBeenShot`, `LeftOwner`.

```mcfunction
execute anchored eyes positioned ^ ^ ^1 run summon minecraft:arrow ~ ~ ~ {Tags:["pw.arrow","pw.new"],damage:6.0d,crit:true,PierceLevel:3b,pickup:0b}
execute anchored eyes positioned ^ ^ ^1.5 run summon minecraft:fireball ~ ~ ~ {Tags:["pw.new"],ExplosionPower:2,acceleration_power:0.1d}
execute anchored eyes positioned ^ ^ ^1 run summon minecraft:wind_charge ~ ~ ~ {Tags:["pw.new"],acceleration_power:0.2d}
```

For fireballs and wind charges, set `Motion` with the vector technique or use the same vector as a direction; `acceleration_power` keeps pushing along the current motion.

## Detecting projectile hits

- Track a tagged projectile each tick: when it is gone (or `inGround:true` for arrows), act at its last position stored on a marker.
- Snowballs and eggs vanish on impact; check in the tick function whether the tagged entity still exists and use a marker riding along (`Passengers`) or a last-position score.
- `on origin` from the projectile gives the shooter.
- Hit entity: `player_hurt_entity` with `damage.direct_entity` type, or enchantment `post_attack` with `enchanted:"attacker"` and `damaging_entity`, or the victim's `HurtTime`.
- `target_hit` trigger for target blocks; enchantment `hit_block` for blocks hit by a projectile shot from an enchanted weapon.

## Custom projectiles without entities physics

A "projectile" can also be a marker or item display moved by a function every tick: `tp @s ^ ^ ^0.8`, check blocks (`unless block ~ ~ ~ #minecraft:air`) and entities (`if entity @e[dx=0,...]` or `distance=..1`), draw particles, count lifetime. This gives exact control: homing, bouncing, piercing, splitting. See `patterns/raycast.md`.
