# Data pack structure (format 81)

```text
<pack>/
  pack.mcmeta
  pack.png                         optional 64x64 icon
  data/
    minecraft/tags/function/load.json
    minecraft/tags/function/tick.json
    <ns>/function/**/*.mcfunction
    <ns>/advancement/**/*.json
    <ns>/predicate/**/*.json
    <ns>/item_modifier/**/*.json
    <ns>/loot_table/**/*.json
    <ns>/recipe/**/*.json
    <ns>/enchantment/**/*.json
    <ns>/dialog/**/*.json
    <ns>/damage_type/**/*.json
    <ns>/tags/<registry>/**/*.json   e.g. tags/item, tags/block, tags/entity_type, tags/function, tags/damage_type
    <ns>/structure/**/*.nbt
```

All folder names are singular since 1.21. Other data-driven folders: `banner_pattern`, `cat_variant`, `chat_type`, `chicken_variant`, `cow_variant`, `dimension`, `dimension_type`, `enchantment_provider`, `frog_variant`, `instrument`, `jukebox_song`, `painting_variant`, `pig_variant`, `test_environment`, `test_instance`, `trial_spawner`, `trim_material`, `trim_pattern`, `wolf_sound_variant`, `wolf_variant`, `worldgen/...`.

`pw new <dir> --ns <namespace>` creates the skeleton; `pw check <dir>` validates it; `pw pack <dir>` zips it.

## pack.mcmeta

```json pack_mcmeta
{"pack":{"pack_format":81,"description":{"text":"Storm Blade pack","color":"aqua"}}}
```

A pack meant to load on a range of versions can add `"supported_formats":[71,81]`; for 1.21.8 only, `pack_format` 81 is enough. Overlays (`"overlays":{"entries":[{"formats":[..],"directory":".."}]}`) select extra folders per version.

## Names and ids

- Namespace and paths: lower-case `a-z 0-9 _ - .` and `/` in paths. No spaces, capitals or Chinese characters in file names (display text can be anything).
- Resource id = `<ns>:<path without extension>`: `data/pw/function/skills/fire.mcfunction` is `pw:skills/fire`.
- Use your own namespace for everything; only put files under `minecraft/` to override vanilla (loot tables, the load/tick tags).
- Prefix scoreboard objectives, tags, teams, storage and bossbars with the namespace too (`pw.cd`, `pw.boss`, `pw:state`).

## load and tick

```json tags/function
{"values":["pw:load"]}
```

- `#minecraft:load` runs on world load and on `/reload`, before players are processed. Create objectives, teams, bossbars, storage defaults there. It must be safe to run many times (`scoreboard objectives add` on an existing objective just fails harmlessly).
- `#minecraft:tick` runs every game tick (20/s). Keep it small: dispatch to sub-functions with cheap conditions.
- For slower loops, schedule a function from itself: `schedule function pw:slow 10t` at the end of `pw:slow`, started once from load.

## Tags

```json tags/item
{"replace":false,"values":["minecraft:diamond_sword","#minecraft:axes",{"id":"othermod:blade","required":false}]}
```

A tag with a missing required entry fails to load completely. Function tags (`tags/function`) let several packs hook the same event.

## Installing

Put the folder or zip into `<world>/datapacks/`, then `/reload` (or restart). `/datapack list` shows it; `/datapack enable "file/<name>"` if it is disabled. Errors appear in the server log or the game output log; a function with any unparsable line does not load at all, so check with `pw check` before shipping.
