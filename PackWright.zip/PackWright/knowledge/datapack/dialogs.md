# Dialogs (1.21.6+)

Dialogs are native GUI screens: title, body text/items, input widgets and buttons. Define them in `data/<ns>/dialog/<name>.json` or inline, open them with `dialog show <targets> <dialog>`, a `show_dialog` click event, or the pause menu / quick actions key through dialog tags. Schema: `pw schema dialog <type>`, `pw schema input <type>`, `pw schema action <type>`.

## Types

| Type | Shape |
|---|---|
| `minecraft:notice` | one `action` button (default OK) |
| `minecraft:confirmation` | `yes` and `no` buttons |
| `minecraft:multi_action` | grid of `actions` (`columns`, default 2), optional `exit_action` |
| `minecraft:dialog_list` | buttons opening other `dialogs` (id, list or `#tag`), labelled by their `external_title` |
| `minecraft:server_links` | server links list |

Common fields: `title`, `external_title`, `body` (one or a list of `minecraft:plain_message` `{contents,width}` / `minecraft:item` `{item,description,show_decorations,show_tooltip,width,height}`), `inputs`, `can_close_with_escape` (default true), `pause` (default true, single player only), `after_action` (`close` default, `none` keeps it open and requires `pause:false`, `wait_for_response`).

Button: `label`, `tooltip`, `width` (1..1024), `action`.

## Inputs

Every input has `type` and `key` (letters, digits, `_`).

| Input | Fields | Value given to templates |
|---|---|---|
| `minecraft:text` | `label`, `label_visible`, `initial`, `max_length` (default 32), `multiline:{max_lines,height}`, `width` | the text, escaped for use inside an SNBT string |
| `minecraft:boolean` | `label`, `initial`, `on_true`, `on_false` | `on_true` / `on_false` text (default `true`/`false`) |
| `minecraft:single_option` | `label`, `options:[{id,display,initial}|"id"]`, `width` | the selected `id` |
| `minecraft:number_range` | `label`, `label_format`, `start`, `end`, `step`, `initial`, `width` | the number; whole numbers have no decimal point |

## Actions

All click event actions with `type` instead of `action`: `run_command` (`command`), `suggest_command`, `open_url` (`url`), `copy_to_clipboard` (`value`), `change_page`, `show_dialog` (`dialog`), `custom` (`id`, `payload`). Plus:

- `minecraft:dynamic/run_command` with `template`: `$(key)` is replaced by each input's value; missing keys become empty.
- `minecraft:dynamic/custom` with `id`, `additions`: sends all inputs as a compound to the server (ignored by vanilla).

Commands from dialogs run as the clicking player with their permission level. Players without op can only use `trigger` and other non-op commands, so buttons that drive a data pack use `trigger <objective> set <value>`.

## Example: skill menu driven by trigger

```json dialog
{"type":"minecraft:multi_action","title":{"text":"Skill Tree","color":"gold"},"body":{"type":"minecraft:plain_message","contents":"Choose a skill to equip."},"pause":false,"columns":2,"actions":[{"label":{"text":"Thunder Dash","color":"aqua"},"tooltip":"Dash forward and strike lightning","action":{"type":"minecraft:run_command","command":"trigger pw.menu set 1"}},{"label":{"text":"Frost Nova","color":"blue"},"action":{"type":"minecraft:run_command","command":"trigger pw.menu set 2"}},{"label":"Blink","action":{"type":"minecraft:run_command","command":"trigger pw.menu set 3"}}],"exit_action":{"label":"Close"}}
```

```mcfunction
scoreboard objectives add pw.menu trigger
scoreboard players enable @a pw.menu
dialog show @s pw:skill_tree
execute as @a[scores={pw.menu=1}] run function pw:menu/equip_dash
execute as @a[scores={pw.menu=2}] run function pw:menu/equip_nova
scoreboard players set @a[scores={pw.menu=1..}] pw.menu 0
scoreboard players enable @a pw.menu
```

## Example: input form

```json dialog
{"type":"minecraft:confirmation","title":"Set bounty","inputs":[{"type":"minecraft:number_range","key":"amount","label":"Emeralds","start":1,"end":64,"step":1,"initial":10},{"type":"minecraft:boolean","key":"anon","label":"Anonymous","on_true":"1","on_false":"0"}],"yes":{"label":"Post","action":{"type":"minecraft:dynamic/run_command","template":"trigger pw.bounty set $(amount)"}},"no":{"label":"Cancel"}}
```

## Dialog tags

- `data/minecraft/tags/dialog/pause_screen_additions.json`: dialogs added as a button on the pause screen.
- `data/minecraft/tags/dialog/quick_actions.json`: dialogs opened by the Quick Actions key (default G).

```json tags/dialog
{"values":["pw:skill_tree"]}
```
