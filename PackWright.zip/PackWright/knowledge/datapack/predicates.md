# Predicates and loot conditions

`data/<ns>/predicate/<path>.json` holds one loot condition or a list (all must pass). Use them in `execute if predicate`, selector `predicate=`, loot tables, item modifiers, advancement `player`/`entity` lists and enchantment `requirements`. `execute if predicate` also accepts an inline SNBT condition.

## Loot condition types

| Condition | Tests |
|---|---|
| `entity_properties` | `entity` (`this`, `attacker`, `direct_attacker`, `attacking_player`) matches an entity predicate |
| `entity_scores` | scores of that entity: `{"scores":{"pw.mana":{"min":10}}}` |
| `random_chance` | `chance` 0..1 (number provider) |
| `random_chance_with_enchanted_bonus` | chance depending on an enchantment level |
| `time_check` | `value` range of day time, `period` (24000 for time of day) |
| `weather_check` | `raining`, `thundering` |
| `location_check` | location predicate at an `offsetX/Y/Z` |
| `block_state_property` | block and states (block loot) |
| `match_tool` | item predicate on the tool |
| `damage_source_properties` | damage source predicate |
| `killed_by_player`, `survives_explosion`, `table_bonus`, `enchantment_active_check` | loot contexts |
| `value_check` | number provider within range (e.g. a score or storage value) |
| `all_of`, `any_of`, `inverted`, `reference` | combinators and references to other predicate files |

## Entity predicate fields

`type`, `type_specific`, `team`, `nbt`, `location`, `stepping_on`, `movement_affected_by`, `distance`, `flags` (`is_on_fire is_sneaking is_sprinting is_swimming is_baby is_on_ground is_flying`), `equipment` (`mainhand offhand head chest legs feet body saddle` -> item predicate), `slots` (`"weapon.*"` -> item predicate), `effects`, `vehicle`, `passenger`, `targeted_entity`, `movement` (`x y z speed horizontal_speed vertical_speed fall_distance`), `periodic_tick`, `components`, `predicates`. Full: `pw schema type OldEntityPredicate`.

`type_specific` (`pw schema sub_predicate`): `player` (`gamemode`, `level`, `advancements`, `recipes`, `stats`, `looking_at`, `input`), `fishing_hook`, `lightning`, `raider`, `sheep`, `slime`. Mob variants are matched through `components` (e.g. `"minecraft:cat/variant"`).

### Player input (movement keys)

The `input` sub-predicate reads which movement keys a player holds: `forward backward left right jump sneak sprint`. Ideal for directional dashes and combo inputs.

```json predicate
{"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","input":{"sneak":true,"jump":true}}}}
```

## Examples

```json predicate
{"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_sneaking":true}}}
```

```json predicate
{"condition":"minecraft:entity_properties","entity":"this","predicate":{"type_specific":{"type":"minecraft:player","looking_at":{"type":"minecraft:zombie","nbt":"{Tags:[\"pw.boss\"]}"}}}}
```

```json predicate
[{"condition":"minecraft:entity_properties","entity":"this","predicate":{"location":{"dimension":"minecraft:the_nether"},"movement":{"vertical_speed":{"min":0.5}}}},{"condition":"minecraft:random_chance","chance":0.25}]
```

```json predicate
{"condition":"minecraft:entity_properties","entity":"this","predicate":{"periodic_tick":20,"stepping_on":{"block":{"blocks":"#minecraft:logs"}},"slots":{"armor.*":{"items":"minecraft:leather_boots"}}}}
```

```json predicate
{"condition":"minecraft:entity_scores","entity":"this","scores":{"pw.mana":{"min":20},"pw.cd":0}}
```

```json predicate
{"condition":"minecraft:time_check","value":{"min":13000,"max":23000},"period":24000}
```

Inline in a command:

```mcfunction
execute as @a if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_sprinting:true}}} run effect give @s minecraft:speed 1 0 true
execute if predicate {condition:"minecraft:random_chance",chance:0.1} run say lucky
execute as @a[predicate=pw:sneak_jump] at @s run function pw:skill/leap
```

`looking_at` tests the entity the player is aiming at (line of sight, up to about 100 blocks), an easy "aim at target" check without a raycast.
