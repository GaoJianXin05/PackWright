# Custom enchantments

`data/<ns>/enchantment/<name>.json`. Since 1.21 enchantments are data: an enchantment is a set of effect components that the game evaluates for the item's holder. Custom enchantments are the most powerful vanilla hook: they modify damage, armor, attributes, projectiles, and run functions with proper attacker/victim context.

## Shape

| Field | Meaning |
|---|---|
| `description` | name shown in the tooltip (text component) |
| `supported_items` | item, list or `#tag` that can carry it |
| `primary_items` | items it can appear on at the table (optional) |
| `exclusive_set` | incompatible enchantments |
| `weight` 1..1024, `max_level` 1..255, `min_cost`/`max_cost` `{base,per_level_above_first}`, `anvil_cost` | table and anvil numbers |
| `slots` | where it is active: `any mainhand offhand hand head chest legs feet armor body saddle` |
| `effects` | effect component map |

Availability in enchanting tables, villager trades, loot and random enchants comes from enchantment tags (`#minecraft:in_enchanting_table`, `#minecraft:tradeable`, `#minecraft:on_random_loot`, `#minecraft:non_treasure`, `#minecraft:treasure`, `#minecraft:curse`...). Leave a hook enchantment out of all of them and give it only by command.

## Effect components (1.21.8)

| Group | Components |
|---|---|
| Value effects (change a number; `effect` = `add multiply set remove_binomial all_of`, each with a level-based `value`) | `damage`, `damage_protection`, `smash_damage_per_fallen_block`, `knockback`, `armor_effectiveness`, `item_damage`, `ammo_use`, `projectile_piercing`, `projectile_count`, `projectile_spread`, `trident_return_acceleration`, `trident_spin_attack_strength`, `fishing_time_reduction`, `fishing_luck_bonus`, `block_experience`, `mob_experience`, `repair_with_xp`, `crossbow_charge_time`, `equipment_drops` |
| Entity effects (do something; `post_attack` has `enchanted`/`affected` roles) | `post_attack`, `hit_block`, `projectile_spawned`, `tick` |
| Location effects (applied while in a location, reverted when leaving) | `location_changed` |
| Attributes (while equipped) | `attributes` |
| Flags | `damage_immunity`, `prevent_equipment_drop`, `prevent_armor_change` |
| Sounds | `crossbow_charging_sounds`, `trident_sound` |

Most value and entity effects take `requirements` (loot conditions evaluated with the enchantment context: `this`, `attacker`, `direct_attacker`, `damage_source`, `enchantment_level`).

Entity effects: `run_function`, `apply_mob_effect`, `damage_entity`, `explode`, `ignite`, `play_sound`, `spawn_particles`, `summon_entity`, `replace_block`, `replace_disk`, `set_block_properties`, `change_item_damage`, `all_of`. Location effects add `attribute`.

Level-based values: a number, or `{"type":"linear","base":2,"per_level_above_first":1}`, `clamped`, `fraction`, `levels_squared`, `lookup`.

## Examples

Extra damage against undead plus a lightning hit on crit-like condition:

```json enchantment
{"description":{"text":"Smite Storm","color":"aqua"},"supported_items":"#minecraft:enchantable/sword","weight":2,"max_level":3,"min_cost":{"base":10,"per_level_above_first":8},"max_cost":{"base":40,"per_level_above_first":8},"anvil_cost":4,"slots":["mainhand"],"effects":{"minecraft:damage":[{"requirements":{"condition":"minecraft:entity_properties","entity":"this","predicate":{"type":"#minecraft:undead"}},"effect":{"type":"minecraft:add","value":{"type":"minecraft:linear","base":2.5,"per_level_above_first":2.5}}}],"minecraft:post_attack":[{"enchanted":"attacker","affected":"victim","requirements":{"condition":"minecraft:random_chance","chance":0.2},"effect":{"type":"minecraft:summon_entity","entity":"minecraft:lightning_bolt"}}]}}
```

Lifesteal through a function (the function runs as the attacker because `affected` is `attacker`):

```json enchantment
{"description":"Lifesteal","supported_items":"#minecraft:enchantable/weapon","weight":1,"max_level":1,"min_cost":{"base":1,"per_level_above_first":0},"max_cost":{"base":1,"per_level_above_first":0},"anvil_cost":0,"slots":["mainhand"],"effects":{"minecraft:post_attack":[{"enchanted":"attacker","affected":"attacker","effect":{"type":"minecraft:run_function","function":"pw:ench/lifesteal"}}]}}
```

Armor that makes the wearer immune to fall damage and faster while sneaking:

```json enchantment
{"description":"Featherstep","supported_items":"#minecraft:enchantable/foot_armor","weight":1,"max_level":1,"min_cost":{"base":1,"per_level_above_first":0},"max_cost":{"base":1,"per_level_above_first":0},"anvil_cost":0,"slots":["feet"],"effects":{"minecraft:damage_immunity":[{"requirements":{"condition":"minecraft:damage_source_properties","predicate":{"tags":[{"id":"minecraft:is_fall","expected":true}]}},"effect":{}}],"minecraft:attributes":[{"attribute":"minecraft:sneaking_speed","id":"pw:featherstep","amount":0.3,"operation":"add_value"}]}}
```

Area pulse every second while held (`tick` runs every tick; `periodic_tick` on the entity predicate throttles it):

```json enchantment
{"description":"Pulse","supported_items":"minecraft:blaze_rod","weight":1,"max_level":1,"min_cost":{"base":1,"per_level_above_first":0},"max_cost":{"base":1,"per_level_above_first":0},"anvil_cost":0,"slots":["mainhand"],"effects":{"minecraft:tick":[{"requirements":{"condition":"minecraft:entity_properties","entity":"this","predicate":{"periodic_tick":20}},"effect":{"type":"minecraft:run_function","function":"pw:ench/pulse"}}]}}
```

Apply with `give @s minecraft:blaze_rod[enchantments={"pw:pulse":1}]`. Hide the tooltip line with `tooltip_display={hidden_components:["minecraft:enchantments"]}` if it is a hidden mechanic.
