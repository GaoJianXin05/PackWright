# Recipes and other data-driven registries

## Recipes

`data/<ns>/recipe/<name>.json`. Ingredients (1.21.2+) are an item id string, a `#tag` string, or a list of item ids. Results are item stacks `{"id":..,"count":..,"components":{..}}`, so recipes can output fully custom items.

| `type` | Fields |
|---|---|
| `crafting_shaped` | `pattern` (1-3 rows of equal width, 1-3 chars), `key` (char -> ingredient), `result`, `category`, `show_notification` |
| `crafting_shapeless` | `ingredients` (1..9), `result` |
| `crafting_transmute` | `input`, `material`, `result`: copies the input's components onto the result (dyeing, upgrades) |
| `smelting`, `blasting`, `smoking`, `campfire_cooking` | `ingredient`, `result`, `experience`, `cookingtime` |
| `stonecutting` | `ingredient`, `result` |
| `smithing_transform` | `template`, `base`, `addition`, `result` (keeps base components) |
| `smithing_trim` | `template`, `base`, `addition`, `pattern` |
| `crafting_special_*`, `crafting_decorated_pot` | built-in special recipes, `category` only |

```json recipe
{"type":"minecraft:crafting_shaped","category":"equipment","pattern":[" E ","EBE"," S "],"key":{"E":"minecraft:echo_shard","B":"minecraft:blaze_rod","S":"#minecraft:soul_fire_base_blocks"},"result":{"id":"minecraft:carrot_on_a_stick","count":1,"components":{"minecraft:custom_data":{"pw":{"id":"storm_blade"}},"minecraft:item_model":"minecraft:diamond_sword","minecraft:item_name":{"text":"Storm Blade","color":"aqua"},"minecraft:max_stack_size":1}}}
```

```json recipe
{"type":"minecraft:crafting_shapeless","ingredients":["minecraft:apple","minecraft:gold_nugget","minecraft:gold_nugget"],"result":{"id":"minecraft:apple","components":{"minecraft:item_name":"Lucky Apple","minecraft:food":{"nutrition":6,"saturation":8,"can_always_eat":true}}}}
```

```json recipe
{"type":"minecraft:smithing_transform","template":"minecraft:netherite_upgrade_smithing_template","base":"minecraft:carrot_on_a_stick","addition":"minecraft:nether_star","result":{"id":"minecraft:carrot_on_a_stick","components":{"minecraft:item_name":{"text":"Storm Blade II","color":"light_purple"}}}}
```

- Recipes match item types only, not components. To restrict a recipe to your custom item, use `crafting_transmute`/`smithing_transform` (which keep the input's components) and check the result in functions, or catch `recipe_crafted`/`inventory_changed` and fix the item afterwards.
- Unlocking: `recipe give @s pw:storm_blade`, or reward `recipes` in an advancement. With `doLimitedCrafting` only unlocked recipes can be crafted.
- Override a vanilla recipe by writing `data/minecraft/recipe/<same name>.json`.

## Damage types

Custom damage types give custom death messages and tag-based behavior (bypasses armor, fire, projectile...).

```json damage_type
{"message_id":"pw.storm","exhaustion":0.1,"scaling":"when_caused_by_living_non_player","effects":"hurt"}
```

Death message keys are `death.attack.<message_id>` and `death.attack.<message_id>.player`; without a resource pack the raw key is shown, so pick a `message_id` of a vanilla type for readable messages (e.g. `"magic"`, `"lightningBolt"`) or ship a resource pack lang file. Use: `damage @s 6 pw:storm by @p`. Add it to tags like `#minecraft:bypasses_armor`, `#minecraft:is_lightning`, `#minecraft:no_knockback`, `#minecraft:bypasses_shield`, `#minecraft:is_projectile` for behavior (`pw tag damage_type`). The game also checks `#minecraft:bypasses_cooldown` (hits of these types ignore the 10-tick hurt cooldown), but vanilla 1.21.8 has no such tag file: a pack that needs rapid repeated hits creates `data/minecraft/tags/damage_type/bypasses_cooldown.json` with its own damage types.

## Other registries packs commonly add

| Folder | Use |
|---|---|
| `jukebox_song` | music discs with custom sound events (needs resource pack sounds) |
| `painting_variant` | paintings (texture from resource pack) |
| `trim_pattern`, `trim_material` | armor trims |
| `instrument` | goat horn sounds |
| `banner_pattern` | banner patterns |
| `chat_type` | chat formats for `/say`-like messages |
| `wolf_variant`, `wolf_sound_variant`, `cat_variant`, `pig_variant`, `cow_variant`, `chicken_variant`, `frog_variant` | mob variants (spawn conditions by biome) |
| `enchantment`, `enchantment_provider` | see enchantments.md |
| `dialog` | see dialogs.md |
| `dimension`, `dimension_type`, `worldgen/*` | custom dimensions and world generation |
| `structure` (`.nbt`) | structures for `place template`, jigsaw, structure blocks |
| `test_instance`, `test_environment` | GameTest with `/test` |
| `trial_spawner` | trial spawner configurations |

Look at the vanilla files for any of these with `pw vanilla <folder>` and `pw vanilla <path>`; copying a vanilla file and editing it is the fastest correct start.
