# Advancements

`data/<ns>/advancement/<path>.json`. Used both as visible goals and, much more often in packs, as invisible event listeners that run a function.

## Shape

```json advancement
{"display":{"icon":{"id":"minecraft:nether_star","components":{"minecraft:enchantment_glint_override":true}},"title":{"text":"Storm Caller","color":"aqua"},"description":"Defeat the Storm King","frame":"challenge","show_toast":true,"announce_to_chat":true,"hidden":false},"parent":"pw:root","criteria":{"kill":{"trigger":"minecraft:player_killed_entity","conditions":{"entity":{"type":"minecraft:wither_skeleton","nbt":"{Tags:[\"pw.storm_king\"]}"}}}},"rewards":{"experience":100,"loot":["pw:rewards/storm_king"],"function":"pw:boss/reward"}}
```

- `criteria`: name -> `{trigger, conditions}`. `requirements` (optional) is a list of OR-groups that are ANDed: `[["a","b"],["c"]]` means (a or b) and c. Default: all criteria.
- `display` is optional; without it the advancement is invisible and never toasts. A root advancement (no `parent`) with display needs `background` only if you want a custom tab background.
- `rewards`: `function`, `loot`, `experience`, `recipes`.
- `sends_telemetry_event` exists but is irrelevant for packs.

## Event listener pattern

```json advancement
{"criteria":{"hit":{"trigger":"minecraft:player_hurt_entity","conditions":{"entity":{"type":"#minecraft:undead"},"damage":{"type":{"is_direct":true}}}}},"rewards":{"function":"pw:events/hit_undead"}}
```

```mcfunction
advancement revoke @s only pw:events/hit_undead
execute as @e[type=#minecraft:undead,distance=..6,nbt={HurtTime:10s},limit=1,sort=nearest] run function pw:events/smite
```

Revoke first so it can trigger again. The reward function runs as the player, at the player. To find the entity that was hit, use `on attacker` from candidates, `HurtTime`, or an enchantment `post_attack` hook (more precise, see items/custom-items.md).

## Trigger reference (57 in 1.21.8)

Every trigger accepts `player` (entity predicate or list of loot conditions on the player). Others:

| Trigger | Fires when | Extra conditions |
|---|---|---|
| `tick` | every tick for every player | `player` only; prefer the tick function |
| `location` | about once per second per player | `player` (with `location`) |
| `impossible` | never (only `/advancement grant`) | |
| `player_hurt_entity` | player damages an entity | `entity`, `damage` |
| `entity_hurt_player` | an entity damages the player | `damage` |
| `player_killed_entity` | player kills | `entity`, `killing_blow` |
| `entity_killed_player` | player dies to an entity | `entity`, `killing_blow` |
| `killed_by_arrow` | one arrow kills several | `victims`, `unique_entity_types`, `fired_from_weapon` |
| `player_interacted_with_entity` | right-click an entity (including `interaction`) | `item`, `entity` |
| `using_item` | each tick while using an item (eating, bow, consumable) | `item` |
| `consume_item` | finishes consuming | `item` |
| `item_used_on_block` | uses an item on a block | `location` (loot conditions with `match_tool`, `location_check`, `block_state_property`) |
| `default_block_use`, `any_block_use` | right-clicks a block (default action / any) | `location` |
| `placed_block` | places a block | `location` |
| `inventory_changed` | inventory changes | `items`, `slots` |
| `item_durability_changed` | item takes damage | `item`, `durability`, `delta` |
| `enchanted_item` | enchants at a table | `item`, `levels` |
| `filled_bucket`, `shot_crossbow`, `used_totem`, `used_ender_eye` | | `item` / `distance` |
| `changed_dimension` | | `from`, `to` |
| `effects_changed` | effects change | `effects`, `source` |
| `fall_from_height`, `ride_entity_in_lava`, `nether_travel` | distance based | `start_position`, `distance` |
| `levitation` | | `distance`, `duration` |
| `slept_in_bed`, `hero_of_the_village`, `voluntary_exile` | | |
| `started_riding` | mounts | |
| `summoned_entity` | builds a golem/wither, or summons via item | `entity` |
| `tame_animal`, `bred_animals` | | `entity` / `parent`, `partner`, `child` |
| `target_hit` | hits a target block | `signal_strength`, `projectile` |
| `lightning_strike`, `channeled_lightning` | | `lightning`, `bystander` / `victims` |
| `thrown_item_picked_up_by_entity`, `thrown_item_picked_up_by_player` | | `item`, `entity` |
| `villager_trade` | | `villager`, `item` |
| `recipe_unlocked`, `recipe_crafted`, `crafter_recipe_crafted` | | `recipe_id`, `ingredients` |
| `fishing_rod_hooked` | | `rod`, `entity`, `item` |
| `brewed_potion`, `construct_beacon`, `cured_zombie_villager`, `bee_nest_destroyed`, `allay_drop_item_on_block`, `avoid_vibration`, `kill_mob_near_sculk_catalyst`, `slide_down_block`, `enter_block`, `player_generates_container_loot`, `fall_after_explosion`, `player_sheared_equipment` (1.21.6) | | see `pw schema trigger <name>` |

Entity conditions (`entity`, `player`, ...) are an entity predicate object or a list of loot conditions: see predicates.md.

## Commands

```mcfunction
advancement grant @s only pw:quests/first_blood
advancement revoke @a from pw:quests/root
advancement revoke @s only pw:events/hit_undead hit
execute if entity @s[advancements={pw:quests/first_blood=true}] run say done
```

Hide the vanilla advancement UI noise for listener advancements by giving them no `display`. Keep listener advancements in a folder like `pw:events/`.
