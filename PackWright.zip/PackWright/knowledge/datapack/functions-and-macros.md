# Functions and macros

## Function files

- One command per line, no leading `/`. Lines starting with `#` are comments. A line ending in `\` continues on the next line.
- A function runs all its commands in the same tick, in order, with the caller's context (executor, position, rotation, dimension). An `execute` on one line does not change the context of later lines.
- If any non-macro line fails to parse, the whole function is not loaded and calling it reports "Unknown function". `pw check` finds these lines.
- Functions started from `#minecraft:tick`, `#minecraft:load` or `schedule` have no executor and run at the world spawn: `@s` selects nothing and `~ ~ ~` is the spawn point. Wrap entity work: `execute as @a at @s run function ns:player/tick`.
- Call: `function pw:skill/fire`, `execute as @a at @s run function pw:player_tick`, from tags (`function #pw:on_hit`), advancement rewards, enchantment `run_function`, `schedule function`.
- Order inside a tick: `#minecraft:tick` functions first, then the dimensions tick (due `schedule`d functions, block ticks, entities, then block entities such as command blocks). Advancement reward functions and enchantment `run_function` effects run at the moment their event fires, so they can land anywhere in that sequence.
- Limits: `maxCommandChainLength` (65536 commands per call chain) and `maxCommandForkCount` (65536 execute branches). Recursion is allowed; stop it with a condition or counter.
- Functions run with permission level 2 (`function-permission-level` on servers).

## Return values

```mcfunction
execute unless entity @s[type=minecraft:player] run return fail
execute if score @s pw.mana matches ..9 run return 0
return run scoreboard players get @s pw.mana
```

- `return <n>`, `return fail`, `return run <cmd>` (result and success of the command). Without a `return`, a function has no return value.
- `execute store result score @s x run function pw:f` stores the return value.
- `execute if function pw:f` passes when the function returns non-zero.

## Macros (1.20.2+)

A line starting with `$` is a macro line. `$(name)` is replaced by the value of `name` from the arguments before the line is parsed.

```mcfunction
$summon minecraft:lightning_bolt $(x) $(y) $(z)
$particle minecraft:dust{color:[$(r),$(g),$(b)],scale:1.0} ~ ~1 ~ 0.3 0.3 0.3 0 $(count)
$scoreboard players set @s pw.cd $(cooldown)
$tellraw @a {text:"$(name) used $(skill)!",color:"gold"}
$execute as @e[tag=pw.id_$(id)] run tag @s add pw.selected
```

Calling:

```mcfunction
function pw:fx/strike {x:10,y:64,z:-3}
function pw:fx/strike with storage pw:tmp pos
function pw:fx/strike with entity @s data.pw
function pw:fx/strike with block ~ ~ ~ components
```

Rules:

- Arguments must be a compound; with `with ... <path>` the path must point at a compound. Extra keys are ignored.
- Variable names: letters, digits, `_`.
- Substitution: strings are inserted without quotes; numbers as plain text without suffix (`10b` becomes `10`, floats up to 15 decimals); booleans as `1`/`0`; lists and compounds as SNBT.
- If a variable is missing or a substituted line does not parse, the whole function call fails and no line of it runs.
- Macro lines are re-parsed on every call, so they cost more than normal lines. Keep the macro function small: compute in normal functions, store into `pw:tmp`, then call a tiny macro function.
- A function with macro lines must be called with arguments; `function pw:fx/strike` alone fails.
- To quote a string value inside SNBT, put the quotes in the macro line: `$data modify storage pw:tmp name set value "$(name)"`.

## Common macro uses

| Need | Macro |
|---|---|
| Coordinates from scores | store scores into storage (`execute store result storage pw:tmp p.x int 1 run scoreboard players get @s pw.x`) then `$tp @s $(x) $(y) $(z)` |
| Dynamic selector by id | `$execute as @e[tag=pw.id,scores={pw.id=$(id)}] run ...` |
| Per-player storage slot | `$data modify storage pw:players "$(uuid)" set from storage pw:tmp record` |
| Variable damage | `$damage @s $(amount) minecraft:magic by @p` |
| Index into a list | `$data modify storage pw:tmp pick set from storage pw:cfg list[$(i)]` |
| Data-driven dispatch | `$function pw:skills/$(skill)` |

## Scheduling

```mcfunction
schedule function pw:boss/phase2 100t
schedule function pw:loop 1s replace
schedule clear pw:loop
```

`append` keeps earlier schedules of the same function, `replace` (default) overwrites. Scheduled functions run at world spawn with no executor: select entities explicitly (`execute as @e[tag=pw.boss] at @s run ...`).

## Writing quality functions

- One responsibility per function, folders per feature: `pw:blade/use`, `pw:blade/skill/dash`, `pw:boss/phase/1`.
- Gate early: `execute unless ... run return 0` at the top keeps later lines simple.
- Tick: `execute as @a at @s run function pw:player/tick` once, then cheap score checks inside. Never run heavy work for every entity every tick.
- Use scores for numbers, tags for flags, storage for structured data, `data` on markers for per-entity extras.
- Make `load` idempotent and namespaced; add an uninstall function that removes objectives, teams, bossbars and storage.
- Comment lines are fine and cost nothing at runtime.
