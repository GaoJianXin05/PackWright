# NBT, SNBT, /data and storage

## SNBT (1.21.5+ rules)

- Compound `{key:value,...}`, list `[a,b]` (mixed element types are allowed since 1.21.5), arrays `[B;1b,2b]`, `[I;1,2,3,4]`, `[L;1L]`.
- Numbers: `1b` byte, `1s` short, `1` int, `1L` long, `1.5f` float, `1.5` or `1.5d` double. `0x1F` hex and `0b101` binary integers, `_` separators (`1_000`).
- Booleans: `true`/`false` (stored as byte 1/0). `bool(x)` converts a number. `uuid("f81d4fae-7dec-11d0-a765-00a0c91e6bf6")` gives the 4-int UUID array.
- Strings: `"double"` or `'single'` quotes. Unquoted strings may contain only `0-9 A-Z a-z _ - . +` and should not start with a digit, `+`, `-` or `.`; quote anything with `:`, spaces or non-ASCII (`"minecraft:stone"`, `"Storm Blade"`, `"café"`).
- Escapes in quoted strings: `\\ \" \' \n \t \xXX \uXXXX \N{name}`.

Entity and block NBT field names are case-sensitive and differ per entity: `pw schema entity <id> --flat` lists them.

## /data

```mcfunction
data get entity @s Health
data get entity @s Pos[1] 100
data get entity @s SelectedItem.components."minecraft:custom_data"
data merge entity @e[type=minecraft:zombie,limit=1,sort=nearest] {NoAI:true,Silent:true}
data modify entity @s Motion set value [0.0d,1.2d,0.0d]
data modify storage pw:state players append value {name:"x",score:0}
data modify storage pw:state list prepend value 1
data modify storage pw:state list insert 2 value 7
data modify storage pw:state copy set from entity @s Inventory
data modify storage pw:state name set string entity @s CustomName
data modify storage pw:state first3 set string storage pw:state name 0 3
data modify storage pw:state a merge value {extra:1b}
data remove storage pw:state players[0]
data remove entity @s data.pw
```

- `data get` returns the value (numbers scaled and truncated to int, lists and compounds return their size, strings their length) and prints it; use it in `execute store`.
- `set from` copies a tag, `set value` writes SNBT, `set string <source> <path> [start] [end]` copies a substring (negative indices count from the end).
- Players: `data get entity @p ...` works, `data modify/merge entity <player>` fails. Change players through commands (`attribute`, `effect`, `item`, `tp`, `xp`, `gamemode`) or their scores.
- Entity `data` is a free compound for your own data on marker and other entities: `data merge entity @s {data:{pw:{hp:10}}}`. It is saved with the entity. Commands cannot write player NBT, so for players keep the data in scores or in storage keyed by id.

## NBT paths

| Form | Meaning |
|---|---|
| `a.b.c` | nested keys |
| `"minecraft:custom_data"` | quote keys with `:` or other special characters |
| `list[0]`, `list[-1]` | element by index (negative from the end) |
| `list[]` | every element |
| `list[{id:"minecraft:stone"}]` | elements matching a compound |
| `{Tags:["x"]}` / `a{b:1}` | the tag itself only if it matches |

Inventory example: `Inventory[{Slot:0b}]`, held item `SelectedItem`, item custom data `SelectedItem.components."minecraft:custom_data".pw`.

## Storage

Storage is a global, persistent, namespaced NBT store (`pw:state`, `pw:tmp`). It is the right place for configuration, lists, macro argument bundles and temporary data. It is saved with the world.

```mcfunction
data modify storage pw:tmp args set value {x:0,y:64,z:0,radius:5}
execute store result storage pw:tmp args.x int 1 run data get entity @s Pos[0]
function pw:blast with storage pw:tmp args
data remove storage pw:tmp args
```

## Converting between scores and NBT

```mcfunction
execute store result score @s pw.hp run data get entity @s Health 10
execute store result storage pw:tmp v double 0.1 run scoreboard players get @s pw.hp
execute store result entity @e[tag=pw.target,limit=1] Health float 0.1 run scoreboard players get #boss pw.hp
```

The scale multiplies on the way in (`data get ... 10`) and on the way out (`store ... 0.1`).

## Performance

- Reading NBT is far slower than scores. Never put `nbt=` in a selector that runs every tick over many entities; use tags, scores, `type=`, predicates or `execute if items`.
- `data get entity @s Inventory` on players copies the whole inventory. Use `execute if items entity @s container.* <predicate>` to test items.
- Cache values in scores if they are read often.
