# Scoreboard

Scores are 32-bit signed integers (-2147483648..2147483647) held by an entity (by UUID), a player name, or a fake player name such as `#tmp` or `$x`. Names starting with `#` are hidden from the sidebar. All math is integer math.

## Objectives

```mcfunction
scoreboard objectives add pw.cd dummy
scoreboard objectives add pw.click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add pw.kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add pw.deaths deathCount
scoreboard objectives add pw.hp health {text:"HP",color:"red"}
scoreboard objectives add pw.menu trigger
scoreboard objectives setdisplay sidebar pw.kills
scoreboard objectives setdisplay below_name pw.hp
scoreboard objectives modify pw.kills displayname {text:"Kills",color:"gold"}
scoreboard objectives modify pw.hp rendertype hearts
scoreboard objectives modify pw.kills numberformat styled {color:"yellow"}
```

Objective names: letters, digits and `_ - . +`, no spaces. Older versions limited them to 16 characters; 1.21.8 does not. Prefix them with your namespace (`pw.cd`) to avoid clashes with other packs.

`pw check` accepts names such as `金币` for objectives, teams, tags and fake players; `--strict-names` limits them to `A-Za-z0-9_-.+`. The name players see is the display name: `scoreboard objectives add pw.gold dummy {text:"金币",color:"gold"}`.

### Criteria

| Criterion | Counts |
|---|---|
| `dummy` | only changed by commands |
| `trigger` | like dummy, but players can run `/trigger <obj>` without op once enabled |
| `deathCount`, `playerKillCount`, `totalKillCount` | deaths and kills |
| `health`, `food`, `air`, `armor`, `level`, `xp` | read-only mirrors of the player |
| `teamkill.<color>`, `killedByTeam.<color>` | team kills |
| `minecraft.<stat_type>:minecraft.<id>` | statistics: `mined` (block), `crafted`, `used`, `broken`, `picked_up`, `dropped` (item), `killed`, `killed_by` (entity), `custom` (custom stat) |

Common custom stats: `minecraft.custom:minecraft.jump`, `sneak_time`, `walk_one_cm`, `sprint_one_cm`, `damage_dealt`, `damage_taken`, `mob_kills`, `play_time`, `time_since_death`, `time_since_rest`, `leave_game`, `talked_to_villager`, `interact_with_crafting_table`. List them with `pw id custom_stat`.

`minecraft.used:minecraft.carrot_on_a_stick` (and `warped_fungus_on_a_stick`) increments on every right click and is the classic right-click detector. Reset it after reading.

Display slots: `list`, `sidebar`, `below_name`, `sidebar.team.<color>`.

## Players

```mcfunction
scoreboard players set @s pw.cd 40
scoreboard players add @s pw.mana 5
scoreboard players remove @a[scores={pw.cd=1..}] pw.cd 1
scoreboard players reset @s pw.click
scoreboard players reset * pw.tmp
scoreboard players get @s pw.mana
scoreboard players enable @a pw.menu
scoreboard players display name @s pw.kills {text:"You",color:"aqua"}
scoreboard players display numberformat #total pw.kills fixed {text:"-"}
```

`reset` removes the score entirely, so `scores={x=0}` no longer matches; `unless score @s x matches -2147483648..` detects "no score".

### operation

`scoreboard players operation <target> <obj> <op> <source> <obj>`

| op | effect |
|---|---|
| `=` | copy |
| `+=` `-=` `*=` | arithmetic |
| `/=` | floor division (rounds toward negative infinity); dividing by 0 makes the command fail ("Cannot divide by zero") |
| `%=` | modulo, result is never negative for a positive divisor; modulo 0 fails |
| `<` | target = min(target, source) |
| `>` | target = max(target, source) |
| `><` | swap |

Constants must be stored as scores first:

```mcfunction
scoreboard players set #100 pw.const 100
scoreboard players set #2 pw.const 2
scoreboard players operation @s pw.tmp = @s pw.mana
scoreboard players operation @s pw.tmp *= #100 pw.const
scoreboard players operation @s pw.tmp /= @s pw.max_mana
```

Multiply before dividing to keep precision. To work with decimals, use fixed point: store `value * 1000` and scale when reading or writing NBT with `execute store ... <scale>` and `data get ... <scale>`.

## Selectors with scores

`@a[scores={pw.cd=1..,pw.mana=..9}]`. Every listed objective must match. A player without a score never matches any range.

## trigger: buttons for non-op players

```mcfunction
scoreboard objectives add pw.menu trigger
scoreboard players enable @a pw.menu
tellraw @a {text:"[Open shop]",color:"green",click_event:{action:"run_command",command:"trigger pw.menu set 1"}}
execute as @a[scores={pw.menu=1}] run function pw:shop/open
scoreboard players set @a[scores={pw.menu=1..}] pw.menu 0
scoreboard players enable @a pw.menu
```

`enable` has to be repeated after each use, because running `/trigger` disables it for that player.

## Random numbers

```mcfunction
execute store result score @s pw.roll run random value 1..100
```

`random value` is silent; `random roll` also announces the result in chat. A named sequence (`random value 1..6 pw:dice`) gives a reproducible stream.

## Linking entities to players

Scores follow entities, so a shared id links them:

```mcfunction
scoreboard players add #next pw.id 1
scoreboard players operation @s pw.id = #next pw.id
execute as @e[type=minecraft:wolf,tag=pw.pet] if score @s pw.id = @p pw.id run tag @s add pw.mine
```

To find "the entity whose id equals mine", compare with `if score @s pw.id = <other> pw.id` inside `as @e[...]`, or use a macro with the stored id. Player UUID-to-entity links can also use `on owner`, `on origin` or the `Owner` NBT.

## Patterns

- Cooldown: set a score to N ticks and decrement every tick while `1..`.
- Timer: `scoreboard players add #timer pw.tmp 1` then `execute if score #timer pw.tmp matches 20.. run ...` and reset.
- Once-per-event: compare with a previous value score; act when different, then copy.
- Global state flags live on fake players (`#phase pw.boss`), per-player state on `@s`.
- Read world time without ticking a counter: `execute store result score #now pw.tmp run time query gametime`.
