# Text components (1.21.5+ format)

Used by `tellraw`, `title`, `bossbar`, `scoreboard ... displayname`, `custom_name`, `item_name`, `lore`, written books, signs, text displays, dialogs, advancement titles and `pack.mcmeta` descriptions.

- In commands and SNBT (item components, entity NBT): write SNBT, `{text:"Hi",color:"gold"}`.
- In `.json` files: write JSON, `{"text":"Hi","color":"gold"}`.
- A string that merely contains JSON is not parsed (1.21.5+): `CustomName:'{"text":"Hi"}'` or `custom_name='{"text":"Hi"}'` show the braces and quotes on screen. Write the compound `{text:"Hi"}`.
- A plain string `"Hi"` and a list `["a",{text:"b"}]` are also components. In a list, the first element's style is inherited by the rest; start with `""` to avoid that: `["",{text:"a",color:"red"},{text:"b"}]`.

Full schema: `pw schema type TextObject --flat`.

## Content types

| Key | Shows |
|---|---|
| `text:"..."` | literal text |
| `translate:"key"`, `with:[...]`, `fallback:"..."` | translated text, `%s` filled from `with` (`pw lang <words>` finds keys) |
| `score:{name:"@s",objective:"pw.kills"}` | a score (`name` can be a selector resolving to one entity, `*` for the viewer) |
| `selector:"@e[type=minecraft:zombie]"`, `separator` | entity names, hoverable |
| `keybind:"key.jump"` | the viewer's key for an action |
| `nbt:"path"` with `entity:"@s"` / `block:"x y z"` / `storage:"pw:x"`, `interpret:true`, `separator` | NBT value; `interpret` renders it as a text component |

## Style

`color` (`black dark_blue dark_green dark_aqua dark_red dark_purple gold gray dark_gray blue green aqua red light_purple yellow white` or `"#RRGGBB"`), `shadow_color` (ARGB int or `[r,g,b,a]` floats), `font`, `bold`, `italic`, `underlined`, `strikethrough`, `obfuscated`, `insertion` (shift-click inserts text), `extra:[...]` children.

Names and lore of items are italic by default; add `italic:false`. `item_name` is not italic and cannot be renamed in an anvil, `custom_name` can.

## click_event

| action | fields |
|---|---|
| `run_command` | `command:"say hi"` (leading `/` optional); runs with the clicking player's permission level; since 1.21.6 chat and books ask for confirmation if the command does not parse or needs more permission |
| `suggest_command` | `command:"/msg "` puts text in the chat box |
| `open_url` | `url:"https://..."` |
| `copy_to_clipboard` | `value:"text"` |
| `change_page` | `page:2` (books only) |
| `show_dialog` | `dialog:"pw:menu"` or an inline dialog |
| `custom` | `id:"pw:event"`, optional `payload` (for servers/mods) |

Non-op players clicking `run_command` cannot run op commands. Use `trigger` objectives for player buttons (see scoreboard.md).

## hover_event

| action | fields |
|---|---|
| `show_text` | `value:<component>` |
| `show_item` | `id:"minecraft:diamond_sword"`, `count:1`, `components:{...}` |
| `show_entity` | `id:"minecraft:zombie"`, `uuid:"..."` or int array, `name:<component>` |

## Examples

```mcfunction
tellraw @a ["",{text:"[Boss] ",color:"dark_red",bold:true},{text:"The Warden King awakens",color:"red"}]
tellraw @s {text:"Mana: ",color:"aqua",extra:[{score:{name:"@s",objective:"pw.mana"},color:"white"},{text:"/100",color:"gray"}]}
tellraw @a {translate:"chat.type.announcement",with:[{text:"Server"},{text:"Restart soon"}]}
tellraw @s {text:"[Info]",color:"yellow",hover_event:{action:"show_text",value:[{text:"Line 1\n"},{text:"Line 2",color:"gray"}]}}
tellraw @s {text:"[Sword]",hover_event:{action:"show_item",id:"minecraft:diamond_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":5}}}}
tellraw @s {text:"[Wiki]",underlined:true,click_event:{action:"open_url",url:"https://minecraft.wiki"}}
tellraw @s {nbt:"players[0].name",storage:"pw:state"}
title @a times 10 40 10
title @a title {text:"Phase 2",color:"dark_purple",bold:true}
title @a subtitle {text:"The ground shakes",color:"gray"}
title @a actionbar [{text:"Cooldown: ",color:"gray"},{score:{name:"@s",objective:"pw.cd"},color:"yellow"}]
bossbar add pw:boss {text:"Warden King",color:"dark_red"}
bossbar set pw:boss color red
bossbar set pw:boss style notched_10
bossbar set pw:boss max 500
bossbar set pw:boss players @a[distance=..64]
```

`title ... actionbar` is the standard per-player HUD line. It stays about 2-3 seconds; refresh it every 10-20 ticks while needed.

Inside an item component or entity NBT the same SNBT applies:

```mcfunction
give @s minecraft:netherite_sword[item_name={text:"Stormbreaker",color:"aqua"},lore=[{text:"Right click: Thunder Dash",color:"gray",italic:false},{text:"Cooldown 5s",color:"dark_gray",italic:false}]]
summon minecraft:text_display ~ ~2 ~ {text:{text:"Shop",color:"gold",bold:true},billboard:"center",background:0}
```
