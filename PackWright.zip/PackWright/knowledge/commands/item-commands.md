# Item commands and item predicates

## Item stack argument (give, item replace ... with, summon item data)

`<id>[<component>=<snbt>,!<component>,...] [count]`

```mcfunction
give @s minecraft:diamond_sword[enchantments={sharpness:5,looting:3},unbreakable={}] 1
give @s minecraft:stick[custom_data={pw:{wand:"fire"}},item_model="minecraft:blaze_rod",max_stack_size=1]
give @s minecraft:bow[!enchantable,repair_cost=99]
give @s minecraft:player_head[profile={name:"Notch"}]
item replace entity @s armor.head with minecraft:carved_pumpkin[enchantments={binding_curse:1}]
item replace entity @s weapon.offhand with minecraft:totem_of_undying
item replace block ~ ~-1 ~ container.0 with minecraft:diamond 5
item replace entity @s hotbar.0 from entity @p weapon.mainhand
```

- Component keys may omit `minecraft:`. `!name` removes a default component.
- Components are merged onto the item's defaults (`pw item <id>` shows them).
- `give` drops overflow at the player's feet.

## Slots

| Slot | Meaning |
|---|---|
| `weapon`, `weapon.mainhand`, `weapon.offhand` | hands |
| `armor.head`, `armor.chest`, `armor.legs`, `armor.feet`, `armor.body` | armor; `armor.body` is horse/wolf/llama body armor |
| `saddle` | saddle slot (1.21.5+) |
| `hotbar.0`..`hotbar.8`, `inventory.0`..`inventory.26` | player inventory |
| `enderchest.0`..`enderchest.26` | ender chest |
| `container.0`..`container.53` | block containers, or the player's whole inventory |
| `horse.0`..`horse.14`, `horse.chest` | chested horse/llama inventory |
| `villager.0`..`villager.7` | villager inventory |
| `player.cursor`, `player.crafting.0`..`3` | player cursor and 2x2 crafting grid |
| `contents` | item entity, item frame, item display, jukebox... |

Ranges (`execute if items`, `item modify` does not take ranges): `container.*`, `hotbar.*`, `inventory.*`, `armor.*`, `weapon.*`, `enderchest.*`, `horse.*`, `villager.*`, `player.crafting.*`.

## Item predicates (execute if items, clear)

`<id | #tag | *>[<test>,<test>|<test>,...]`

| Test | Meaning |
|---|---|
| `component` | component present (even if default) |
| `!component` | absent |
| `component=<snbt>` | exact value |
| `predicate~<snbt>` | partial match through a data component predicate (`custom_data`, `damage`, `enchantments`, `stored_enchantments`, `potion_contents`, `attribute_modifiers`, `container`, `bundle_contents`, `firework_explosion`, `fireworks`, `jukebox_playable`, `trim`, `writable_book_content`, `written_book_content`) |
| `count~{min:2}` / `count=5` style | stack size test |
| `a\|b` | either test |
| `,` | all tests |

```mcfunction
execute if items entity @s weapon.mainhand minecraft:stick[custom_data~{pw:{wand:"fire"}}] run function pw:wand/fire
execute if items entity @s armor.* *[enchantments~[{enchantments:"minecraft:thorns"}]] run say thorny
execute if items entity @s container.* minecraft:emerald[count~{min:10}] run say rich
execute if items entity @s weapon.mainhand #minecraft:swords[!enchantments] run say plain sword
execute if items entity @s weapon.mainhand *[damage~{durability:{max:10}}] run title @s actionbar {text:"Your tool is about to break",color:"red"}
execute store result score @s pw.count if items entity @s container.* minecraft:gold_ingot
clear @s minecraft:emerald 10
clear @s *[custom_data~{pw:{quest_item:true}}]
clear @s minecraft:emerald 0
```

- `custom_data~{a:1}` matches if the item's custom data contains that subset; `custom_data={...}` needs the whole compound to be equal.
- `execute if items` returns the total count of matching items, so `store result` counts them.
- `clear <targets> <predicate> 0` only counts (removes nothing).
- `#minecraft:swords`, `#minecraft:enchantable/weapon` etc.: `pw tag item`.

## /item modify and item modifiers

`item modify entity|block <target> <slot> <modifier>` applies loot functions to the item in place. `<modifier>` is a file id (`pw:make_glow`) or inline SNBT (one function or a list):

```mcfunction
item modify entity @s weapon.mainhand {function:"minecraft:set_components",components:{"minecraft:enchantment_glint_override":true}}
item modify entity @s weapon.mainhand [{function:"minecraft:set_damage",damage:-0.1,add:true},{function:"minecraft:set_lore",lore:[{text:"Repaired",color:"green",italic:false}],mode:"append"}]
item modify entity @s weapon.mainhand {function:"minecraft:set_count",count:-1,add:true}
item modify entity @s weapon.mainhand {function:"minecraft:set_custom_data",tag:{pw:{charges:3}}}
item modify entity @s weapon.mainhand {function:"minecraft:copy_custom_data",source:{type:"minecraft:storage",source:"pw:tmp"},ops:[{source:"charges",target:"pw.charges",op:"replace"}]}
```

This is how you change an item a player is holding (counters on items, durability, renaming, lore updates). See `items/item-modifiers-and-loot.md`.

## /loot

```mcfunction
loot give @s loot pw:rewards/boss
loot spawn ~ ~1 ~ loot minecraft:chests/simple_dungeon
loot give @s mine ~ ~-1 ~ minecraft:diamond_pickaxe[enchantments={fortune:3}]
loot give @s kill @e[type=minecraft:zombie,limit=1,sort=nearest]
loot replace entity @s weapon.mainhand loot pw:upgrade/sword_t2
loot insert ~ ~ ~ loot pw:chest_fill
```

`loot` with a loot table that uses `set_components`, `set_name`, `set_lore`, `enchant_with_levels`, `set_count` is the cleanest way to create configurable items from functions.
