# /execute

Full tree: `pw usage execute`, `pw usage execute if --types`.

## Context model

Every command runs with a context: executor (`@s`), position, rotation, dimension, anchor (feet/eyes). `execute` subcommands are applied left to right and each one changes the context for what follows. A subcommand that selects several entities forks: everything after it runs once per entity.

| Subcommand | Changes |
|---|---|
| `as <targets>` | executor only (position stays) |
| `at <targets>` | position, rotation, dimension (executor stays) |
| `positioned <pos>` / `positioned as <targets>` / `positioned over <heightmap>` | position |
| `rotated <rot>` / `rotated as <targets>` | rotation |
| `facing <pos>` / `facing entity <targets> eyes\|feet` | rotation toward a point |
| `anchored eyes\|feet` | where `^ ^ ^` and `facing` measure from |
| `align xyz` | floors the position to the block grid (use `align xyz positioned ~.5 ~ ~.5` for block centre) |
| `in <dimension>` | dimension of the source (coordinates are not scaled); selectors without `distance`/`x y z`/`dx dy dz` still search every dimension (see selectors.md) |
| `on <relation>` | executor becomes a related entity: `attacker`, `controller`, `leasher`, `origin`, `owner`, `passengers`, `target`, `vehicle` |
| `summon <entity>` | summons an entity and makes it the executor |

`as @a at @s` is the usual "for each player, at that player". `at @s` alone after `as` is required for `~ ~ ~` to mean the entity's position.

`on origin` gives the shooter of a projectile or the summoner of an evoker fang; `on attacker` the last entity that hurt the executor (recent); `on target` the mob's attack target; `on owner` the owner of a tamed animal or projectile; for `interaction` entities, `on attacker`/`on target` give the player that last attacked/used it.

## Conditions

`if` passes when the test is true, `unless` when false. A failing condition stops that branch.

| Test | Example |
|---|---|
| `entity <targets>` | `if entity @s[tag=boss]` |
| `score <a> <obj> <op> <b> <obj>` | ops `< <= = >= >` |
| `score <a> <obj> matches <range>` | `matches 1..`, `matches ..-1`, `matches 3..7`, `matches 5` |
| `block <pos> <block_predicate>` | `if block ~ ~-1 ~ #minecraft:logs` , states `oak_stairs[half=top]` |
| `blocks <start> <end> <dest> all\|masked` | compare regions |
| `data block\|entity\|storage <src> <path>` | passes if the path exists (count of matches) |
| `predicate <id>` | a predicate file, or an inline predicate SNBT |
| `function <id>` | runs the function, passes if it returned non-zero |
| `items entity\|block <src> <slots> <item_predicate>` | `if items entity @s weapon.mainhand *[custom_data~{wand:true}]` |
| `loaded <pos>` | chunk is fully loaded |
| `dimension <id>` | `if dimension minecraft:the_nether` |
| `biome <pos> <biome or #tag>` | `if biome ~ ~ ~ #minecraft:is_ocean` |

Ranges are inclusive. `..5` means at most 5, `5..` at least 5.

## store

`execute store result|success <target> ... run <command>` writes the command's result after it runs.

- `store result score <targets> <objective>`
- `store result entity <target> <path> <type> <scale>` (types `byte short int long float double`)
- `store result storage <id> <path> <type> <scale>`
- `store result block <pos> <path> <type> <scale>`
- `store result bossbar <id> value|max`

`result` is the command's return value (for example `data get` returns the number scaled, `time query gametime` returns the time, `execute if entity @e[...]` returns the count), `success` is 1 or 0. Players' NBT cannot be written; store into a score or storage instead.

```mcfunction
execute store result score @s pw.y run data get entity @s Pos[1] 100
execute store result storage pw:tmp speed double 0.01 run scoreboard players get @s pw.speed
execute store success score @s pw.ok run clear @s minecraft:emerald 5
execute store result score #count pw.tmp if entity @e[type=minecraft:zombie,distance=..16]
```

## Forking, order and cost

- Each selector after `as`/`at` multiplies the work. `execute as @a at @s as @e[distance=..5]` runs per player per nearby entity.
- Conditions placed before a fork are cheaper: test cheap scores first, then `if entity`, and only then NBT or predicates.
- Branches run in selector order (sorted by `sort=` if given) and each branch completes before the next starts.
- `maxCommandForkCount` (default 65536) caps the number of branches of one command; `maxCommandChainLength` (default 65536) caps commands per function call chain.

## return

- `return <int>` ends the current function with that value.
- `return fail` ends it with failure (value 0).
- `return run <command>` ends it with the command's result and success. If the command forks, only the first branch runs.
- `execute if ... run return 1` returns only when the condition passes; otherwise the function continues.
- A function called with `execute as @a run function ns:f` runs once per player; a `return` inside `ns:f` ends only that call.

```mcfunction
execute unless entity @s[type=minecraft:player] run return fail
execute if score @s pw.cd matches 1.. run return 0
execute store result score @s pw.hits run function pw:count_hits
execute if function pw:has_target run say target found
```

## Useful idioms

```mcfunction
execute as @a at @s if block ~ ~-1 ~ minecraft:magma_block run effect give @s minecraft:speed 1 1 true
execute as @e[type=minecraft:armor_stand,tag=pw.spawner] at @s unless entity @e[type=minecraft:zombie,distance=..8] run summon minecraft:zombie ~ ~ ~
execute as @a[tag=pw.caster] at @s anchored eyes positioned ^ ^ ^2 run particle minecraft:flame ~ ~ ~ 0 0 0 0 1
execute at @s align xyz positioned ~.5 ~ ~.5 run summon minecraft:marker ~ ~ ~ {Tags:["pw.node"]}
execute summon minecraft:marker run tag @s add pw.new
execute as @e[type=minecraft:arrow] on origin if entity @s[type=minecraft:player] run tag @s add pw.shooter
execute positioned over motion_blocking_no_leaves run summon minecraft:lightning_bolt ~ ~ ~
```
