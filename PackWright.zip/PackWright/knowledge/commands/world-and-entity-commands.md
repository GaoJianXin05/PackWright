# World and entity commands (cheat sheet)

Exact trees: `pw usage <command>`. Ids: `pw id <registry> <words>`.

## Entities

```mcfunction
summon minecraft:zombie ~ ~ ~ {Tags:["pw.minion"],PersistenceRequired:true,equipment:{mainhand:{id:"minecraft:iron_sword",count:1}},drop_chances:{mainhand:0.0f}}
tp @s ~ ~1 ~
tp @s ^ ^ ^3
tp @s ~ ~ ~ facing entity @p eyes
tp @e[tag=pw.orb] @s
rotate @s facing entity @p eyes
rotate @s ~15 ~
execute as @e[type=minecraft:zombie,distance=..4,limit=3] run damage @s 6 minecraft:player_attack by @p
damage @s 3 minecraft:magic
damage @e[tag=pw.target,limit=1] 10 minecraft:explosion at ~ ~ ~
kill @e[type=minecraft:marker,tag=pw.temp]
ride @s mount @e[type=minecraft:horse,limit=1,sort=nearest]
ride @s dismount
effect give @s minecraft:resistance 5 4 true
effect give @a minecraft:night_vision infinite 0 true
effect clear @s minecraft:poison
attribute @s minecraft:max_health base set 40
attribute @s minecraft:movement_speed modifier add pw:haste 0.5 add_multiplied_base
attribute @s minecraft:movement_speed modifier remove pw:haste
attribute @s minecraft:scale base set 2
attribute @s minecraft:gravity base set 0.04
execute store result score @s pw.tmp run attribute @s minecraft:attack_damage get 10
enchant @s minecraft:sharpness 3
experience add @s 5 levels
spreadplayers 0 0 50 200 false @a
```

- `damage <target> <amount> [<type> [at <pos> | by <entity> [from <cause>]]]` takes exactly one target (fork with `execute as` for many). `by` sets the attacker (enables `on attacker`, kill credit and aggro). Damage types: `pw id damage_type`. A target hit in the last 10 ticks only takes the part above its previous hit (hurt cooldown), see pitfalls.md.
- `tp` to `^ ^ ^n` moves along the executor's look direction. `tp` resets motion; for knockback write `Motion` on non-players, or use `attribute`/explosions/wind charges for players.
- `rotate` (1.21.2+) changes rotation without teleporting.
- Attribute modifiers: `add_value`, `add_multiplied_base`, `add_multiplied_total`. Ids are resource locations (`pw:haste`); adding the same id twice fails, so remove first or use a new id.
- Attributes in 1.21.8: `armor armor_toughness attack_damage attack_knockback attack_speed block_break_speed block_interaction_range burning_time camera_distance entity_interaction_range explosion_knockback_resistance fall_damage_multiplier flying_speed follow_range gravity jump_strength knockback_resistance luck max_absorption max_health mining_efficiency movement_efficiency movement_speed oxygen_bonus safe_fall_distance scale sneaking_speed spawn_reinforcements step_height submerged_mining_speed sweeping_damage_ratio tempt_range water_movement_efficiency waypoint_receive_range waypoint_transmit_range`.
- Players' NBT is read-only. Health: `effect` (instant_health/instant_damage), `damage`, or attributes.

## Blocks

```mcfunction
setblock ~ ~ ~ minecraft:chest[facing=north]{Items:[{Slot:0b,id:"minecraft:diamond",count:3}]}
setblock ~ ~-1 ~ minecraft:magma_block replace
fill ~-3 ~ ~-3 ~3 ~3 ~3 minecraft:glass hollow
fill ~-5 ~-1 ~-5 ~5 ~-1 ~5 minecraft:air replace minecraft:fire
fill ~-2 ~ ~-2 ~2 ~2 ~2 minecraft:stone strict
clone ~ ~ ~ ~5 ~5 ~5 ~10 ~ ~ masked
place feature minecraft:oak ~ ~ ~
place template pw:arena ~ ~ ~ none none 1.0 0
```

- `fill` limit: 32768 blocks per command (`commandModificationBlockLimit`).
- `strict` (1.21.5+) skips block updates and shape adjustment.
- Block states in brackets, block entity NBT in braces: `pw block <id>` lists states and defaults.

## Particles and sounds

```mcfunction
particle minecraft:flame ~ ~1 ~ 0.3 0.3 0.3 0.02 20
particle minecraft:dust{color:[0.6,0.1,0.9],scale:1.5} ~ ~1 ~ 0.5 0.5 0.5 0 30 force @a
particle minecraft:dust_color_transition{from_color:[1.0,0.0,0.0],to_color:[1.0,1.0,0.0],scale:1.0} ~ ~1 ~ 0.2 0.2 0.2 0 10
particle minecraft:block{block_state:"minecraft:stone"} ~ ~ ~ 0.5 0.1 0.5 0 40
particle minecraft:item{item:"minecraft:diamond"} ~ ~1 ~ 0.2 0.2 0.2 0.05 10
particle minecraft:entity_effect{color:[1.0,0.2,0.2,1.0]} ~ ~1 ~ 0.3 0.5 0.3 1 10
particle minecraft:trail{target:[0.0d,80.0d,0.0d],color:16711680,duration:20} ~ ~1 ~ 0 0 0 0 1
particle minecraft:sonic_boom ~ ~1 ~
particle minecraft:end_rod ^ ^ ^1 0 0 0 0 1
playsound minecraft:entity.warden.sonic_boom hostile @a[distance=..32] ~ ~ ~ 1 0.8
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
stopsound @a music
```

- Argument order: `particle <name> <pos> <delta> <speed> <count> [force|normal] [<viewers>]`. With `count 0`, delta is a direction and speed its magnitude (directional particles like `flame`, `end_rod`, `cloud`).
- Particles with options (1.21.8): `block block_crumble block_marker falling_dust dust_pillar` (`block_state`), `dust` (`color`, `scale`), `dust_color_transition`, `entity_effect` (`color` with alpha), `tinted_leaves` (`color`), `item` (`item`), `trail` (`target`, `color`, `duration`), `vibration` (`destination`, `arrival_in_ticks`), `sculk_charge` (`roll`), `shriek` (`delay`). `pw schema particle <name>`.
- Sound categories: `master music record weather block hostile neutral player ambient voice ui`. Sound ids: `pw id sound_event <words>`.

## World and players

```mcfunction
time set day
time add 6000
weather thunder 600
gamerule keepInventory true
gamerule doImmediateRespawn true
gamerule sendCommandFeedback false
difficulty hard
worldborder set 200 30
worldborder center 0 0
spawnpoint @s ~ ~ ~
setworldspawn 0 64 0
forceload add ~ ~
gamemode adventure @a[tag=pw.fighter]
team add pw.red {text:"Red",color:"red"}
team modify pw.red color red
team modify pw.red friendlyFire false
team modify pw.red collisionRule never
team modify pw.red nametagVisibility hideForOtherTeams
team join pw.red @s
schedule function pw:phase2 100t replace
schedule clear pw:phase2
tick rate 10
tick freeze
tick unfreeze
```

- Game rules in 1.21.8 are camelCase. Useful: `doImmediateRespawn`, `keepInventory`, `doMobLoot`, `mobGriefing`, `naturalRegeneration`, `sendCommandFeedback`, `commandBlockOutput`, `showDeathMessages`, `announceAdvancements`, `fallDamage`, `fireDamage`, `drowningDamage`, `freezeDamage`, `doDaylightCycle`, `doWeatherCycle`, `doMobSpawning`, `randomTickSpeed`, `spawnRadius`, `locatorBar`, `maxCommandChainLength`, `maxCommandForkCount`, `commandModificationBlockLimit`. All: `pw usage gamerule`.
- `schedule function` runs without an executor at world spawn; store context in scores/storage or re-select entities with `execute as`.
- Time units: `20t` = `1s`; `d` = 24000 ticks.

## Dialogs and waypoints (1.21.6+)

```mcfunction
dialog show @s pw:menu
dialog clear @s
waypoint modify @s color red
waypoint modify @s style reset
```

Dialog files: see `datapack/dialogs.md`. Any living entity with `waypoint_transmit_range` > 0 shows on the locator bar of players whose `waypoint_receive_range` covers it.
