# Target selectors

| Selector | Picks |
|---|---|
| `@p` | nearest player |
| `@r` | random player |
| `@a` | all players (including dead ones) |
| `@e` | all entities that are alive (players, markers, items, displays and armor stands included) |
| `@s` | the executor |
| `@n` | nearest entity (any type) |

Options go right after the selector, no spaces: `@e[type=minecraft:zombie,tag=pw.boss,limit=1,sort=nearest]`.

| Option | Notes |
|---|---|
| `type=minecraft:zombie`, `type=!player`, `type=#minecraft:undead` | one positive type, any number of negated ones; entity tags allowed |
| `tag=x`, `tag=!x`, `tag=` | repeat to require several; `tag=` matches entities with no tags |
| `name="Bob"`, `name=!Bob` | custom name or player name |
| `team=red`, `team=!red`, `team=` | team membership |
| `scores={pw.cd=1..,pw.mana=..9}` | all must match |
| `distance=..5`, `distance=2..8` | from the execution position (sphere); restricts to the current dimension |
| `x= y= z=` with `dx= dy= dz=` | box from (x,y,z) to (x+dx, y+dy, z+dz), tests the hitbox overlap |
| `x_rotation=`, `y_rotation=` | pitch and yaw ranges |
| `level=`, `gamemode=survival` / `!spectator` | players only |
| `limit=N`, `sort=nearest\|furthest\|random\|arbitrary` | `@p`/`@n` imply `limit=1,sort=nearest` |
| `advancements={pw:hidden/hit=true}`, `advancements={pw:x={crit=true}}` | advancement or criterion state |
| `predicate=pw:is_sneaking`, `predicate=!pw:x` | predicate files |
| `nbt={OnGround:true}` | NBT match; slow, avoid on frequent selectors |

Selector costs from cheap to expensive: `@s`, `@p`, `limit=` with `type=` and `tag=`, `distance=`, `scores=`, `predicate=`, `nbt=`. Always narrow `@e` with `type=` and `tag=` or `distance=` inside tick functions.

`@a[distance=..10]` from a function run by the server (no executor position) measures from world spawn; always set the position first with `execute at` or `positioned`.

Dimensions: a selector without `distance=`, `x=y=z=` or `dx=dy=dz=` searches every loaded dimension, wherever the command runs, and `execute in <dim>` does not change that (it only moves the source). `execute in minecraft:the_nether as @e[type=minecraft:marker,tag=pw.node] run ...` therefore runs once per marker in all three dimensions, and three such lines run everything three times. For entity-driven loops drop the `in` and use `execute as @e[...] at @s run ...` (`at @s` carries the entity's own dimension). To keep a search inside the source's dimension without limiting the range, add `distance=0..`.

```mcfunction
execute as @e[type=#minecraft:undead,distance=..12,tag=!pw.immune] run damage @s 4 minecraft:magic by @p
kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:rotten_flesh"}},distance=..30]
execute as @a[gamemode=!spectator,predicate=pw:in_arena] run tag @s add pw.fighter
tp @e[type=minecraft:marker,tag=pw.node,limit=1,sort=furthest] @s
execute at @n[type=minecraft:armor_stand,tag=pw.altar] run particle minecraft:end_rod ~ ~1 ~ 0.3 0.3 0.3 0.02 5
```

Players' names, UUID strings (`f81d4fae-7dec-11d0-a765-00a0c91e6bf6`) and fake names (`#tmp`) also work where a single target or score holder is expected.
