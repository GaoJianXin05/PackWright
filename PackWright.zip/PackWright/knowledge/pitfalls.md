# Pitfalls that pass the parser but break the pack

`pw check` catches syntax, ids, schema and stale formats. The mistakes below are logic mistakes: the pack loads and then behaves wrong. Read this before writing systems with many moving parts.

## Execution context

| Mistake | What happens | Do instead |
|---|---|---|
| `@s` or `~ ~ ~` directly in `tick`/`load`, a `schedule`d function or a function tag | these run as the server at world spawn, `@s` matches nothing | `execute as @a at @s run function ns:player/tick` |
| `execute as @e[...] run particle ... ~ ~ ~` | `as` changes the executor only; the position stays where it was | `execute as @e[...] at @s run ...` |
| `positioned as` when the rotation or dimension matters | only the position changes | `at` copies position, rotation and dimension |
| `anchored eyes` expecting `~` to move | anchoring affects `^` coordinates and `facing` only | `execute anchored eyes positioned ^ ^ ^ run ...` |
| `return run` on a forking command | only the first branch runs | fork with `execute as ... run function`, return inside that function |
| `return` inside a function called per entity | ends that call only, the other entities still run | intended; to stop everything set a flag score and check it |
| `schedule function` expecting the caller | context is lost, it runs as the server | tag or score the target, select it inside the scheduled function |
| advancement reward functions | run as the player, at the player | no extra `execute as` needed |
| `kill @s` in the middle of a function | the function keeps running | put cleanup that uses `@s` before the kill |

## Selectors

| Mistake | What happens | Do instead |
|---|---|---|
| `@e` without `type=`/`tag=`/`distance=` every tick | scans every entity in loaded chunks | always narrow with `type=` and a tag |
| `@e[type=player]` for respawn logic | `@e` skips dead entities; `@a` also selects dead players | `@a` and check `scores`/`predicate` as needed |
| `@e[distance=..6]` meant as "enemies around me" | it matches every kind of entity: other players, pets, armor stands, markers, items, displays, boats | `type=!player`, `tag=!ns.caster`, `type=!#ns:ignore` (your own entity-type tag for markers, displays, items, armor stands...) |
| `execute in <dim> as @e[...]` to restrict a loop to one dimension | `in` only moves the source; a selector without `distance`/`x y z`/`dx dy dz` still searches every dimension, so three `in` lines run everything three times | drop the `in` and use `as @e[...] at @s`, or add `distance=0..` |
| forgetting spectators | `@a` includes them | `@a[gamemode=!spectator]` |
| `distance=` from the tick function | measured from world spawn | `execute at <anchor> if entity @a[distance=..16]` |
| `nbt=` in hot selectors | serializes the whole entity each test | scores, tags, predicates, `execute if items` |
| `limit=1` without `sort` on `@e` | arbitrary order | `sort=nearest`, `sort=random` |
| entities in unloaded chunks | not selectable, `summon` there fails ("Unable to summon entity") | `forceload add` the arena or work near players |

## Scores

| Mistake | What happens | Do instead |
|---|---|---|
| reading a score that was never set | `if score ... matches` fails, `unless score ... matches` passes, `scoreboard players get` fails ("none is set") | initialize in `load` or on first join |
| `/= #0` | the operation fails ("Cannot divide by zero") | guard: `execute unless score #d pw.tmp matches 0 run ...` |
| decimals | all math is 32-bit integer, `/=` floors | fixed point (x100 or x1000) |
| `data get ... <scale>` | the result is floored | scale up first (`Health` with scale 10), then compare |
| `trigger` objective used twice | it is disabled after each use ("You cannot trigger this objective yet") | `scoreboard players enable @s <obj>` again after handling |
| `scoreboard objectives add` in `load` | runs every `/reload`, fails harmlessly when it exists | fine; never rely on it to reset values |
| a score text component with `name:"@s"` in `tellraw @a` | shows the executor's score to everyone | `name:"*"` shows each reader their own score, or `execute as @a run tellraw @s ...` |

```mcfunction
tellraw @a [{text:"Mana: ",color:"aqua"},{score:{name:"*",objective:"pw.mana"}}]
execute as @a run title @s actionbar [{text:"Mana: ",color:"aqua"},{score:{name:"@s",objective:"pw.mana"}}]
```

## Entity data

| Mistake | What happens | Do instead |
|---|---|---|
| `data modify entity @s ...` on a player | fails ("Unable to modify player data") | `attribute`, `effect`, `damage`, `tp`, `item`, `xp`, `gamemode`, `spawnpoint` |
| setting a player's `Motion` | impossible | levitation, `tp` steps, knockback from `damage` or explosions, `wind_charge` |
| `data get entity @a[...]` or `@p` on many players in hot loops | player NBT is large | read once into scores, prefer predicates |
| Tags beyond 1024 per entity | `tag add` fails ("too many tags") | store data in scores or storage |
| `summon` then selecting "the newest" entity | race between several summons | `execute summon minecraft:marker run function ns:init` (the new entity is `@s`) |
| display entity interpolation set at spawn | nothing animates | spawn, then a tick later set `transformation`, `start_interpolation:0`, `interpolation_duration` |
| `transformation` with only some of the four fields in `summon` | the compound is rejected as a whole and the display keeps its default size | write `translation`, `left_rotation`, `scale` and `right_rotation` together (`data merge` may change single fields) |
| `Health:100f` where the max health comes from worn equipment or an effect | those modifiers apply on the first tick, so `Health` is clamped to the base max at spawn | `attributes:[{id:"minecraft:max_health",base:100d}]` in the same NBT, or raise `Health` a tick later |
| projectile ownership | `Owner` is an int-array UUID | copy with `data modify entity @s Owner set from entity @p[tag=pw.caster] UUID` |

```mcfunction
execute summon minecraft:marker run function pw:init_marker
data modify entity @s Owner set from entity @p[tag=pw.caster] UUID
```

## Items

| Mistake | What happens | Do instead |
|---|---|---|
| identifying items by name or model | anvil renames and resource packs break it | `custom_data~{pw:{id:"x"}}` |
| `custom_data={...}` in a predicate when you mean "contains" | `=` needs exact equality of the whole component | `custom_data~{...}` for a partial match |
| `SelectedItem` / `Inventory` NBT checks | slow and fragile | `execute if items entity @s weapon.mainhand <predicate>` |
| `custom_name` for an item's built-in name | italic by default and replaced by anvils | `item_name` (not italic, survives anvils); `lore` lines are italic purple unless `italic:false` |
| a hidden enchantment that never fires | its effects only work in the slots listed in `slots` | `"slots":["mainhand"]` for weapons, `"armor"` for armor |
| enchantment `supported_items` used to restrict a component-applied enchantment | components bypass it; it only matters for tables, anvils and `/enchant` | restrict by giving the enchantment only through your loot table |
| `attribute ... modifier add` run twice | fails ("Modifier ... is already present") | `attribute ... modifier remove` first, or check |
| JSON text in commands, SNBT in files | commands parse SNBT text components, data files use JSON | match the container |
| a text component written as a JSON string: `CustomName:'{"text":"Boss"}'`, `item_name='{"text":"X"}'` | since 1.21.5 a string is plain text, so the braces and quotes appear on screen | a compound: `CustomName:{text:"Boss"}`, `item_name={text:"X"}` |
| old `Count:1b` in an item inside block entity NBT, entity NBT or a selector: `setblock ~ ~ ~ chest{Items:[{Slot:0b,id:"minecraft:apple",Count:3b}]}`, `nbt={Inventory:[{Count:1b}]}` | the key is `count` (int); `Count` is not read, so the stack holds 1 item and the selector never matches | `count:3`, `nbt={Inventory:[{count:1}]}` |

```mcfunction
attribute @s minecraft:movement_speed modifier remove pw:haste
attribute @s minecraft:movement_speed modifier add pw:haste 0.05 add_value
```

## Damage

| Mistake | What happens | Do instead |
|---|---|---|
| several skills or ticks damage the same target | after a hit, a mob or player ignores damage that is not larger than the last hit for 10 ticks (hurt cooldown); a second `damage` within 0.5 s is swallowed or only its excess applies | space the hits 10 ticks apart, hit each target once per cast, or use a damage type listed in `#minecraft:bypasses_cooldown` |
| relying on `#minecraft:bypasses_cooldown` | the game checks the tag, but vanilla 1.21.8 ships no such file (`pw tag damage_type` does not list it), so it only exists if your pack creates `data/minecraft/tags/damage_type/bypasses_cooldown.json` | create the tag with your own damage types |
| an area skill that damages whatever `@e` returns | breaks armor stands and boats, sets off end crystals, hurts other players and the caster's own minions | narrow the selector (see Selectors above) |

## Feedback and UI

| Mistake | What happens | Do instead |
|---|---|---|
| a one-off actionbar message while a HUD rewrites the actionbar every few ticks | the HUD replaces it within that interval and the player never reads it | let the HUD print the message (a score that keeps it for ~30 ticks), or use title, chat or a sound |
| rules that skip creative or spectator players (targeting, idle despawn) | test runs in creative look broken: nothing attacks, bosses vanish | say so in the instructions or add a debug switch |

## Functions, macros and loading

| Mistake | What happens | Do instead |
|---|---|---|
| one bad line in a function | the whole function fails to load, `/function` says it is unknown | `pw check` before testing; read the server log after `/reload` |
| a macro argument missing at call time | the call fails ("Missing argument") | pass every `$(key)` the function uses |
| a macro line without `$` | `$(key)` is taken literally and usually fails to parse | start the line with `$` |
| macros in per-tick loops | each new argument set is re-parsed | keep macros at the edges (setup, rare events) |
| unbounded recursion (raycasts, rings) | the whole execution stops at `maxCommandChainLength` (65536 commands) | always add a step counter or distance limit |
| uppercase or spaces in file names | the file is ignored | `[a-z0-9_.-]` and `/` only |
| JSON comments or trailing commas | the file fails to load | strict JSON |
| advancement events fire once | criteria stay granted | `advancement revoke @s only ns:events/x` in the reward function |
| recipes "missing" | they are craftable without unlocking; only the recipe book needs `recipe give` | unlock if the book matters |

## Blocks and the world

| Mistake | What happens | Do instead |
|---|---|---|
| `if block ~ ~ ~ minecraft:air` | misses `cave_air` and `void_air` | `if block ~ ~ ~ #minecraft:air` |
| `fill`/`setblock` across unloaded chunks | fails | keep edits near players or `forceload` |
| particles at long range | normal particles show within 32 blocks | `force` raises it to 512 |
| block states in tests | `if block ~ ~ ~ minecraft:oak_stairs` ignores states; `[facing=north]` requires them | write only the states you need |
