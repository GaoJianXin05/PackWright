# Minecraft Java 1.21.8: version facts and stale syntax

## Numbers

| Fact | Value |
|---|---|
| Data pack `pack_format` | 81 |
| Resource pack `pack_format` | 64 |
| Data version | 4440 |
| Protocol | 772 |
| Java | 21 |

1.21.8 is a hotfix of 1.21.6/1.21.7. Data pack content is the same as 1.21.7 (format 81). Anything introduced in 1.21.9 or later does not exist here.

## Things that do NOT exist in 1.21.8

Training data and the current wiki describe newer versions. These are not in 1.21.8:

- snake_case game rules (`max_command_sequence_length`, `keep_inventory`). 1.21.8 uses camelCase: `maxCommandChainLength`, `maxCommandForkCount`, `keepInventory`, `doDaylightCycle`, `commandModificationBlockLimit`, `sendCommandFeedback`, `locatorBar`.
- `/stopwatch`, `/swing`, `/fetchprofile`, environment attributes, timelines, world clocks, copper golems, copper tools and armor, shelves, `minecraft:object`/`player` text components, `pack.mcmeta` `min_format`/`max_format`, spears and lunge, the `effect`/`instant_effect` particle options, nautilus mobs.
- Use `pw usage`, `pw id` and `pw schema` to confirm whether something exists before relying on memory.

## Things added in 1.20.5 to 1.21.8 that you can use

- 1.20.5: item components replace item NBT; `execute if items`; item predicates in `clear`/`execute if items`; `/transfer`; storage-backed macros already existed (1.20.2).
- 1.21: data pack folders are singular; data-driven enchantments, jukebox songs, painting variants; `minecraft:run_function` enchantment effect; `/item` and `/loot` unchanged.
- 1.21.2: `consumable`, `use_cooldown`, `use_remainder`, `equippable`, `glider`, `damage_resistant`, `death_protection`, `enchantable`, `repairable`, `item_model`, `tooltip_style`; recipe ingredients become plain strings; `/rotate`; attribute ids lose `generic.` and friends; `entity_interaction_range` and `block_interaction_range` etc.
- 1.21.4: `custom_model_data` becomes `{floats,flags,strings,colors}`; item model definitions in resource packs (`assets/<ns>/items/`); `equippable.asset_id`.
- 1.21.5: text components are written as SNBT inside commands; `click_event`/`hover_event` with new field names; `tooltip_display`; `weapon`, `blocks_attacks`, `break_sound`, `provides_banner_patterns`, `provides_trim_material`, `potion_duration_scale`; mob `equipment` and `drop_chances` maps; `fall_distance`; SNBT booleans, `bool()`, `uuid()`, hex and binary numbers; `/test` and test instances; `strict` mode for `setblock`/`fill`; mob variant components.
- 1.21.6: `/dialog` and the `dialog` registry; `show_dialog` and `custom` click events; `/waypoint`, waypoint attributes and the locator bar; `/version`; `equippable.can_be_sheared`; `home_pos`/`home_radius` on mobs; `custom_particle` on area effect clouds; `player_sheared_equipment` trigger; `attribute_modifiers` `display` field; `camera_distance` and `waypoint_transmit_range`/`waypoint_receive_range` attributes.

## Stale syntax and its 1.21.8 form

| Stale | 1.21.8 |
|---|---|
| `give @s diamond_sword{Enchantments:[{id:"sharpness",lvl:5}]}` | `give @s diamond_sword[enchantments={sharpness:5}]` |
| `{display:{Name:'{"text":"X"}'}}` | `[custom_name={text:"X",italic:false}]` or `[item_name="X"]` |
| `CustomName:'{"text":"X"}'`, `item_name='{"text":"X"}'` (JSON inside a string) | `CustomName:{text:"X"}`, `item_name={text:"X"}`; a string is shown literally |
| `display.Lore` | `[lore=[{text:"line",italic:false}]]` |
| `CustomModelData:7` | `[custom_model_data={floats:[7f]}]` |
| `Unbreakable:1b` | `[unbreakable={}]` |
| `HideFlags:127` | `[tooltip_display={hidden_components:["enchantments","attribute_modifiers"]}]` |
| `hide_tooltip={}` component | `[tooltip_display={hide_tooltip:true}]` |
| `enchantments={levels:{...},show_in_tooltip:false}` | `enchantments={sharpness:5}` plus `tooltip_display` |
| `attribute_modifiers={modifiers:[...]}` | `attribute_modifiers=[{type:"attack_damage",id:"ns:x",amount:5,operation:"add_value",slot:"mainhand"}]` |
| `fire_resistant={}` | `damage_resistant={types:"#minecraft:is_fire"}` |
| `food={eat_seconds:..,effects:[..]}` | `food={nutrition:..,saturation:..}` plus `consumable={consume_seconds:..,on_consume_effects:[..]}` |
| item NBT `tag:{...}` | `custom_data={...}` for your own data; real behavior lives in components |
| `Count:1b` in item stacks | `count:1` |
| `SkullOwner:"Name"` | `profile={name:"Name"}` or `profile="Name"` |
| `BlockEntityTag:{...}` / `EntityTag:{...}` | `block_entity_data={id:"...",...}` / `entity_data={id:"...",...}` (id required) |
| `Potion:"..."`, `CustomPotionEffects` | `potion_contents={potion:"...",custom_effects:[...]}` |
| `HandItems`, `ArmorItems`, `body_armor_item`, `SaddleItem` | `equipment:{mainhand:{id:"..."},head:{id:"..."},body:{...},saddle:{...}}` |
| `HandDropChances`, `ArmorDropChances` | `drop_chances:{mainhand:0.0f,head:1.0f}` |
| `FallDistance` | `fall_distance` (double) |
| `Attributes:[{Name:"generic.max_health",Base:40}]` | `attributes:[{id:"minecraft:max_health",base:40d}]` |
| `ActiveEffects:[{Id:1b,...}]` | `active_effects:[{id:"minecraft:speed",amplifier:1b,duration:200}]` |
| `/attribute @s generic.max_health ...` | `/attribute @s minecraft:max_health ...` |
| area effect cloud `Particle:"..."` | `custom_particle:{type:"minecraft:flame"}` |
| fireball `power:[..]` | `acceleration_power:0.1d` |
| `particle dust 1 0 0 1 ~ ~ ~ ...` | `particle dust{color:[1.0,0.0,0.0],scale:1.0} ~ ~ ~ ...` |
| `particle block stone`, `particle item diamond` | `particle block{block_state:"stone"}`, `particle item{item:"diamond"}` |
| `"clickEvent":{"action":"run_command","value":"/x"}` | `click_event:{action:"run_command",command:"x"}` |
| `"hoverEvent":{"action":"show_text","contents":..}` | `hover_event:{action:"show_text",value:..}` |
| `open_url` `value`, `change_page` `value` | `url:"https://..."`, `page:2` |
| `show_item` `contents:{id,count,tag}` | `hover_event:{action:"show_item",id:"...",count:1,components:{...}}` |
| `data/<ns>/functions/`, `tags/functions/`, `tags/items/` | `data/<ns>/function/`, `tags/function/`, `tags/item/` (all folders singular) |
| recipe ingredient `{"item":"minecraft:stone"}` / `{"tag":"minecraft:logs"}` | `"minecraft:stone"` / `"#minecraft:logs"` |
| recipe result `{"item":"...","count":2}` | `{"id":"...","count":2}` |
| advancement icon `{"item":"..."}` | `{"id":"..."}` (with optional `components`) |
| loot `set_nbt`, `copy_nbt` | `set_custom_data`, `copy_custom_data`, or `set_components` |
| item predicate `{"items":[..],"nbt":"{..}"}` | `{"items":"...","predicates":{"minecraft:custom_data":{..}}}` |
| `minecraft:grass`, `minecraft:scute`, enchantment `sweeping` | `short_grass`, `turtle_scute`, `sweeping_edge` |
| `pack_format` 48 / 57 / 61 / 71 | `81` |

## Text components inside commands

Since 1.21.5 a text component argument is parsed as SNBT. JSON-style quoted keys still parse, but the field names must be the 1.21.5 names. Prefer the SNBT style:

```mcfunction
tellraw @a [{text:"[Shop] ",color:"gold"},{text:"Buy",color:"green",click_event:{action:"run_command",command:"trigger shop set 1"},hover_event:{action:"show_text",value:"Click to buy"}}]
```

In `.json` files (advancements, loot tables, dialogs) text components stay JSON with the same 1.21.5 field names.
