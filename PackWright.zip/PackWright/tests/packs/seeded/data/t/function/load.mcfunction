# comment
/scoreboard objectives add t.a dummy
scoreboard objectives add t.b dummy
execute as @a \
  run say hi
function t:nothere
function t:macro {x:"1"}
execute if score @s t.undefined matches 1 run say hi
tag @s add foo
execute if entity @s[tag=bar] run say hi
schedule function t:load 1s
execute run function t:load
execute as @e run function t:load
return fail
say after return
