$say $(x) $(y
$execute as @e[limit=$(n)] run say hi
