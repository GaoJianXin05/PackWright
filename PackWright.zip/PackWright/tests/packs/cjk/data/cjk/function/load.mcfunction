# Objectives, teams and tags may be Chinese
scoreboard objectives add 金币 dummy {text:"金币",color:"gold"}
scoreboard objectives add 魔力值 dummy
scoreboard objectives add 清怪否决 trigger
scoreboard objectives setdisplay sidebar 金币
team add 红队
team modify 红队 color red
scoreboard players set #全局 金币 0
