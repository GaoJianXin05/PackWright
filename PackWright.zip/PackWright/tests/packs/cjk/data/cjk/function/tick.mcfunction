execute as @a at @s run function cjk:per_player
scoreboard players enable @a 清怪否决
