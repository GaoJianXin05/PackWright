tag @s add 玩家
team join 红队 @s
execute if score @s 金币 matches 100.. run title @s actionbar [{text:"金币 ",color:"gold"},{score:{name:"@s",objective:"金币"}}]
execute if score @s 清怪否决 matches 1 run scoreboard players set @s 清怪否决 0
execute as @e[tag=!玩家,type=zombie,distance=..8] run tag @s add 被标记
execute if entity @e[tag=被标记,limit=1] run scoreboard players add @s 魔力值 1
