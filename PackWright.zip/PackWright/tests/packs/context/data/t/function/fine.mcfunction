particle flame ~ ~ ~ 0 0 0 0 1
tag @s add y
