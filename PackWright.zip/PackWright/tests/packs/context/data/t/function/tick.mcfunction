execute as @a run function t:per_player
function t:server_stuff
execute as @a at @s run function t:positioned
schedule function t:later 20t
execute as @e[type=marker] at @s run function t:fine
