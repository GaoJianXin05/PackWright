particle flame ~ ~ ~ 0 0 0 0 1
execute if entity @s[tag=x] run say fine
