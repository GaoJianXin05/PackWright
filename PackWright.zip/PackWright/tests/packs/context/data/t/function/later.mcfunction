effect give @s speed 1 0
