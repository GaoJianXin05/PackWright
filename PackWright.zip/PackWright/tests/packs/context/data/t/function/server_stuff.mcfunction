say hi
tag @s add bad
execute as @e[type=marker] run function t:nested
