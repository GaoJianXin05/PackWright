"""Regression tests for the PackWright checker.

    python3 tests/run.py            run everything
    python3 tests/run.py -v         also list every passing case

Groups:
  commands.txt         one command per line with the diagnostics it must produce
  commands_strict.txt  the same with --strict-names
  packs/<name>/        a small data pack plus expected.txt (exact list of findings)
  merge                two packs that only make sense together (pw check --merge)
  examples/            both bundled examples must be clean
  knowledge/           every ```mcfunction and typed ```json block in the notes must be clean
"""
import contextlib
import io
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "tools"))

from packwright import args, cli, pack  # noqa: E402

VERBOSE = "-v" in sys.argv[1:]
failures = []
passed = 0


def check(label, ok, detail=""):
    global passed
    if ok:
        passed += 1
        if VERBOSE:
            print("  ok   " + label)
    else:
        failures.append((label, detail))
        print("  FAIL " + label)
        if detail:
            for line in str(detail).split("\n"):
                print("       " + line)


def tokens(rep):
    """E:CODE / W:CODE for every error and warning (notes are not compared)."""
    return sorted({f"{d.severity[0].upper()}:{d.code}" for d in rep.diags if d.severity in ("error", "warning")})


def run_commands(path, strict):
    args.OPTIONS["strict_names"] = strict
    try:
        for n, raw in enumerate(path.read_text(encoding="utf-8").split("\n"), 1):
            if not raw.strip() or raw.startswith("#"):
                continue
            expect, _, command = raw.partition(" | ")
            want = sorted(set(expect.split()) - {"ok"})
            extra = [t for t in want if t.startswith("I:")]
            want = [t for t in want if not t.startswith("I:")]
            rep = pack.check_commands_text(command, "x")
            got = tokens(rep)
            infos = {f"I:{d.code}" for d in rep.diags if d.severity == "info"}
            ok = got == want and all(t in infos for t in extra)
            check(f"{path.name}:{n} {command[:70]}", ok, f"expected {want + extra or ['ok']}, got {got + sorted(infos) or ['ok']}")
    finally:
        args.OPTIONS["strict_names"] = False


def parse_expected(path):
    out = set()
    for raw in path.read_text(encoding="utf-8").split("\n"):
        raw = raw.strip()
        if not raw or raw.startswith("#"):
            continue
        sev, code, where = raw.split(None, 2)
        file, _, line = where.partition(":")
        out.add((sev, code, file, line or ""))
    return out


def findings(rep):
    return {(d.severity[0].upper(), d.code, d.file or "", str(d.line) if d.line is not None else "") for d in rep.diags}


def run_pack(folder):
    rep = pack.check_path(folder)
    want = parse_expected(folder / "expected.txt")
    got = findings(rep)
    detail = ""
    if want != got:
        detail = "\n".join([f"missing:    {w}" for w in sorted(want - got)] + [f"unexpected: {g}" for g in sorted(got - want)])
    check(f"pack {folder.name}", want == got, detail)


def run_merge(folder):
    a, b = folder / "a", folder / "b"
    alone = findings(pack.check_path(b))
    codes = {c for _, c, _, _ in alone}
    check("merge: pack b alone cannot see pack a", "OBJECTIVE_NOT_CREATED" in codes and "MISSING_RESOURCE" not in codes, sorted(codes))
    rep = pack.check_merged([a, b])
    got = findings(rep)
    want = parse_expected(folder / "expected_merged.txt")
    detail = "\n".join([f"missing:    {w}" for w in sorted(want - got)] + [f"unexpected: {g}" for g in sorted(got - want)])
    check("merge: a + b together", want == got, detail)


def run_examples():
    for d in sorted((ROOT / "examples").iterdir()):
        if d.is_dir():
            rep = pack.check_path(d)
            check(f"example {d.name} is clean", tokens(rep) == [], "\n".join(f"{x.severity} {x.code} {x.file}:{x.line} {x.message}" for x in rep.diags if x.severity != "info"))


def run_knowledge():
    blocks = 0
    for p in sorted((ROOT / "knowledge").rglob("*.md")):
        text = p.read_text(encoding="utf-8")
        for m in re.finditer(r"^```(mcfunction)[^\n]*\n(.*?)^```", text, re.S | re.M):
            blocks += 1
            line = text[: m.start()].count("\n") + 2
            rep = pack.check_commands_text(m.group(2), f"{p.name}:{line}")
            bad = [d for d in rep.diags if d.severity in ("error", "warning")]
            check(f"knowledge {p.relative_to(ROOT / 'knowledge')}:{line}", not bad, "\n".join(f"{d.severity} {d.code} line {d.line}: {d.message}" for d in bad))
    check("knowledge has mcfunction blocks", blocks > 20, blocks)
    json_blocks = 0
    for p in sorted((ROOT / "knowledge").rglob("*.md")):
        text = p.read_text(encoding="utf-8")
        for m in re.finditer(r"^```json ([\w/]+)[^\n]*\n(.*?)^```", text, re.S | re.M):
            json_blocks += 1
            line = text[: m.start()].count("\n") + 2
            rep = pack.check_json_as(m.group(1), m.group(2), f"{p.name}:{line}")
            bad = [d for d in rep.diags if d.severity in ("error", "warning")]
            check(f"knowledge {p.relative_to(ROOT / 'knowledge')}:{line} json {m.group(1)}", not bad, "\n".join(f"{d.severity} {d.code}: {d.message}" for d in bad))
    check("knowledge has json blocks", json_blocks > 20, json_blocks)


def run_misc():
    with contextlib.redirect_stdout(io.StringIO()):
        code = cli.main(["doctor"])
    check("doctor reports ready", code == 0)


def main():
    print("PackWright tests")
    run_commands(HERE / "commands.txt", False)
    run_commands(HERE / "commands_strict.txt", True)
    for folder in sorted((HERE / "packs").iterdir()):
        if folder.is_dir() and (folder / "expected.txt").exists():
            run_pack(folder)
    run_merge(HERE / "merge")
    run_examples()
    run_knowledge()
    run_misc()
    print(f"{passed} passed, {len(failures)} failed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
