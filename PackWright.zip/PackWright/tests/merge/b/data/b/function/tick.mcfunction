execute as @a[scores={a.score=100..}] run function a:api/give_bonus
execute as @a run function #a:hooks
execute as @a run scoreboard players add @s b.reward 1
function a:api/needs_executor
function a:api/typo
