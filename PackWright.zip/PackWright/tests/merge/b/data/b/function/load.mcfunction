scoreboard objectives add b.reward dummy
