tag @s add touched
