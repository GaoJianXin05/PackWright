execute as @a run function a:per_player
