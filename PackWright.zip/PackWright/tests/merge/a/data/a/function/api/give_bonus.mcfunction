scoreboard players add @s a.score 10
