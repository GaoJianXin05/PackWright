scoreboard objectives add a.score dummy
