---
name: packwright
description: Build Minecraft Java 1.21.8 content from vanilla commands and data packs. Use for any Minecraft command, function, data pack, custom item or weapon, skill system, boss, minigame mechanic, advancement, predicate, loot table, item modifier, enchantment, recipe, dialog, text component, scoreboard or NBT question.
---

# PackWright

A toolkit for Minecraft Java Edition 1.21.8 (data pack format 81): a knowledge base, the exact 1.21.8 command tree, registries, tags, block states, item defaults, JSON schemas, all vanilla data files, and a static checker. Everything runs offline with Python 3.9+ and no dependencies.

Run the tools as `python3 <this folder>/tools/pw.py <command>` (`python` or `py` on Windows). They work from any working directory. Start a session with `pw doctor`.

Most of what you remember about Minecraft commands comes from other versions. Item NBT, JSON text in commands, plural folders, `generic.` attributes and old click event fields are gone; snake_case game rules, copper golems and `/stopwatch` do not exist yet. The tools are exact for 1.21.8, so look things up whenever you are not certain, and let the checker catch what slips through.

## Working loop

1. **Understand the request.** Work out what the player wants to experience, then choose the form: one command for chat (chat input stops at 256 characters), a few commands for command blocks, or a data pack. Anything with state, several steps or ongoing behavior is best as a data pack. If details are missing, choose reasonable defaults and say what you chose; ask only when the answer would change the whole design.
2. **Look up what you need.** Open `knowledge/INDEX.md` and read the files that match the task. Use `pw find` for anything else. Confirm syntax with `pw usage`, ids with `pw id`, fields with `pw schema`, and see how vanilla does something with `pw vanilla`. For a weapon or a boss, read the matching pattern file and its example pack first.
3. **Design before writing.** Sketch the system: inputs and events, state (scores, tags, storage), what runs every tick and what runs on events, the execution context of each function (`as`, `at`), feedback for the player, cleanup and uninstall. Think about multiplayer, death, relogging, `/reload` and unloaded chunks. Write the function tree down before filling it in.
4. **Write the pack.** Use `pw new <dir> --ns <namespace>` for a skeleton, or extend an existing pack. Keep the user's pack outside this folder.
5. **Check and fix.** Run `pw check <dir>` (or `pw cmd "<command>"` for loose commands, `pw check-json <type> <file>` for one JSON file). Fix every error. Read warnings and notes: fix them when they are right, keep your version when you have a reason (an id your own pack defines, a deliberate choice, evidence from the wiki or the game) and mention it in one line.
6. **Deliver.** `pw pack <dir>` makes a zip for `<world>/datapacks/`. Tell the user how to install and try it (`/reload`, `/function <ns>:give`), what each input does, and what to tune. Answer in the user's language.

The checker is a fast second pair of eyes, not a gate. A clean result means the syntax, ids and schemas are right for 1.21.8; it cannot see logic mistakes, so read `knowledge/pitfalls.md` for systems with many parts. When the user reports what happened in game, trust the game and adjust.

## When you are unsure

- Search the knowledge base first (`pw find`), then the data (`pw schema`, `pw vanilla --grep`).
- If you have web access, search: minecraft.wiki, the Java Edition 1.20.5 to 1.21.8 changelogs, misode.github.io generators and community examples. The wiki describes the newest version, so check its version history and confirm against `pw usage` and `pw schema`, which are exact for 1.21.8.
- Try ideas cheaply with `pw cmd`. It accepts many commands at once and macro lines starting with `$`.
- Tools beat memory. If a tool and a source disagree, say so and pick the safer option.

## Room to work

Vanilla 1.21.8 can build far more than it seems. Combine freely:

- **Items** (96 components): any item can be consumable with a custom duration and animation, equippable in any slot with a camera overlay, a glider, a weapon with its own damage and attack speed (`attribute_modifiers`, `weapon`), a shield (`blocks_attacks`), a tool with custom mining rules, a death-protection totem, damage resistant, with a vanilla cooldown overlay (`use_cooldown`), a custom model (`item_model`), rarity, glint, lore and hidden tooltips.
- **Events**: 57 advancement triggers, 30 enchantment effect components (`post_attack`, `hit_block`, `tick`, `projectile_spawned`, `damage_immunity`, `location_changed`, ...), scoreboard criteria for every statistic, predicates for player input keys, flags, equipment, location, weather and time.
- **State**: scores, tags, command storage, markers as data holders, macros for dynamic commands.
- **World and UI**: display entities for models, labels and animations, interaction entities as clickable hitboxes, particles, sounds, bossbars, titles, actionbars, sidebar with number formats, dialogs for menus and forms, waypoints.
- **Combat and movement**: `/damage` with damage types and kill credit, 35 attributes (`scale`, `gravity`, `jump_strength`, `step_height`, `safe_fall_distance`, `block_interaction_range`, `entity_interaction_range`, `knockback_resistance`, ...), effects, motion for mobs and projectiles, `tp` dashes, raycasts.
- **Math**: fixed point, vectors from rotations, square roots, random rolls.

A weapon can map several skills to different inputs with cooldowns, mana and an HUD, plus an on-hit passive and a charged ultimate. A boss can have phases, telegraphed attacks, minions, an arena, a bossbar, loot and an advancement. Both exist as complete, checked packs in `examples/`.

## Quality

- Namespace every objective, tag, storage, bossbar and modifier id (`ns.name`, `ns:name`).
- Prefer events (advancements, enchantment hooks, statistics) to polling; narrow every `@e` with `type=` and a tag.
- Keep per-player state in scores so the pack works with many players.
- Give every action feedback (sound, particles, actionbar), and give every system a load, a cleanup and an uninstall function.
- Create custom items from one loot table so `/loot`, drops and shops share one definition. A recipe result cannot call a loot table: repeat the item there and keep it identical.

## Tools

| Command | Use |
|---|---|
| `pw doctor` | verify the toolkit |
| `pw find <words>` | search knowledge, schema keys and ids |
| `pw id <id or name>` | find ids by id, English or Chinese name; `pw id --all <registry>` lists a registry |
| `pw block <id>` / `pw item <id>` | block states and tags / default item components and tags |
| `pw tag <registry> [tag]` | list vanilla tags or expand one |
| `pw usage <command> [words]` | exact 1.21.8 syntax; `--types` shows argument types |
| `pw schema <kind> <key>` | fields of a component, trigger, loot function, condition, entity, dialog, ...; `pw schema` lists kinds, `--flat` inlines inherited fields |
| `pw vanilla [path or words]` | vanilla data files; `--grep <text>` searches their contents |
| `pw lang <words>` | English texts and translation keys, also for error messages |
| `pw check <paths>` | check a pack folder or zip, `.mcfunction`, commands `.txt` or data `.json`; several packs are checked one by one, add `--merge` to check them as one map (cross-pack functions, objectives, tags); `--strict-names` also flags non-ASCII names |
| `pw check-json <type> <file / - / json>` | check JSON as a resource type (`loot_table`, `item_modifier`, `predicate`, `advancement`, `recipe`, `enchantment`, `dialog`, ...) |
| `pw cmd "<command>" ...` | check commands; `pw cmd -` reads lines from stdin |
| `pw new <dir> --ns <ns>` | create a pack skeleton with load and tick |
| `pw pack <dir> [-o file.zip]` | check and zip a pack |

Add `--json` to any command for machine-readable output. `pw check` exits with 1 when there are errors. When a shell mangles quotes (common on Windows), put the commands in a `.txt` or `.mcfunction` file and run `pw check <file>`, or pipe them into `pw cmd -`.

## Files

- `knowledge/INDEX.md`: map of the knowledge base and when to read each file.
- `knowledge/version-1.21.8.md`: version numbers, what does not exist yet, stale syntax and its 1.21.8 form.
- `knowledge/pitfalls.md`: logic mistakes the checker cannot see.
- `examples/storm-blade/`: a weapon with a dash, a frost nova, an on-hit chain lightning passive, cooldowns and an HUD.
- `examples/storm-king/`: a two-phase boss with telegraphed lightning, shockwaves, minions, an arena leash, a bossbar, loot and an advancement.
- `reference/`: the 1.21.8 data the tools read. Query it through the tools.
- `tests/run.py`: regression tests for the checker (`python3 tests/run.py`). Run them after changing anything in `tools/`.

This toolkit covers Minecraft Java Edition 1.21.8 only. For other versions, say that syntax may differ and verify with a source for that version.
