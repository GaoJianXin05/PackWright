import re

WILD = "\ue000"

_INT_LIMITS = {
    "b": (-128, 127),
    "s": (-32768, 32767),
    "i": (-2147483648, 2147483647),
    "l": (-9223372036854775808, 9223372036854775807),
}
_UINT_LIMITS = {"b": 255, "s": 65535, "i": 4294967295, "l": 18446744073709551615}
_UNQUOTED = re.compile(r"[0-9A-Za-z_\-.+" + WILD + r"]")
_NUMBER = re.compile(
    r"""(?P<sign>[-+])?(?:
        0[xX](?P<hex>[0-9a-fA-F](?:[0-9a-fA-F_]*[0-9a-fA-F])?)(?P<hsfx>[sSuU]?[bBsSiIlL])?
      | 0[bB](?P<bin>[01](?:[01_]*[01])?)(?P<bsfx>[sSuU]?[bBsSiIlL])?
      | (?P<dec>(?:\d(?:[\d_]*\d)?)?(?:\.(?:\d(?:[\d_]*\d)?)?)?)(?P<exp>[eE][-+]?\d(?:[\d_]*\d)?)?(?P<dsfx>[sSuU]?[bBsSiIlL]|[fFdD])?
    )$""",
    re.X,
)


class SnbtError(ValueError):
    def __init__(self, message, pos):
        super().__init__(message)
        self.message = message
        self.pos = pos


class N:
    __slots__ = ("value", "t", "boolean", "wild")

    def __init__(self, value, t, boolean=False, wild=False):
        self.value = value
        self.t = t
        self.boolean = boolean
        self.wild = wild

    def __repr__(self):
        return f"{self.value}{self.t}"

    def __eq__(self, other):
        if isinstance(other, N):
            return self.value == other.value
        if isinstance(other, (int, float)) and not isinstance(other, bool):
            return self.value == other
        return NotImplemented

    def __hash__(self):
        return hash(self.value)


class Arr(list):
    __slots__ = ("t",)

    def __init__(self, t, items):
        super().__init__(items)
        self.t = t


class Wild(str):
    pass


class S(str):
    __slots__ = ("quoted",)


def make_s(text, quoted):
    s = S(text)
    s.quoted = quoted
    return s


def parse_number(text):
    if WILD in text:
        return N(0, "", wild=True)
    m = _NUMBER.match(text)
    if not m or not text or text in ("+", "-", ".", "+.", "-."):
        return None
    sign = -1 if m.group("sign") == "-" else 1
    if m.group("hex") is not None or m.group("bin") is not None:
        digits = (m.group("hex") or m.group("bin")).replace("_", "")
        base = 16 if m.group("hex") is not None else 2
        sfx = (m.group("hsfx") or m.group("bsfx") or "").lower()
        value = int(digits, base) * sign
        return _int_with_suffix(value, sfx, text, True)
    dec = m.group("dec") or ""
    exp = m.group("exp")
    sfx = (m.group("dsfx") or "").lower()
    if not dec or dec == ".":
        return None
    is_float = "." in dec or exp is not None or sfx in ("f", "d")
    clean = dec.replace("_", "")
    if is_float:
        if sfx and sfx not in ("f", "d"):
            return None
        try:
            value = float(clean + (exp.replace("_", "") if exp else "")) * sign
        except ValueError:
            return None
        if value in (float("inf"), float("-inf")):
            raise SnbtError(f"number {text!r} is out of range", 0)
        if sfx == "f" and abs(value) > 3.4028235e38:
            raise SnbtError(f"float {text!r} is out of range", 0)
        return N(value, sfx or "d")
    if len(clean) > 1 and clean.startswith("0"):
        raise SnbtError(f"integer {text!r} has a leading zero", 0)
    value = int(clean) * sign
    return _int_with_suffix(value, sfx, text, False)


def _int_with_suffix(value, sfx, text, radix):
    unsigned = False
    if len(sfx) == 2:
        unsigned = sfx[0] == "u"
        sfx = sfx[1]
    t = sfx or "i"
    lo, hi = _INT_LIMITS[t]
    if unsigned:
        if value < 0 or value > _UINT_LIMITS[t]:
            raise SnbtError(f"number {text!r} is out of range for its type", 0)
    elif radix and value > hi and value <= _UINT_LIMITS[t] and not sfx:
        pass
    elif value < lo or value > hi:
        raise SnbtError(f"number {text!r} is out of range for its type", 0)
    return N(value, t)


_ESCAPES = {"\\": "\\", "'": "'", '"': '"', "b": "\b", "s": " ", "t": "\t", "n": "\n", "f": "\f", "r": "\r"}


class SnbtParser:
    def __init__(self, text, pos=0, allow_wild=True):
        self.s = text
        self.i = pos
        self.allow_wild = allow_wild
        self.depth = 0

    def err(self, msg, pos=None):
        raise SnbtError(msg, self.i if pos is None else pos)

    def ws(self):
        while self.i < len(self.s) and self.s[self.i] in " \t\r\n":
            self.i += 1

    def peek(self):
        return self.s[self.i] if self.i < len(self.s) else ""

    def value(self):
        self.ws()
        self.depth += 1
        if self.depth > 512:
            self.err("NBT nesting is too deep")
        try:
            c = self.peek()
            if c == "{":
                return self.compound()
            if c == "[":
                return self.list_or_array()
            if c in "\"'":
                return make_s(self.quoted(), True)
            if not c:
                self.err("expected a value")
            return self.literal()
        finally:
            self.depth -= 1

    def quoted(self):
        q = self.s[self.i]
        start = self.i
        self.i += 1
        out = []
        while True:
            if self.i >= len(self.s):
                self.err("unterminated string", start)
            c = self.s[self.i]
            if c == q:
                self.i += 1
                return "".join(out)
            if c == "\\":
                self.i += 1
                if self.i >= len(self.s):
                    self.err("unterminated escape", start)
                e = self.s[self.i]
                if e in _ESCAPES:
                    out.append(_ESCAPES[e])
                    self.i += 1
                elif e in "xuU":
                    n = {"x": 2, "u": 4, "U": 8}[e]
                    h = self.s[self.i + 1 : self.i + 1 + n]
                    if len(h) != n or not re.fullmatch(r"[0-9a-fA-F]+", h):
                        self.err(f"invalid \\{e} escape")
                    out.append(chr(int(h, 16)))
                    self.i += 1 + n
                elif e == "N":
                    m = re.match(r"N\{[^}]+\}", self.s[self.i :])
                    if not m:
                        self.err("invalid \\N{...} escape")
                    self.i += m.end()
                    out.append("?")
                else:
                    self.err(f"invalid escape \\{e}")
                continue
            out.append(c)
            self.i += 1

    def unquoted_word(self):
        start = self.i
        while self.i < len(self.s) and _UNQUOTED.match(self.s[self.i]):
            self.i += 1
        return self.s[start : self.i]

    def literal(self):
        start = self.i
        word = self.unquoted_word()
        if not word:
            c = self.peek()
            if c == ":" or (c.isalpha() and not c.isascii()):
                self.err(f"unexpected character {c!r}: quote this text, for example \"minecraft:stone\" or 'Storm Blade'")
            self.err(f"unexpected character {c!r}")
        self.ws()
        if self.peek() == "(" and word in ("bool", "uuid"):
            self.i += 1
            arg = self.value()
            self.ws()
            if self.peek() != ")":
                self.err("expected ')'")
            self.i += 1
            if word == "bool":
                return N(1, "b", boolean=True)
            return Arr("I", [N(0, "i")] * 4)
        if WILD in word:
            return Wild(word)
        if word in ("true", "false"):
            return N(1 if word == "true" else 0, "b", boolean=True)
        num = None
        try:
            num = parse_number(word)
        except SnbtError as e:
            self.err(e.message, start)
        if num is not None:
            return num
        if word[0] in "0123456789.+-":
            self.err(f"{word!r} is not a valid number, and unquoted text cannot start with a digit, '.', '+' or '-'", start)
        return make_s(word, False)

    def compound(self):
        self.i += 1
        out = {}
        self.ws()
        if self.peek() == "}":
            self.i += 1
            return out
        while True:
            self.ws()
            kpos = self.i
            c = self.peek()
            if c in "\"'":
                key = self.quoted()
            else:
                key = self.unquoted_word()
                if not key:
                    if c == "}":
                        self.err("trailing comma is allowed only once; remove the extra ','", kpos)
                    if c and not c.isascii():
                        self.err(f"key starting with {c!r} must be quoted", kpos)
                    self.err(f"expected a key, found {c!r}" if c else "expected a key", kpos)
            self.ws()
            if self.peek() != ":":
                if self.peek() == "=":
                    self.err("SNBT uses ':' between key and value, not '='")
                self.err(f"expected ':' after key {key!r}")
            self.i += 1
            if key in out:
                self.err(f"duplicate key {key!r}", kpos)
            out[key] = self.value()
            self.ws()
            c = self.peek()
            if c == ",":
                self.i += 1
                self.ws()
                if self.peek() == "}":
                    self.i += 1
                    return out
                continue
            if c == "}":
                self.i += 1
                return out
            self.err("expected ',' or '}' in compound" if c else "unterminated compound: missing '}'")

    def list_or_array(self):
        self.i += 1
        m = re.match(r"([BIL]);", self.s[self.i : self.i + 2])
        if m:
            t = m.group(1)
            self.i += 2
            items = []
            self.ws()
            if self.peek() == "]":
                self.i += 1
                return Arr(t, items)
            while True:
                v = self.value()
                if not isinstance(v, (N, Wild)):
                    self.err(f"[{t};...] arrays contain only numbers")
                items.append(v)
                self.ws()
                c = self.peek()
                if c == ",":
                    self.i += 1
                    self.ws()
                    if self.peek() == "]":
                        self.i += 1
                        return Arr(t, items)
                    continue
                if c == "]":
                    self.i += 1
                    return Arr(t, items)
                self.err("expected ',' or ']' in array")
        items = []
        self.ws()
        if self.peek() == "]":
            self.i += 1
            return items
        while True:
            items.append(self.value())
            self.ws()
            c = self.peek()
            if c == ",":
                self.i += 1
                self.ws()
                if self.peek() == "]":
                    self.i += 1
                    return items
                continue
            if c == "]":
                self.i += 1
                return items
            self.err("expected ',' or ']' in list" if c else "unterminated list: missing ']'")


def parse(text, pos=0, whole=True):
    p = SnbtParser(text, pos)
    v = p.value()
    if whole:
        p.ws()
        if p.i < len(text):
            raise SnbtError(f"unexpected text after the value: {text[p.i:p.i+20]!r}", p.i)
    return v, p.i


def parse_at(text, pos):
    p = SnbtParser(text, pos)
    v = p.value()
    return v, p.i


def to_plain(v):
    if isinstance(v, N):
        return v.value
    if isinstance(v, dict):
        return {k: to_plain(x) for k, x in v.items()}
    if isinstance(v, list):
        return [to_plain(x) for x in v]
    return v
