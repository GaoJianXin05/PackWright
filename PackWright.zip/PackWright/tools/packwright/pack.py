import json
import re
import zipfile
from pathlib import Path, PurePosixPath

from . import data, schema
from .commands import Diag, check_command, macro_prepare
from .snbt import WILD

PLURAL = {
    "functions": "function", "advancements": "advancement", "loot_tables": "loot_table",
    "predicates": "predicate", "recipes": "recipe", "item_modifiers": "item_modifier",
    "structures": "structure",
}
PLURAL_TAGS = {
    "functions": "function", "items": "item", "blocks": "block", "entity_types": "entity_type",
    "fluids": "fluid", "game_events": "game_event",
}
NS_RE = re.compile(r"^[a-z0-9_.\-]+$")
PATH_RE = re.compile(r"^[a-z0-9_.\-/]+$")
TEXT_EXT = {".mcfunction", ".json", ".mcmeta", ".txt", ".md"}


class File:
    __slots__ = ("path", "text", "raw", "shown")

    def __init__(self, path, raw):
        self.path = path
        self.raw = raw
        self.text = None
        self.shown = path


class Report:
    def __init__(self, target):
        self.target = target
        self.diags = []
        self.stats = {"files": 0, "functions": 0, "commands": 0, "json": 0}
        self.kind = "pack"

    def add(self, d):
        self.diags.append(d)

    def counts(self):
        c = {"error": 0, "warning": 0, "info": 0}
        for d in self.diags:
            c[d.severity] = c.get(d.severity, 0) + 1
        return c

    def status(self):
        c = self.counts()
        if c["error"]:
            return "ERRORS"
        if c["warning"]:
            return "WARNINGS"
        return "OK"

    def to_dict(self):
        return {
            "target": self.target,
            "kind": self.kind,
            "minecraft": "1.21.8",
            "status": self.status(),
            "counts": self.counts(),
            "stats": self.stats,
            "diagnostics": [d.to_dict() for d in self.diags],
        }


def load_dir(root):
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(root).as_posix()
            if any(part.startswith(".") for part in rel.split("/")):
                continue
            files.append(File(rel, p.read_bytes()))
    return files


def load_zip(path):
    files = []
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        prefix = ""
        if "pack.mcmeta" not in names:
            metas = [n for n in names if n.endswith("/pack.mcmeta") and n.count("/") == 1]
            if len(metas) == 1:
                prefix = metas[0][: -len("pack.mcmeta")]
        for n in names:
            if prefix and not n.startswith(prefix):
                continue
            rel = n[len(prefix) :]
            if "\\" in n:
                continue
            files.append(File(rel, z.read(n)))
    return files, prefix


def decode(f, report):
    if f.text is not None:
        return f.text
    raw = f.raw
    if raw.startswith(b"\xef\xbb\xbf"):
        report.add(Diag("warning", "UTF8_BOM", "file starts with a UTF-8 BOM; save as UTF-8 without BOM", file=f.shown))
        raw = raw[3:]
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        report.add(Diag("error", "NOT_UTF8", "file is UTF-16; Minecraft needs UTF-8", "on Windows PowerShell write with -Encoding utf8 or use an editor", file=f.shown))
        f.text = raw.decode("utf-16", errors="replace")
        return f.text
    try:
        f.text = raw.decode("utf-8")
    except UnicodeDecodeError:
        report.add(Diag("error", "NOT_UTF8", "file is not valid UTF-8", file=f.shown))
        f.text = raw.decode("utf-8", errors="replace")
    return f.text


class DupKey(ValueError):
    pass


def strict_json(text):
    def hook(pairs):
        out = {}
        for k, v in pairs:
            if k in out:
                raise DupKey(k)
            out[k] = v
        return out

    return json.loads(text, object_pairs_hook=hook)


def parse_json(f, report):
    text = decode(f, report)
    try:
        return strict_json(text), True
    except DupKey as e:
        report.add(Diag("warning", "JSON_DUPLICATE_KEY", f"duplicate key {str(e)!r}; the last one wins", file=f.shown))
        return json.loads(text), True
    except json.JSONDecodeError as e:
        hint = ""
        if "//" in text or "/*" in text:
            hint = "JSON files cannot contain comments"
        elif re.search(r",\s*[}\]]", text):
            hint = "remove the trailing comma"
        report.add(Diag("error", "JSON_SYNTAX", f"invalid JSON: {e.msg}", hint, file=f.shown, line=e.lineno, col=e.colno))
        return None, False


def function_lines(text):
    lines = text.split("\n")
    out = []
    i = 0
    while i < len(lines):
        line = lines[i].rstrip("\r")
        start = i + 1
        stripped = line.strip()
        while stripped.endswith("\\") and not stripped.startswith("#") and i + 1 < len(lines):
            i += 1
            nxt = lines[i].rstrip("\r").strip()
            stripped = stripped[:-1] + nxt
        out.append((start, stripped))
        i += 1
    return out


class World:
    """What the cross-file checks know. One world can hold several packs (pw check --merge)."""

    def __init__(self):
        self.functions = {}  # function id -> File
        self.macro_functions = set()
        self.resources = {}
        self.tags = {}
        self.namespaces = set()
        self.refs = []
        self.uses = []
        self.calls = {}
        self.tag_members = {}
        self.created = {"objective": set(), "team": set(), "tag": set()}
        self.fn_calls = {}  # function id -> [(callee, is_tag, has_executor, has_position, line)]
        self.fn_flags = {}  # function id -> [(line, "exec" | "pos", what, col, text)]
        self.schedules = []  # (callee, is_tag)


class PackChecker:
    def __init__(self, files, target, report=None, world=None):
        self.files = files
        self.report = report or Report(target)
        w = self.world = world or World()
        self.functions = w.functions
        self.macro_functions = w.macro_functions
        self.resources = w.resources
        self.tags = w.tags
        self.namespaces = w.namespaces
        self.refs = w.refs
        self.uses = w.uses
        self.calls = w.calls
        self.tag_members = w.tag_members
        self.created = w.created

    def add(self, *a, **k):
        self.report.add(Diag(*a, **k))

    def run(self):
        self.prepare()
        self.finish()
        return self.report

    def finish(self):
        self.cross_check()
        self.contexts()

    def prepare(self):
        r = self.report
        r.stats["files"] += len(self.files)
        names = {f.path for f in self.files}
        if "pack.mcmeta" not in names:
            nested = [n for n in names if n.endswith("/pack.mcmeta")]
            if nested:
                self.add("error", "MCMETA_LOCATION", f"pack.mcmeta is not at the pack root (found {nested[0]})", "zip or check the folder that directly contains pack.mcmeta and data/")
            else:
                self.add("error", "MCMETA_MISSING", "pack.mcmeta is missing at the pack root", 'add {"pack":{"pack_format":81,"description":"..."}}')
        lower = {}
        for f in self.files:
            key = f.path.lower()
            if key in lower:
                self.add("warning", "CASE_COLLISION", f"{f.path} and {lower[key]} differ only in case", file=f.shown)
            lower[key] = f.path
        for f in self.files:
            self.classify(f)
        for f in self.files:
            self.check_file(f)

    def classify(self, f):
        parts = f.path.split("/")
        if parts[0] != "data" or len(parts) < 4:
            return
        ns = parts[1]
        self.namespaces.add(ns)
        reg, rest = self.registry_of(parts[2:])
        if reg is None:
            return
        ext = ".mcfunction" if reg == "function" else (".nbt" if reg == "structure" else ".json")
        if not rest.endswith(ext):
            return
        rid = f"{ns}:{rest[: -len(ext)]}"
        if reg.startswith("tags/"):
            self.tags.setdefault(reg[5:], set()).add(rid)
        else:
            self.resources.setdefault(reg, set()).add(rid)

    def registry_of(self, parts):
        dirs = data.profile()["data_dirs"]
        if parts[0] == "tags" and len(parts) >= 3:
            for n in (2, 1):
                cand = "/".join(parts[1 : 1 + n])
                if cand in data.registry_sets() or cand in ("function", "worldgen/biome", "worldgen/structure", "worldgen/flat_level_generator_preset", "worldgen/world_preset"):
                    if len(parts) > 1 + n:
                        return "tags/" + cand, "/".join(parts[1 + n :])
            return None, ""
        if parts[0] == "worldgen" and len(parts) >= 3:
            cand = "worldgen/" + parts[1]
            if cand in dirs:
                return cand, "/".join(parts[2:])
            return None, ""
        if parts[0] in dirs:
            return parts[0], "/".join(parts[1:])
        return None, ""

    def check_file(self, f):
        path = f.path
        parts = path.split("/")
        if path == "pack.mcmeta":
            self.check_mcmeta(f)
            return
        if path == "pack.png":
            return
        if parts[0] != "data":
            if parts[0] == "assets":
                self.add("info", "RESOURCE_PACK_FILE", "assets/ belongs to a resource pack; a data pack ignores it", file=f.shown)
            elif path.endswith((".mcfunction", ".json")):
                self.add("error", "FILE_LOCATION", "data pack files must be under data/<namespace>/<folder>/", file=f.shown)
            return
        if len(parts) < 4:
            self.add("error", "FILE_LOCATION", "expected data/<namespace>/<folder>/<file>", file=f.shown)
            return
        ns = parts[1]
        if not NS_RE.match(ns):
            self.add("error", "NAMESPACE", f"invalid namespace {ns!r}", "namespaces use only a-z 0-9 _ - .", file=f.shown)
            return
        folder = parts[2]
        if folder in PLURAL:
            self.add("error", "PLURAL_FOLDER", f"folder {folder}/ was renamed to {PLURAL[folder]}/ in 1.21; files here are ignored", f"move to data/{ns}/{PLURAL[folder]}/", file=f.shown)
            return
        if folder == "tags" and len(parts) > 3 and parts[3] in PLURAL_TAGS:
            self.add("error", "PLURAL_FOLDER", f"folder tags/{parts[3]}/ was renamed to tags/{PLURAL_TAGS[parts[3]]}/ in 1.21; files here are ignored", f"move to data/{ns}/tags/{PLURAL_TAGS[parts[3]]}/", file=f.shown)
            return
        reg, rest = self.registry_of(parts[2:])
        if reg is None:
            known = data.profile()["data_dirs"]
            sug = schema.suggest(folder, known)
            self.add("warning", "UNKNOWN_FOLDER", f"data/{ns}/{folder}/ is not a 1.21.8 data pack folder; files in it are ignored", ("did you mean " + ", ".join(sug)) if sug else "", file=f.shown)
            return
        ext = ".mcfunction" if reg == "function" else (".nbt" if reg == "structure" else ".json")
        if not rest.endswith(ext):
            self.add("warning", "FILE_EXTENSION", f"files in {reg}/ must end with {ext}; this file is ignored", file=f.shown)
            return
        rpath = rest[: -len(ext)]
        if not rpath or not PATH_RE.match(rpath):
            hint = "use lower-case a-z 0-9 _ - . / only" + ("; Chinese file names are not allowed" if not rpath.isascii() else "")
            self.add("error", "RESOURCE_PATH", f"invalid resource path {rpath!r}", hint, file=f.shown)
            return
        rid = f"{ns}:{rpath}"
        if reg == "structure":
            return
        if reg == "function":
            self.check_function(f, rid)
            return
        value, ok = parse_json(f, self.report)
        self.report.stats["json"] += 1
        if not ok:
            return
        if reg.startswith("tags/"):
            self.check_tag(f, reg[5:], rid, value)
            return
        disp = schema.dispatchers().get("minecraft:resource", {})
        if reg in disp:
            ctx = schema.Ctx(strict=True, snbt=False)
            issues = schema.validate(value, {"k": "dispatch", "reg": "minecraft:resource", "keys": [reg]}, ctx)
            for iss in issues[:60]:
                sev = schema.severity(iss, ctx)
                where = iss.where()
                self.add(sev, iss.code or ("LEGACY_SYNTAX" if iss.kind == "legacy" else "SCHEMA"), (f"{where}: " if where else "") + iss.message, iss.hint, file=f.shown)
            if len(issues) > 60:
                self.add("info", "MORE", f"{len(issues) - 60} more schema findings not shown", file=f.shown)
            for ref in ctx.refs:
                self.refs.append((ref.registry, ref.id, ref.tag, f.shown, None))
            self.scan_json(value, f.shown)
        if reg == "advancement" and isinstance(value, dict):
            self.check_advancement(value, f.shown)
        if reg == "recipe" and isinstance(value, dict) and data.strip_ns(str(value.get("type", ""))) == "crafting_shaped":
            self.check_shaped(value, f.shown)

    def scan_json(self, value, path, depth=0):
        if depth > 60:
            return
        if isinstance(value, dict):
            for k, v in value.items():
                if k in ("command",) and isinstance(v, str) and isinstance(value.get("type") or value.get("action"), str):
                    act = data.strip_ns(str(value.get("type") or value.get("action")))
                    if act == "run_command":
                        cmd = v[1:] if v.startswith("/") else v
                        for d in check_command(cmd)[0]:
                            if d.severity == "error":
                                self.add("warning", "CLICK_COMMAND", f"run_command {cmd[:60]!r} will fail: {d.message}", d.hint, file=path)
                if k == "template" and isinstance(v, str) and data.strip_ns(str(value.get("type", ""))) == "dynamic/run_command":
                    text, names, bad = macro_prepare(v[1:] if v.startswith("/") else v)
                    for d in check_command(text, macro=True)[0]:
                        if d.severity == "error":
                            self.add("warning", "DIALOG_TEMPLATE", f"dynamic/run_command template may fail: {d.message}", d.hint, file=path)
                self.scan_json(v, path, depth + 1)
        elif isinstance(value, list):
            for v in value:
                self.scan_json(v, path, depth + 1)

    def check_advancement(self, value, path):
        crit = value.get("criteria")
        req = value.get("requirements")
        if isinstance(crit, dict) and isinstance(req, list):
            names = set(crit)
            used = set()
            for group in req:
                if isinstance(group, list):
                    for n in group:
                        if isinstance(n, str):
                            used.add(n)
                            if n not in names:
                                self.add("error", "ADVANCEMENT_REQUIREMENT", f"requirements mention {n!r}, which is not in criteria", file=path)
            for n in names - used:
                self.add("warning", "ADVANCEMENT_UNUSED_CRITERION", f"criterion {n!r} is not listed in requirements, so it never matters", file=path)
        rewards = value.get("rewards")
        if isinstance(rewards, dict) and isinstance(rewards.get("function"), str):
            fid = rewards["function"]
            self.calls.setdefault("@advancement", set()).add(fid if ":" in fid else "minecraft:" + fid)

    def check_shaped(self, value, path):
        pattern = value.get("pattern")
        key = value.get("key")
        if not isinstance(pattern, list) or not all(isinstance(r, str) for r in pattern) or not isinstance(key, dict):
            return
        if not 1 <= len(pattern) <= 3 or len({len(r) for r in pattern}) != 1 or not 1 <= len(pattern[0]) <= 3:
            self.add("error", "RECIPE_PATTERN", "pattern rows must all have the same width, 1 to 3 rows of 1 to 3 characters", "pad short rows with spaces", file=path)
        used = {c for r in pattern for c in r if c != " "}
        for c in sorted(used - set(key)):
            self.add("error", "RECIPE_PATTERN", f"pattern symbol {c!r} is not defined in key", file=path)
        for c in sorted(set(key) - used):
            self.add("error", "RECIPE_PATTERN", f"key symbol {c!r} is never used in the pattern; the recipe fails to load", file=path)
        if " " in key:
            self.add("error", "RECIPE_PATTERN", "' ' is reserved for empty slots and cannot be a key", file=path)

    def check_mcmeta(self, f):
        value, ok = parse_json(f, self.report)
        if not ok:
            return
        if not isinstance(value, dict) or not isinstance(value.get("pack"), dict):
            self.add("error", "MCMETA", 'pack.mcmeta needs a "pack" object', file=f.shown)
            return
        pack = value["pack"]
        fmt = pack.get("pack_format")
        target = data.profile()["pack_format"]
        if not isinstance(fmt, int) or isinstance(fmt, bool):
            self.add("error", "MCMETA_FORMAT", "pack.pack_format must be an integer (81 for 1.21.8)", file=f.shown)
        elif fmt != target:
            sf = pack.get("supported_formats")
            covered = False
            if isinstance(sf, int):
                covered = sf == target
            elif isinstance(sf, list) and len(sf) == 2 and all(isinstance(x, int) for x in sf):
                covered = sf[0] <= target <= sf[1]
            elif isinstance(sf, dict):
                lo, hi = sf.get("min_inclusive"), sf.get("max_inclusive")
                covered = isinstance(lo, int) and isinstance(hi, int) and lo <= target <= hi
            if not covered:
                self.add("warning", "MCMETA_FORMAT", f"pack_format {fmt} is not 1.21.8's format {target}; the game marks the pack as made for another version", f"set pack_format to {target}", file=f.shown)
        if "description" not in pack:
            self.add("error", "MCMETA_DESCRIPTION", "pack.description is required", file=f.shown)
        else:
            ctx = schema.Ctx(strict=True)
            for iss in schema.validate(pack["description"], {"k": "ref", "path": "::java::util::text::Text"}, ctx):
                self.add(schema.severity(iss, ctx), "MCMETA_DESCRIPTION", "description: " + iss.message, iss.hint, file=f.shown)
        for key in ("min_format", "max_format"):
            if key in pack:
                self.add("info", "MCMETA_FIELD", f"{key} is a 1.21.9+ field; 1.21.8 ignores it", file=f.shown)

    def check_tag(self, f, registry, rid, value):
        path = f.shown
        if not isinstance(value, dict):
            self.add("error", "TAG", 'a tag file must be an object like {"values":[...]}', file=path)
            return
        if not isinstance(value.get("values"), list):
            self.add("error", "TAG", 'a tag needs a "values" list', file=path)
            return
        if "replace" in value and not isinstance(value["replace"], bool):
            self.add("error", "TAG", '"replace" must be true or false', file=path)
        for k in value:
            if k not in ("values", "replace"):
                self.add("warning", "TAG", f"unknown field {k!r} in tag (ignored)", file=path)
        members = []
        for entry in value["values"]:
            required = True
            if isinstance(entry, dict):
                ident = entry.get("id")
                required = entry.get("required", True)
                if not isinstance(ident, str) or set(entry) - {"id", "required"} or not isinstance(required, bool):
                    self.add("error", "TAG_ENTRY", 'tag entries are "ns:id", "#ns:tag" or {"id":"ns:id","required":false}', file=path)
                    continue
            elif isinstance(entry, str):
                ident = entry
            else:
                self.add("error", "TAG_ENTRY", f"invalid tag entry {entry!r}", file=path)
                continue
            is_tag = ident.startswith("#")
            body = ident[1:] if is_tag else ident
            if not schema.RL_RE.match(body):
                self.add("error", "TAG_ENTRY", f"{ident!r} is not a valid id", "ids are lower-case namespace:path", file=path)
                continue
            full = body if ":" in body else "minecraft:" + body
            members.append((full, is_tag))
            if not required:
                continue
            if is_tag:
                self.refs.append((registry, full, True, path, "tag"))
            elif registry == "function":
                self.refs.append(("function", full, False, path, "tag"))
            else:
                ns, p = data.split_id(full)
                reg = data.registry_sets().get(registry)
                if ns == "minecraft" and reg is not None and p not in reg and registry not in schema.DATA_DRIVEN:
                    sug = schema.suggest(p, list(reg))
                    self.add("error", "TAG_ENTRY", f"{full} is not a 1.21.8 {registry}; the whole tag fails to load", ("did you mean " + ", ".join(sug)) if sug else "", file=path)
                elif registry in schema.DATA_DRIVEN or ns != "minecraft":
                    self.refs.append((registry, full, False, path, "tag"))
        key = (registry, rid)
        if value.get("replace") is True or key not in self.tag_members:
            self.tag_members[key] = members
        else:
            self.tag_members[key] = self.tag_members[key] + members

    def check_function(self, f, rid):
        text = decode(f, self.report)
        self.report.stats["functions"] += 1
        before = self.functions.get(rid)
        if before is not None and before is not f:
            self.add("warning", "DUPLICATE_FUNCTION", f"{rid} is also defined in {before.shown}; only one of the two is used", "rename one of them, or make sure the pack that should win loads last", file=f.shown)
        self.functions[rid] = f
        calls = self.calls.setdefault(rid, set())
        count = 0
        has_macro = False
        for line_no, line in function_lines(text):
            if not line or line.startswith("#"):
                continue
            count += 1
            macro = False
            if line.startswith("/"):
                self.add("error", "LEADING_SLASH", "commands in .mcfunction files must not start with '/'", file=f.shown, line=line_no)
                line = line[1:]
            if line.startswith("$"):
                macro = True
                has_macro = True
                body = line[1:]
                text2, names, bad = macro_prepare(body)
                if not names and "$(" not in text2:
                    self.add("error", "MACRO_NO_VARIABLE", "a macro line ($...) must contain at least one $(name)", "remove the leading $ or add a variable", file=f.shown, line=line_no)
                for b in bad:
                    self.add("error", "MACRO_NAME", f"invalid macro variable name $({b})", "use letters, digits and _ only", file=f.shown, line=line_no)
                if "$(" in text2:
                    self.add("error", "MACRO_UNCLOSED", "a $( in this macro line has no closing )", "write $(name) with the closing parenthesis; the function fails to load otherwise", file=f.shown, line=line_no)
                cmd = text2
            else:
                if "$(" in line:
                    self.add("warning", "MACRO_NOT_MARKED", "this line uses $(...) but does not start with $, so it is not a macro line", "start the line with $", file=f.shown, line=line_no)
                cmd = line
            self.report.stats["commands"] += 1
            diags, ctx = check_command(cmd, macro=macro)
            for d in diags:
                d.file = f.shown
                d.line = line_no
                d.text = "" if macro else cmd
                if macro and d.severity == "error":
                    d.severity = "warning"
                    d.message = "(macro line, checked with placeholders) " + d.message
                self.report.add(d)
            for reg, ident, is_tag, pos in ctx.refs:
                self.refs.append((reg, ident, is_tag, f.shown, line_no))
                if reg == "function":
                    calls.add(("#" if is_tag else "") + ident)
            for kind, value, role, pos in ctx.uses:
                self.uses.append((kind, value, f.shown, line_no))
            self.scan_creates(cmd, f.shown, line_no, ctx)
            if re.match(r"^(?:execute\b.*\brun\s+)?function\s+\S+\s*$", cmd):
                m = re.search(r"function\s+(#?)(\S+)\s*$", cmd)
                if m and not m.group(1):
                    target = m.group(2) if ":" in m.group(2) else "minecraft:" + m.group(2)
                    self.calls.setdefault("@plain", set()).add((target, f.shown, line_no))
            chain = ctx.chain
            if chain:
                shown_text = "" if macro else cmd
                for callee, is_tag, has_exec, has_pos in chain["calls"]:
                    self.world.fn_calls.setdefault(rid, []).append((callee, is_tag, has_exec, has_pos, line_no))
                for callee, is_tag in chain["schedules"]:
                    self.world.schedules.append((callee, is_tag))
                for what, col in chain["s_no_exec"]:
                    self.world.fn_flags.setdefault(rid, []).append((line_no, "exec", what, col, shown_text))
                if chain["rel_no_pos"]:
                    self.world.fn_flags.setdefault(rid, []).append((line_no, "pos", "", chain["rel_no_pos"][0], shown_text))
        if count == 0:
            self.add("info", "EMPTY_FUNCTION", "function has no commands", file=f.shown)
        if has_macro:
            self.macro_functions.add(rid)

    def scan_creates(self, cmd, path, line, ctx):
        for m in re.finditer(r"\bscoreboard objectives add (\S+)", cmd):
            self.created["objective"].add(m.group(1))
        for m in re.finditer(r"\bteam add (\S+)", cmd):
            self.created["team"].add(m.group(1))
        for m in re.finditer(r"\btag \S+ add (\S+)", cmd):
            self.created["tag"].add(m.group(1))
        for m in re.finditer(r"Tags:\[([^\]]*)\]", cmd):
            for t in re.findall(r"[\"']?([^,\s\"']+)[\"']?", m.group(1)):
                self.created["tag"].add(t)

    def exists(self, registry, ident, is_tag):
        if is_tag:
            if ident in self.tags.get(registry, set()):
                return True
            ns, p = data.split_id(ident)
            if ns == "minecraft" and data.has_tag(registry, ident):
                return True
            return False
        if registry == "function":
            return ident in self.functions
        if ident in self.resources.get(registry, set()):
            return True
        ns, p = data.split_id(ident)
        if ns == "minecraft" and p in data.registry_sets().get(registry, ()):
            return True
        return False

    def cross_check(self):
        seen = set()
        for registry, ident, is_tag, path, line in self.refs:
            key = (registry, ident, is_tag, path, line)
            if key in seen:
                continue
            seen.add(key)
            if WILD in ident:
                continue
            ns, p = data.split_id(ident)
            if self.exists(registry, ident, is_tag):
                continue
            label = ("#" if is_tag else "") + ident
            if line == "tag":
                if ns in self.namespaces or ns == "minecraft":
                    self.add("error", "TAG_MISSING_ENTRY", f"tag entry {label} does not exist; the whole tag fails to load", 'add the file, fix the id, or use {"id":"...","required":false}', file=path)
                continue
            if ns in self.namespaces:
                folder = ("tags/" + registry) if is_tag else registry
                ext = ".mcfunction" if registry == "function" else ".json"
                self.add("warning", "MISSING_RESOURCE", f"{label} is referenced but data/{ns}/{folder}/{p}{ext} is not in this pack", "add the file or fix the id", file=path, line=line)
            elif ns == "minecraft" and registry in schema.DATA_DRIVEN and registry not in ("function", "predicate", "item_modifier"):
                pool = list(data.registry_sets().get(registry, ()))
                sug = schema.suggest(p, pool)
                self.add("warning", "MISSING_RESOURCE", f"{label} is not a vanilla {registry} and is not defined in this pack", ("did you mean " + ", ".join(sug)) if sug else "", file=path, line=line)
            elif ns == "minecraft" and registry in ("function", "predicate", "item_modifier"):
                self.add("warning", "MISSING_RESOURCE", f"{label} is not defined in this pack (vanilla has no {registry}s)", file=path, line=line)
        for target, path, line in sorted(self.calls.get("@plain", set())):
            if target in self.macro_functions:
                self.add("warning", "MACRO_WITHOUT_ARGS", f"{target} contains macro lines but is called without 'with ...' or an SNBT argument", "call it as: function " + target + " {key:value} or ... with storage ns:x path", file=path, line=line)
        used = {}
        for kind, value, path, line in self.uses:
            if kind in self.created and WILD not in value:
                used.setdefault((kind, value), (path, line))
        if self.functions:
            for (kind, value), (path, line) in sorted(used.items()):
                if kind == "objective" and value not in self.created["objective"]:
                    self.add("warning", "OBJECTIVE_NOT_CREATED", f"objective {value!r} is used but never created in this pack", f"add 'scoreboard objectives add {value} dummy' to your load function", file=path, line=line)
                elif kind == "team" and value not in self.created["team"]:
                    self.add("info", "TEAM_NOT_CREATED", f"team {value!r} is used but never created in this pack", file=path, line=line)
                elif kind == "tag" and value not in self.created["tag"]:
                    self.add("info", "TAG_NOT_ADDED", f"entity tag {value!r} is tested but never added in this pack", file=path, line=line)
        load = self.tag_members.get(("function", "minecraft:load"))
        tick = self.tag_members.get(("function", "minecraft:tick"))
        if self.created["objective"] and load is None and self.functions:
            self.add("info", "NO_LOAD_TAG", "objectives are created but there is no data/minecraft/tags/function/load.json", "run setup from #minecraft:load so it happens on /reload")
        if tick:
            reach = self.reachable([m for m, t in tick if not t])
            for fid in sorted(reach):
                fobj = self.functions.get(fid)
                if not fobj:
                    continue
                for line_no, line in function_lines(fobj.text or ""):
                    if re.search(r"@e(?![\[\w])", line) or re.search(r"@e\[(?![^\]]*(?:type=|tag=|distance=|limit=|predicate=))[^\]]*\]", line):
                        self.add("info", "TICK_PERFORMANCE", "@e without type/tag/distance runs over every entity each tick", "narrow it with type=, tag= or distance=", file=fobj.shown, line=line_no)
                        break

    def contexts(self):
        """Follow calls from #minecraft:tick, #minecraft:load and `schedule function`: those run as the server,
        with no executor and with the world spawn as position, unless an `execute as` / `at` on the way changes that."""
        w = self.world
        if not w.fn_flags:
            return

        def expand(ident, is_tag, seen=None):
            if not is_tag:
                return [ident]
            seen = seen if seen is not None else set()
            if ident in seen:
                return []
            seen.add(ident)
            out = []
            for member, member_is_tag in w.tag_members.get(("function", ident), []):
                out.extend(expand(member, member_is_tag, seen))
            return out

        parent = {}
        queue = []

        def start(fid, origin):
            node = (fid, False, False)
            if node not in parent and fid in self.functions:
                parent[node] = (None, origin)
                queue.append(node)

        for tag_id, origin in (("minecraft:tick", "#minecraft:tick"), ("minecraft:load", "#minecraft:load")):
            for fid in expand(tag_id, True):
                start(fid, origin)
        for callee, is_tag in w.schedules:
            for fid in expand(callee, is_tag):
                start(fid, "schedule function")
        i = 0
        while i < len(queue):
            node = queue[i]
            i += 1
            fid, has_exec, has_pos = node
            for callee, is_tag, call_exec, call_pos, _ in w.fn_calls.get(fid, ()):
                for target in expand(callee, is_tag):
                    nxt = (target, has_exec or call_exec, has_pos or call_pos)
                    if nxt not in parent and target in self.functions:
                        parent[nxt] = (node, None)
                        queue.append(nxt)

        def route(node):
            names = []
            origin = ""
            while node is not None:
                names.append(node[0])
                node, org = parent[node]
                origin = org or origin
            names.reverse()
            if len(names) > 4:
                names = names[:2] + ["..."] + names[-2:]
            return origin + " -> " + " -> ".join(names) if names else origin

        depth = {}
        for node in parent:
            n, cur = 0, node
            while parent[cur][0] is not None:
                cur = parent[cur][0]
                n += 1
            depth[node] = n
        by_function = {}
        for node in parent:
            by_function.setdefault(node[0], []).append(node)
        for fid, flags in sorted(w.fn_flags.items()):
            nodes = by_function.get(fid)
            if not nodes:
                continue
            fobj = self.functions[fid]
            done = set()
            for line_no, kind, what, col, text in flags:
                if (line_no, kind) in done:
                    continue
                bad = [n for n in nodes if not (n[1] if kind == "exec" else n[2])]
                if not bad:
                    continue
                done.add((line_no, kind))
                where = route(min(bad, key=lambda n: depth[n]))
                if kind == "exec":
                    self.add("warning", "NO_CONTEXT", f"{what} selects nothing here: the function runs as the server ({where}) and no 'execute as' on the way sets an executor", "call it as: execute as @a run function ...  (add 'at @s' if it also uses ~ ~ ~)", file=fobj.shown, line=line_no, col=col + 1, text=text)
                else:
                    self.add("info", "NO_POSITION", f"~ / ^ are relative to the world spawn here: the function runs as the server ({where}) and nothing on the way uses 'at' or 'positioned'", "call it as: execute as @a at @s run function ...", file=fobj.shown, line=line_no, col=col + 1, text=text)

    def reachable(self, roots):
        out = set()
        stack = list(roots)
        while stack:
            fid = stack.pop()
            if fid.startswith("#"):
                members = self.tag_members.get(("function", fid[1:]), [])
                stack.extend(("#" + m) if t else m for m, t in members)
                continue
            if fid in out:
                continue
            out.add(fid)
            for c in self.calls.get(fid, set()):
                if isinstance(c, str):
                    stack.append(c)
        return out


def check_commands_text(text, target):
    rep = Report(target)
    rep.kind = "commands"
    for line_no, line in function_lines(text):
        if not line or line.startswith("#"):
            continue
        macro = line.startswith("$")
        cmd = line[1:] if macro else line
        if macro:
            cmd, names, bad = macro_prepare(cmd)
            if not names and "$(" not in cmd:
                rep.add(Diag("error", "MACRO_NO_VARIABLE", "a macro line ($...) must contain at least one $(name)", "remove the leading $ or add a variable", file=target, line=line_no))
            for b in bad:
                rep.add(Diag("error", "MACRO_NAME", f"invalid macro variable name $({b})", "use letters, digits and _ only", file=target, line=line_no))
            if "$(" in cmd:
                rep.add(Diag("error", "MACRO_UNCLOSED", "a $( in this macro line has no closing )", "write $(name) with the closing parenthesis", file=target, line=line_no))
        rep.stats["commands"] += 1
        diags, ctx = check_command(cmd, macro=macro)
        for d in diags:
            d.line = line_no
            d.file = target
            d.text = "" if macro else cmd
            if macro and d.severity == "error":
                d.severity = "warning"
                d.message = "(macro line, checked with placeholders) " + d.message
            rep.add(d)
    return rep


def load_pack(p):
    """Files of a pack folder or zip, and the notes to show about how it was found."""
    if p.is_dir():
        files = load_dir(p)
        if not any(f.path == "pack.mcmeta" for f in files) and (p / "data").is_dir() is False:
            sub = [d for d in p.iterdir() if d.is_dir() and (d / "pack.mcmeta").exists()]
            if len(sub) == 1:
                files = load_dir(sub[0])
                p = sub[0]
        return files, [], p
    files, prefix = load_zip(p)
    notes = []
    if prefix:
        notes.append(Diag("info", "ZIP_PREFIX", f"the zip has a top folder {prefix!r}; Minecraft needs pack.mcmeta at the zip root", "zip the contents of the folder, not the folder itself"))
    return files, notes, p


def check_merged(paths):
    """Check several packs as one world, the way the game loads them: references between packs resolve,
    #minecraft:tick / #minecraft:load of all packs are followed together, objectives created in one pack count for all."""
    paths = [Path(p) for p in paths]
    world = World()
    rep = Report(" + ".join(str(p) for p in paths))
    rep.kind = "merged"
    used = {}
    first = None
    for p in paths:
        if not p.is_dir() and p.suffix.lower() != ".zip":
            rep.add(Diag("error", "NOT_A_PACK", f"{p} is not a pack folder or a .zip", "--merge takes data pack folders and zips"))
            continue
        files, notes, real = load_pack(p)
        label = real.stem if real.is_file() else real.name
        used[label] = used.get(label, 0) + 1
        if used[label] > 1:
            label += f"#{used[label]}"
        for f in files:
            f.shown = f"{label}/{f.path}"
        for n in notes:
            n.file = label
            rep.add(n)
        pc = PackChecker(files, str(p), rep, world)
        pc.prepare()
        first = first or pc
    if first is not None:
        first.finish()
    return rep


def check_path(path):
    p = Path(path)
    if p.is_dir():
        files, notes, p = load_pack(p)
        return PackChecker(files, str(p)).run()
    if p.suffix.lower() == ".zip":
        files, notes, p = load_pack(p)
        rep = PackChecker(files, str(p)).run()
        for n in notes:
            rep.add(n)
        return rep
    raw = p.read_bytes()
    text = raw.decode("utf-8", errors="replace").lstrip("\ufeff")
    if p.suffix.lower() == ".json":
        rep = Report(str(p))
        rep.kind = "json"
        parts = PurePosixPath(p.as_posix()).parts
        reg = None
        if "data" in parts:
            idx = len(parts) - 1 - parts[::-1].index("data")
            sub = list(parts[idx + 2 :])
            reg, _ = PackChecker([], "").registry_of(sub) if len(sub) >= 2 else (None, "")
        if reg is None:
            rep.add(Diag("info", "JSON_KIND", "cannot tell the resource type from the path; use: pw check-json <type> <file>"))
            return rep
        f = File(f"data/x/{reg}/x.json", raw)
        pc = PackChecker([f], str(p), rep)
        pc.check_file(f)
        for d in rep.diags:
            d.file = str(p)
        return rep
    return check_commands_text(text, str(p))


def check_json_as(kind, text, target):
    rep = Report(target)
    rep.kind = "json"
    f = File(f"data/x/{kind}/x.json", text.encode("utf-8"))
    pc = PackChecker([f], target, rep)
    if kind == "pack_mcmeta":
        pc.check_mcmeta(f)
    elif kind.startswith("tags/"):
        value, ok = parse_json(f, rep)
        if ok:
            pc.check_tag(f, kind[5:], "x:x", value)
    else:
        pc.check_file(f)
    for d in rep.diags:
        d.file = target
    return rep
