import re

from . import data, schema
from .analysis import chain_events, legacy_stacks, seq_add
from .args import CmdCtx, Fail, R, legacy_count_check, parse_argument, schema_check, word_hint
from .snbt import WILD

MACRO_VAR = re.compile(r"\$\(([^)]*)\)")


class Diag:
    __slots__ = ("severity", "code", "message", "hint", "file", "line", "col", "text")

    def __init__(self, severity, code, message, hint="", file="", line=None, col=None, text=""):
        self.severity = severity
        self.code = code
        self.message = message
        self.hint = hint
        self.file = file
        self.line = line
        self.col = col
        self.text = text

    def to_dict(self):
        out = {"severity": self.severity, "code": self.code, "message": self.message}
        if self.hint:
            out["hint"] = self.hint
        if self.file:
            out["file"] = self.file
        if self.line is not None:
            out["line"] = self.line
        if self.col is not None:
            out["col"] = self.col
        return out


def tree():
    return data.commands()


def resolve_path(path):
    node = tree()
    for p in path:
        node = (node.get("children") or {}).get(p)
        if node is None:
            return None
    return node


def is_run(node):
    return node.get("type") == "literal" and not node.get("children") and not node.get("executable") and "redirect" not in node


class Walker:
    def __init__(self, text, ctx):
        self.text = text
        self.ctx = ctx
        self.best = None
        self.steps = 0

    def fail(self, pos, message, hint="", code="SYNTAX"):
        if self.best is None or pos >= self.best[0]:
            self.best = (pos, message, hint, code)

    def walk(self, node, r, path, depth):
        self.steps += 1
        if self.steps > 4000 or depth > 200:
            return True
        if not r.can():
            if node.get("executable"):
                return True
            self.fail(r.i, "incomplete command: " + expected_after(node), "", "INCOMPLETE")
            return False
        if r.peek() != " ":
            self.fail(r.i, "expected a space between arguments")
            return False
        r.i += 1
        if not r.can():
            self.fail(r.i, "trailing space or incomplete command: " + expected_after(node), "", "INCOMPLETE")
            return False
        if r.peek() == " ":
            self.fail(r.i, "double space between arguments")
            return False
        return self.children(node, r, path, depth)

    def children(self, node, r, path, depth):
        kids = node.get("children") or {}
        word = r.word()
        start = r.i
        if word in kids and kids[word].get("type") == "literal":
            return self.enter(kids[word], word, r, path, depth, start)
        wild = WILD in word
        literals = [k for k, v in kids.items() if v.get("type") == "literal"]
        if wild:
            for name in literals:
                r.i = start
                snap = self.ctx.snapshot()
                if self.enter(kids[name], name, r, path, depth, start, literal_override=True):
                    return True
                self.ctx.restore(snap)
        for name, child in kids.items():
            if child.get("type") != "argument":
                continue
            r.i = start
            snap = self.ctx.snapshot()
            try:
                value = parse_argument(child.get("parser", ""), child.get("properties") or {}, r, self.ctx, name, path)
            except Fail as f:
                self.ctx.restore(snap)
                self.fail(f.pos, f.message, f.hint, f.code)
                continue
            if r.can() and r.peek() != " ":
                self.ctx.restore(snap)
                bad = r.word()
                self.fail(r.i, f"unexpected text {bad!r} after argument <{name}>", hint_for_tail(bad, child), "SYNTAX")
                continue
            self.ctx.args[name] = value
            if self.after(child, name, r, path + [name], depth):
                return True
            self.ctx.restore(snap)
        r.i = start
        if literals and not any(v.get("type") == "argument" for v in kids.values()):
            sug = schema.suggest(word, literals)
            self.fail(start, f"unknown or misplaced word {word!r}; expected one of: {', '.join(literals[:16])}{' ...' if len(literals) > 16 else ''}", ("did you mean " + ", ".join(sug)) if sug else "", "SYNTAX")
        elif literals:
            self.fail(start, f"unexpected {word!r} here", "expected " + ", ".join(literals[:10]) + " or an argument", "SYNTAX")
        return False

    def enter(self, child, name, r, path, depth, start, literal_override=False):
        if literal_override:
            r.i = start + len(r.word())
        else:
            r.i = start + len(name)
        seq_add(self.ctx, ("lit", "?" if literal_override else name))
        return self.after(child, name, r, path + [name], depth)

    def after(self, child, name, r, path, depth):
        if is_run(child):
            if not r.can() or r.peek() != " ":
                self.fail(r.i, "expected a command after 'run'", "", "INCOMPLETE")
                return False
            r.i += 1
            sub_start = r.i
            self.ctx.args["_runs"] = self.ctx.args.get("_runs", ()) + (sub_start,)
            return self.root(r, depth + 1)
        redirect = child.get("redirect")
        if isinstance(redirect, list):
            target = resolve_path(redirect)
            if target is None:
                return True
            if not r.can():
                if child.get("executable"):
                    return True
                self.fail(r.i, f"incomplete command after '{name}'", "", "INCOMPLETE")
                return False
            return self.walk(target, r, list(redirect), depth + 1)
        return self.walk(child, r, path, depth + 1)

    def root(self, r, depth):
        start = r.i
        word = r.word()
        kids = tree().get("children") or {}
        name = word.lower() if word.lower() in kids and word not in kids else word
        if word.startswith("/"):
            self.fail(start, "a nested command after 'run' must not start with '/'", "remove the slash", "SYNTAX")
            return False
        if word not in kids:
            if WILD in word:
                return True
            sug = schema.suggest(word, list(kids))
            self.fail(start, f"unknown command {word!r}", ("did you mean " + ", ".join(sug)) if sug else "", "UNKNOWN_COMMAND")
            return False
        node = kids[word]
        r.i = start + len(word)
        self.ctx.path = [word]
        cmd = word
        if isinstance(node.get("redirect"), list):
            cmd = node["redirect"][0]
            node = resolve_path(node["redirect"]) or node
        frame = {"_cmd": cmd, "_start": start}
        prev = self.ctx.args
        self.ctx.frames.append(frame)
        self.ctx.args = frame
        ok = self.walk(node, r, [word], depth + 1)
        self.ctx.args = prev
        if not ok:
            if frame in self.ctx.frames:
                self.ctx.frames.remove(frame)
        return ok


def expected_after(node):
    kids = node.get("children") or {}
    names = []
    for k, v in kids.items():
        names.append(k if v.get("type") == "literal" else f"<{k}>")
    if not names:
        return "nothing more is expected"
    return "expected " + " | ".join(names[:12]) + (" ..." if len(names) > 12 else "")


def hint_for_tail(bad, child):
    p = child.get("parser", "")
    spacing = word_hint(bad[:1])
    if spacing:
        return spacing
    if p == "minecraft:item_stack" and bad.startswith("{"):
        return "item NBT {...} was replaced by components [...] in 1.20.5"
    if p in ("brigadier:float", "brigadier:double", "brigadier:integer") and bad[:1] in "fFdDbBsSlL":
        return "command numbers take no type suffix"
    if p == "minecraft:entity" and bad.startswith("["):
        return "selector options go right after @e, with no space"
    if bad.startswith("{") or bad.startswith("["):
        return "check that brackets and quotes are balanced and that there is no space inside an argument where none is allowed"
    return ""


def check_command(text, macro=False, depth=0):
    ctx = CmdCtx(macro=macro)
    raw = text
    if raw.startswith("/"):
        raw = raw[1:]
    r = R(raw)
    w = Walker(raw, ctx)
    ok = w.root(r, 0)
    out = []
    offset = len(text) - len(raw)
    if not ok:
        pos, message, hint, code = w.best or (0, "command does not match the 1.21.8 syntax", "", "SYNTAX")
        out.append(Diag("error", code, message, hint, col=pos + offset + 1))
        for spos, scode, smessage, shint in dict.fromkeys(ctx.sticky):
            out.append(Diag("warning", scode, smessage, shint, col=spos + offset + 1))
    for sev, code, message, hint, pos in ctx.diags:
        out.append(Diag(sev, code, message, hint, col=(pos + offset + 1) if pos is not None else None))
    if ok:
        out.extend(semantic(ctx, raw, offset))
        if depth < 3:
            nested = [c for f in ctx.frames for c in f.get("_nested_commands", [])]
            for cmd, pos in nested:
                sub, _ = check_command(cmd, macro, depth + 1)
                for d in sub:
                    if d.severity == "error":
                        out.append(Diag("warning", "CLICK_COMMAND", f"the click_event command {cmd[:60]!r} will fail: {d.message}", d.hint, col=pos + offset + 1))
    return out, ctx


def semantic(ctx, raw, offset):
    out = []
    chain = ctx.chain = chain_events(ctx.frames)
    if chain["in_dim"]:
        kind, col = chain["in_dim"][0]
        out.append(Diag("warning", "EXECUTE_IN_SELECTOR", f"'execute in' does not limit @{kind}: a selector without distance/x/y/z/dx/dy/dz still loops over entities of every dimension", "writing one such line per dimension runs everything once per dimension; use a single 'execute as @e[...] at @s run ...' (at @s moves into the entity's own dimension) or limit the selector with distance/x/y/z/dx/dy/dz (distance=0.. keeps the search in the source's dimension)", col=col + offset + 1))
    for frame in ctx.frames:
        cmd = frame.get("_cmd")
        if cmd == "data":
            lits = [x[1] for x in frame.get("_seq", ()) if x[0] == "lit"]
            nbt = frame.get("nbt") or frame.get("value")
            if isinstance(nbt, tuple) and ("entity" in lits or "block" in lits):
                sub = CmdCtx()
                legacy_count_check(sub, nbt[0], nbt[1], "NBT value")
                for sev, code, message, hint, p in sub.diags:
                    out.append(Diag(sev, code, message, hint, col=p + offset + 1))
        elif cmd == "summon":
            ent = frame.get("entity")
            if not isinstance(ent, str) or WILD in ent:
                continue
            short = data.strip_ns(ent)
            if short in ("player", "fishing_bobber"):
                out.append(Diag("error", "NOT_SUMMONABLE", f"{short} cannot be summoned", col=frame["_start"] + offset + 1))
                continue
            nbt = frame.get("nbt")
            if isinstance(nbt, tuple) and short in schema.dispatchers().get("minecraft:entity", {}):
                pos, value = nbt
                sub = CmdCtx()
                schema_check(value, {"k": "dispatch", "reg": "minecraft:entity", "keys": [short]}, sub, pos, False, f"{short} data", code="ENTITY_NBT")
                for sev, code, message, hint, p in sub.diags:
                    out.append(Diag(sev, code, message, hint, col=p + offset + 1))
                ctx.refs.extend(sub.refs)
        elif cmd == "kill":
            sels = frame.get("_selectors") or []
            if any(k == "e" and not o for k, o in sels):
                out.append(Diag("warning", "KILL_ALL", "kill @e removes every entity, including players, items and display entities", "add filters such as type=, tag= or distance=", col=frame["_start"] + offset + 1))
    return out


def macro_prepare(line):
    names = MACRO_VAR.findall(line)
    bad = [n for n in names if not re.fullmatch(r"[A-Za-z0-9_]+", n)]
    text = MACRO_VAR.sub(WILD, line)
    return text, names, bad
