"""Context analysis for one command line.

Commands record small events while they are parsed (`_seq` in the command frame):

    ("lit", name)                  a literal such as `as`, `at`, `positioned`, `run`
    ("sel", kind, limited, col)    a selector; `limited` is True when it has distance/x/y/z/dx/dy/dz
    ("pos", kinds, col)            three coordinates, each "~", "^" or "n" (absolute)
    ("fn", id, is_tag)             a function reference

`chain_events` replays them to answer: which parts of this line need an executor or a position
that the line itself does not provide, and which functions does it call in which context?
"""

LIMITERS = ("distance", "x", "y", "z", "dx", "dy", "dz")
ALL_DIMENSION_SELECTORS = "aerpn"
# keys whose value is the user's own data, not Minecraft item stacks
OWN_DATA_KEYS = {"custom_data", "minecraft:custom_data"}


def seq_add(ctx, item):
    """Append an event to the current command frame (a tuple, so backtracking restores it)."""
    args = ctx.args
    args["_seq"] = args.get("_seq", ()) + (item,)


def chain_events(frames):
    state = {"exec": False, "pos": False, "dim": False}
    out = {"s_no_exec": [], "rel_no_pos": [], "in_dim": [], "calls": [], "schedules": []}
    for frame in frames:
        cmd = frame.get("_cmd")
        prev = prev2 = None
        for item in frame.get("_seq", ()):
            kind = item[0]
            if kind == "lit":
                name = item[1]
                if cmd == "execute":
                    if name == "in":
                        state["dim"] = True
                    elif name == "on":
                        if not state["exec"]:
                            out["s_no_exec"].append(("on", None))
                        state["exec"] = True
                    elif name == "summon":
                        state["exec"] = True
                prev2, prev = prev, name
                continue
            if kind == "sel":
                _, skind, limited, col = item
                role = "use"
                if cmd == "execute":
                    if prev == "as" and prev2 not in ("positioned", "rotated"):
                        role = "as"
                    elif prev == "at":
                        role = "at"
                    elif prev == "as" and prev2 == "positioned":
                        role = "pos_as"
                if skind == "s" and not state["exec"]:
                    out["s_no_exec"].append(("@s", col))
                if state["dim"] and skind in ALL_DIMENSION_SELECTORS and not limited and role != "use":
                    out["in_dim"].append((skind, col))
                if role == "as" and skind != "s":
                    state["exec"] = True
                elif role in ("at", "pos_as"):
                    state["pos"] = True
                prev2, prev = prev, "<sel>"
                continue
            if kind == "pos":
                _, kinds, col = item
                if any(k in "~^" for k in kinds) and not state["pos"]:
                    out["rel_no_pos"].append(col)
                if cmd == "execute" and prev == "positioned" and all(k == "n" for k in kinds):
                    state["pos"] = True
                prev2, prev = prev, "<pos>"
                continue
            if kind == "fn":
                if cmd == "schedule":
                    out["schedules"].append((item[1], item[2]))
                else:
                    out["calls"].append((item[1], item[2], state["exec"], state["pos"]))
                prev2, prev = prev, "<fn>"
                continue
    return out


def legacy_stacks(value, path="", depth=0):
    """Paths of compounds that look like pre-1.20.5 item stacks ({id:..., Count:...})."""
    found = []
    if depth > 30:
        return found
    if isinstance(value, dict):
        if "Count" in value and isinstance(value.get("id"), str):
            found.append(path or "<root>")
        for k, v in value.items():
            if k in OWN_DATA_KEYS:
                continue
            found.extend(legacy_stacks(v, f"{path}.{k}" if path else str(k), depth + 1))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            found.extend(legacy_stacks(v, f"{path}[{i}]", depth + 1))
    return found
