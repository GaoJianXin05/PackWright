import gzip
import json
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REF = ROOT / "reference"
KNOWLEDGE = ROOT / "knowledge"


def _read(name):
    path = REF / name
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    gz = REF / (name + ".gz")
    return json.loads(gzip.decompress(gz.read_bytes()).decode("utf-8"))


@lru_cache(None)
def profile():
    return _read("profile.json")


@lru_cache(None)
def registries():
    return _read("registries.json")


@lru_cache(None)
def registry_sets():
    return {k: frozenset(v) for k, v in registries().items()}


@lru_cache(None)
def tags():
    return _read("tags.json")


@lru_cache(None)
def blocks():
    return _read("blocks.json")


@lru_cache(None)
def items():
    return _read("items.json")


@lru_cache(None)
def commands():
    return _read("commands.json")


@lru_cache(None)
def names():
    return _read("names.json")


@lru_cache(None)
def lang():
    return _read("lang_en.json")


@lru_cache(None)
def vanilla():
    return _read("vanilla.json")


@lru_cache(None)
def schema():
    return _read("schema.json")


REG_ALIASES = {
    "entity": "entity_type",
    "effect": "mob_effect",
    "particle": "particle_type",
    "component": "data_component_type",
    "trigger": "trigger_type",
    "biome": "worldgen/biome",
    "sound": "sound_event",
    "structure": "worldgen/structure",
    "feature": "worldgen/configured_feature",
    "loot_function": "loot_function_type",
    "loot_condition": "loot_condition_type",
    "predicate_type": "loot_condition_type",
    "enchantment_effect": "enchantment_effect_component_type",
    "entity_effect": "enchantment_entity_effect_type",
    "stat": "custom_stat",
    "block_entity": "block_entity_type",
}


def reg_name(name):
    name = name.strip().lower().removeprefix("minecraft:")
    return REG_ALIASES.get(name, name)


def strip_ns(value):
    return value[10:] if value.startswith("minecraft:") else value


def split_id(value):
    if ":" in value:
        ns, _, path = value.partition(":")
        return ns or "minecraft", path
    return "minecraft", value


def in_registry(registry, value):
    regs = registry_sets()
    reg = regs.get(registry)
    if reg is None:
        return None
    ns, path = split_id(value)
    if ns != "minecraft":
        return None
    return path in reg


def tag_values(registry, tag, seen=None):
    seen = seen or set()
    reg = registry.removeprefix("minecraft:")
    table = tags().get(reg, {})
    ns, path = split_id(tag.lstrip("#"))
    if ns != "minecraft" or path not in table or path in seen:
        return None
    seen.add(path)
    out = []
    for v in table[path]:
        ref = v["id"] if isinstance(v, dict) else v
        if ref.startswith("#"):
            sub = tag_values(registry, ref, seen)
            out.extend(sub or [])
        else:
            out.append(strip_ns(ref))
    return out


def has_tag(registry, tag):
    reg = registry.removeprefix("minecraft:")
    ns, path = split_id(tag.lstrip("#"))
    if ns != "minecraft":
        return None
    if reg not in tags():
        return None
    return path in tags()[reg]
