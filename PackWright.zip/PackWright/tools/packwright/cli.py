import argparse
import json
import locale
import re
import sys
import zipfile
from pathlib import Path

from . import args as argmod, data, schema
from .commands import Diag, check_command, is_run, resolve_path, tree
from .pack import Report, check_commands_text, check_json_as, check_merged, check_path, load_dir, PackChecker

SCHEMA_KINDS = {
    "component": "minecraft:data_component",
    "components": "minecraft:data_component",
    "item_component": "minecraft:data_component",
    "component_predicate": "minecraft:data_component_predicate",
    "item_predicate": "minecraft:data_component_predicate",
    "trigger": "minecraft:trigger",
    "criterion": "minecraft:trigger",
    "loot_function": "minecraft:loot_function",
    "item_modifier": "minecraft:loot_function",
    "modifier": "minecraft:loot_function",
    "condition": "minecraft:loot_condition",
    "loot_condition": "minecraft:loot_condition",
    "predicate": "minecraft:loot_condition",
    "entry": "minecraft:loot_pool_entry",
    "loot_entry": "minecraft:loot_pool_entry",
    "number": "minecraft:number_provider",
    "number_provider": "minecraft:number_provider",
    "entity": "minecraft:entity",
    "block_entity": "minecraft:block_entity",
    "particle": "minecraft:particle",
    "dialog": "minecraft:dialog",
    "dialog_action": "minecraft:dialog_action",
    "action": "minecraft:dialog_action",
    "dialog_body": "minecraft:dialog_body",
    "body": "minecraft:dialog_body",
    "input": "minecraft:input_control",
    "input_control": "minecraft:input_control",
    "click_event": "minecraft:click_event",
    "click": "minecraft:click_event",
    "hover_event": "minecraft:hover_event",
    "hover": "minecraft:hover_event",
    "consume_effect": "minecraft:consume_effect",
    "effect_component": "minecraft:effect_component",
    "enchantment_effect": "minecraft:effect_component",
    "entity_effect": "minecraft:entity_effect",
    "location_effect": "minecraft:location_based_effect",
    "value_effect": "minecraft:value_effect",
    "level_value": "minecraft:level_based_value",
    "level_based_value": "minecraft:level_based_value",
    "recipe": "minecraft:recipe_serializer",
    "resource": "minecraft:resource",
    "file": "minecraft:resource",
    "item_model": "minecraft:item_model",
    "slot_source": "minecraft:slot_source",
    "entity_sub_predicate": "minecraft:entity_sub_predicate",
    "sub_predicate": "minecraft:entity_sub_predicate",
    "enchantment_provider": "minecraft:enchantment_provider",
    "int_provider": "minecraft:int_provider",
    "float_provider": "minecraft:float_provider",
    "list_operation": "minecraft:list_operation",
    "attribute_display": "minecraft:attribute_display",
}
HIDDEN_DISPATCH = {
    "minecraft:environment_attribute", "minecraft:environment_attribute_argb_color_modifier",
    "minecraft:environment_attribute_color_modifier", "minecraft:environment_attribute_float_modifier",
    "minecraft:game_rule", "minecraft:context_float_provider", "minecraft:context_int_provider",
}
HIDDEN_KEYS = {"copper_golem_statue"}
SEV_RANK = {"error": 0, "warning": 1, "info": 2}
SEV_LABEL = {"error": "ERROR", "warning": "WARN ", "info": "NOTE "}


def out_json(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=1))


def read_stdin():
    stream = getattr(sys.stdin, "buffer", None)
    if stream is None:
        return sys.stdin.read()
    raw = stream.read()
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode(locale.getpreferredencoding(False), errors="replace")


def full_id(value):
    value = value.strip()
    return value if ":" in value else "minecraft:" + value


def print_report(rep, show_info=True, limit=300):
    c = rep.counts()
    st = rep.stats
    bits = []
    if st.get("functions"):
        bits.append(f"{st['functions']} functions")
    if st.get("commands"):
        bits.append(f"{st['commands']} commands")
    if st.get("json"):
        bits.append(f"{st['json']} JSON files")
    diags = [d for d in rep.diags if show_info or d.severity != "info"]
    diags.sort(key=lambda d: (d.file or "", d.line or 0, SEV_RANK.get(d.severity, 3)))
    for d in diags[:limit]:
        loc = d.file or ""
        if d.line is not None:
            loc += f":{d.line}"
            if d.col is not None:
                loc += f":{d.col}"
        elif d.col is not None:
            loc += f"col {d.col}"
        print(f"{SEV_LABEL.get(d.severity, d.severity)} {loc} [{d.code}] {d.message}".replace("  [", " ["))
        if d.text:
            text = d.text if len(d.text) <= 200 else d.text[:200] + " ..."
            print("      | " + text)
            if d.col is not None and d.col - 1 <= len(text):
                print("      | " + " " * (d.col - 1) + "^")
        if d.hint:
            print("      hint: " + d.hint)
    if len(diags) > limit:
        print(f"... {len(diags) - limit} more")
    print(f"{rep.status()}: {c['error']} errors, {c['warning']} warnings, {c['info']} notes" + (f" ({', '.join(bits)})" if bits else "") + f" [{rep.target}]")


def cmd_doctor(a):
    prof = data.profile()
    problems = []
    if sys.version_info < (3, 9):
        problems.append("Python 3.9 or newer is required")
    loaded = {}
    for name in ("registries", "tags", "blocks", "items", "commands", "names", "lang", "vanilla", "schema"):
        try:
            v = getattr(data, name)()
            loaded[name] = len(v)
        except Exception as e:
            problems.append(f"reference/{name}: {e}")
    know = sorted(p.relative_to(data.KNOWLEDGE).as_posix() for p in data.KNOWLEDGE.rglob("*.md")) if data.KNOWLEDGE.is_dir() else []
    if not know:
        problems.append("knowledge/ folder is missing or empty")
    try:
        for line in ('give @s diamond_sword[custom_name={text:"x"}]', "scoreboard players set @s 金币 5"):
            diags, _ = check_command(line)
            if any(d.severity == "error" for d in diags):
                problems.append(f"self-test command failed: {line}")
    except Exception as e:
        problems.append(f"self-test crashed: {e}")
    res = {
        "ok": not problems,
        "minecraft": prof["version"],
        "pack_format": prof["pack_format"],
        "resource_pack_format": prof["resource_pack_format"],
        "data_version": prof["data_version"],
        "python": sys.version.split()[0],
        "reference": loaded,
        "knowledge_files": len(know),
        "problems": problems,
    }
    if a.json:
        out_json(res)
    else:
        print(f"PackWright for Minecraft Java {prof['version']}: data pack format {prof['pack_format']}, resource pack format {prof['resource_pack_format']}, data version {prof['data_version']}")
        print(f"python {res['python']}, {len(data.registries())} registries, {len(data.commands().get('children', {}))} commands, {len(schema.types())} schema types, {len(know)} knowledge files")
        for p in problems:
            print("PROBLEM: " + p)
        print("ready" if not problems else "not ready")
    return 0 if not problems else 1


def sections():
    out = []
    if not data.KNOWLEDGE.is_dir():
        return out
    for p in sorted(data.KNOWLEDGE.rglob("*.md")):
        rel = p.relative_to(data.ROOT).as_posix()
        lines = p.read_text(encoding="utf-8").split("\n")
        heads = []
        cur = None
        for i, line in enumerate(lines, 1):
            m = re.match(r"^(#{1,4})\s+(.*)", line)
            if m and not (cur and cur.get("fence")):
                level = len(m.group(1))
                heads = heads[: level - 1] + [m.group(2).strip()]
                cur = {"file": rel, "line": i, "title": " > ".join(heads), "body": [], "fence": False}
                out.append(cur)
                continue
            if cur is None:
                cur = {"file": rel, "line": i, "title": rel, "body": [], "fence": False}
                out.append(cur)
            if line.strip().startswith("```"):
                cur["fence"] = not cur["fence"]
            cur["body"].append((i, line))
    return out


# The notes are written in English; these let `pw find 冷却` reach them. Ids and block/item names are searched in Chinese anyway.
ZH_TERMS = {
    "冷却": "cooldown", "无敌帧": "invulnerability iframes i-frames bypasses_cooldown", "无敌": "invulnerable invulnerability",
    "伤害": "damage", "计分板": "scoreboard", "记分板": "scoreboard", "计分项": "objective scoreboard", "记分项": "objective scoreboard",
    "选择器": "selector", "目标选择器": "selector", "宏": "macro", "函数": "function", "进度": "advancement", "成就": "advancement",
    "战利品": "loot", "掉落": "loot drop", "附魔": "enchantment", "物品": "item", "组件": "component", "文本": "text component",
    "展示实体": "display", "射线": "raycast", "技能": "skill", "武器": "weapon", "首领": "boss", "血条": "bossbar", "对话框": "dialog",
    "谓词": "predicate", "配方": "recipe", "存储": "storage", "数学": "math", "计时": "timer", "定时": "schedule timer",
    "右键": "right click use", "属性": "attribute", "药水": "potion effect", "效果": "effect", "粒子": "particle", "音效": "sound",
    "队伍": "team", "标签": "tag", "维度": "dimension in", "坐标": "coordinates position", "旋转": "rotation", "实体": "entity",
    "玩家": "player", "传送": "teleport", "召唤": "summon", "击杀": "kill", "生命": "health", "护甲": "armor", "盾": "shield",
    "弓": "bow", "弩": "crossbow", "三叉戟": "trident", "冲刺": "dash", "闪电": "lightning", "爆炸": "explosion", "加载": "load",
    "卸载": "uninstall", "性能": "performance tick", "中文": "chinese unicode non-ascii", "命名": "name", "名字": "name", "装备": "equipment",
    "掉落物": "drop", "凋落物": "drop", "出生": "spawn", "死亡": "death", "复活": "respawn", "世界": "world", "时间": "time", "天气": "weather",
}
CJK = re.compile("[\u3400-\u9fff]")


def terms_of(query):
    return [t for t in re.split(r"[\s,;]+", query.lower()) if t]


def term_groups(query):
    """Each search term with its alternatives; a Chinese word brings the English words it stands for."""
    groups = []
    for t in terms_of(query):
        alts = [t]
        if CJK.search(t):
            for zh, en in ZH_TERMS.items():
                if zh in t:
                    alts.extend(en.split())
        groups.append(list(dict.fromkeys(alts)))
    return groups


def cmd_find(a):
    q = " ".join(a.query)
    groups = term_groups(q)
    flat = [t for g in groups for t in g]
    hits = []
    for s in sections():
        title = s["title"].lower()
        body = "\n".join(l for _, l in s["body"]).lower()
        score = 0
        present = 0
        for g in groups:
            h = sum(title.count(t) for t in g)
            b = sum(body.count(t) for t in g)
            if h or b:
                present += 1
            score += 6 * min(h, 2) + min(b, 6)
        if not score:
            continue
        if present == len(groups):
            score *= 3
        lines = [(i, l.strip()) for i, l in s["body"] if any(t in l.lower() for t in flat) and l.strip()]
        hits.append((score, s, lines[:3]))
    hits.sort(key=lambda h: -h[0])
    hits = hits[: a.limit]
    schema_hits = []
    for reg, entries in schema.dispatchers().items():
        if reg in HIDDEN_DISPATCH or reg.startswith("mcdoc:"):
            continue
        for key in entries:
            if key.startswith("%") or key in HIDDEN_KEYS:
                continue
            if all(any(t in key.lower() for t in g) for g in groups):
                schema_hits.append(f"{reg.removeprefix('minecraft:')} {key}")
    id_hits = find_ids(q, None, 8)
    if a.json:
        out_json({
            "knowledge": [{"file": s["file"], "line": s["line"], "section": s["title"], "score": sc, "lines": [{"line": i, "text": t} for i, t in ls]} for sc, s, ls in hits],
            "schema": schema_hits[:30],
            "ids": id_hits,
        })
        return 0
    if hits:
        print("knowledge:")
        for sc, s, ls in hits:
            print(f"  {s['file']}:{s['line']}  {s['title']}")
            for i, t in ls:
                print(f"      {i}: {t[:160]}")
    if schema_hits:
        print("schema (pw schema <kind> <key>):")
        for h in schema_hits[:30]:
            print("  " + h)
    if id_hits:
        print("ids:")
        for h in id_hits:
            print("  " + fmt_id(h))
    if not (hits or schema_hits or id_hits):
        print(f"nothing found for {q!r}; try other words, pw id <name>, pw schema, or a web search")
        return 1
    return 0


def name_entry(reg, path):
    return (data.names().get(reg) or {}).get(path)


def fmt_id(h):
    s = f"{h['registry']:<16} {h['id']}"
    if h.get("en") or h.get("zh"):
        s += "  " + " / ".join(x for x in (h.get("en"), h.get("zh")) if x)
    return s


def find_ids(query, registry, limit):
    q = query.strip().lower().removeprefix("minecraft:")
    if not q:
        return []
    regs = [registry] if registry else list(data.registries())
    exact, start, sub, named = [], [], [], []
    for reg in regs:
        ids = data.registries().get(reg, [])
        names = data.names().get(reg) or {}
        for path in ids:
            n = names.get(path) or {}
            h = {"registry": reg, "id": "minecraft:" + path}
            if n.get("en"):
                h["en"] = n["en"]
            if n.get("zh"):
                h["zh"] = n["zh"]
            en = (n.get("en") or "").lower()
            zh = n.get("zh") or ""
            zt = n.get("zh_tw") or ""
            if path == q or en == q or zh == query.strip() or zt == query.strip():
                exact.append(h)
            elif path.startswith(q):
                start.append(h)
            elif q in path or q.replace(" ", "_") in path:
                sub.append(h)
            elif (en and q in en) or (zh and query.strip() in zh) or (zt and query.strip() in zt):
                named.append(h)
    key = lambda h: (len(h["id"]), h["id"])
    out = exact + sorted(start, key=key) + sorted(sub, key=key) + sorted(named, key=key)
    pri = {"item": 0, "block": 1, "entity_type": 2, "mob_effect": 3, "enchantment": 4, "attribute": 5, "particle_type": 6, "sound_event": 7}
    head = sorted(out[: len(exact)], key=lambda h: pri.get(h["registry"], 9))
    out = head + out[len(exact):]
    return out[:limit]


def cmd_id(a):
    words = a.query
    registry = None
    if words:
        cand = data.reg_name(words[0])
        if cand in data.registries():
            registry = cand
            words = words[1:]
    q = " ".join(words)
    if registry and not q:
        ids = data.registries()[registry]
        if a.json:
            out_json({"registry": registry, "count": len(ids), "ids": ids})
            return 0
        shown = ids if a.all or len(ids) <= 200 else ids[:200]
        names = data.names().get(registry) or {}
        for i in shown:
            n = names.get(i) or {}
            extra = " / ".join(x for x in (n.get("en"), n.get("zh")) if x)
            print(f"minecraft:{i}" + (f"  {extra}" if extra else ""))
        if len(shown) < len(ids):
            print(f"... {len(ids) - len(shown)} more (use --all)")
        print(f"{len(ids)} ids in {registry}")
        return 0
    if not q:
        regs = sorted(data.registries())
        if a.json:
            out_json({k: len(data.registries()[k]) for k in regs})
        else:
            for k in regs:
                print(f"{k:<52} {len(data.registries()[k])}")
        return 0
    hits = find_ids(q, registry, a.limit)
    if a.json:
        out_json(hits)
        return 0 if hits else 1
    if not hits:
        pool = data.registries().get(registry, []) if registry else [i for r in ("item", "block", "entity_type") for i in data.registries()[r]]
        sug = schema.suggest(q.lower().replace(" ", "_"), pool, 5)
        print(f"no id matches {q!r}" + (f" in {registry}" if registry else "") + ("; close: " + ", ".join(sug) if sug else ""))
        return 1
    for h in hits:
        print(fmt_id(h))
    return 0


def block_tags(path):
    out = []
    for tag in data.tags().get("block", {}):
        vals = data.tag_values("block", "minecraft:" + tag) or []
        if path in vals:
            out.append("#minecraft:" + tag)
    return sorted(out)


def item_tags(path):
    out = []
    for tag in data.tags().get("item", {}):
        vals = data.tag_values("item", "minecraft:" + tag) or []
        if path in vals:
            out.append("#minecraft:" + tag)
    return sorted(out)


def cmd_block(a):
    path = full_id(a.id).removeprefix("minecraft:")
    b = data.blocks().get(path)
    if b is None:
        sug = schema.suggest(path, list(data.blocks()), 5)
        print(f"minecraft:{path} is not a 1.21.8 block" + ("; did you mean " + ", ".join(sug) if sug else ""))
        return 1
    n = name_entry("block", path) or {}
    res = {"id": "minecraft:" + path, "en": n.get("en"), "zh": n.get("zh"), "properties": b.get("p", {}), "default": b.get("d", {}), "item": path in data.items(), "tags": block_tags(path)}
    if a.json:
        out_json(res)
        return 0
    print(f"minecraft:{path}" + (f"  {n.get('en')} / {n.get('zh')}" if n else ""))
    if res["properties"]:
        for k, vals in res["properties"].items():
            print(f"  {k}: {' | '.join(vals)}  (default {res['default'].get(k)})")
        print("  default state: minecraft:" + path + "[" + ",".join(f"{k}={v}" for k, v in res["default"].items()) + "]")
    else:
        print("  no block state properties")
    print("  has item form: " + ("yes" if res["item"] else "no"))
    if res["tags"]:
        print("  tags: " + ", ".join(res["tags"]))
    return 0


def cmd_item(a):
    path = full_id(a.id).removeprefix("minecraft:")
    it = data.items().get(path)
    if it is None:
        sug = schema.suggest(path, list(data.items()), 5)
        print(f"minecraft:{path} is not a 1.21.8 item" + ("; did you mean " + ", ".join(sug) if sug else ""))
        return 1
    n = name_entry("item", path) or {}
    res = {"id": "minecraft:" + path, "en": n.get("en"), "zh": n.get("zh"), "default_components": it, "tags": item_tags(path)}
    if a.json:
        out_json(res)
        return 0
    print(f"minecraft:{path}" + (f"  {n.get('en')} / {n.get('zh')}" if n else ""))
    print("default components (what the item already has; set only what you change):")
    for k, v in sorted(it.items()):
        text = json.dumps(v, ensure_ascii=False)
        print(f"  {k}: {text if len(text) < 220 else text[:220] + ' ...'}")
    if res["tags"]:
        print("tags: " + ", ".join(res["tags"]))
    return 0


def cmd_tag(a):
    registry = data.reg_name(a.registry)
    table = data.tags().get(registry)
    if table is None:
        print(f"no vanilla tags for {registry!r}; registries with tags: {', '.join(sorted(data.tags()))}")
        return 1
    if not a.tag:
        names = sorted(table)
        if a.json:
            out_json(names)
        else:
            for t in names:
                print("#minecraft:" + t)
            print(f"{len(names)} {registry} tags")
        return 0
    tag = a.tag.lstrip("#")
    tag = tag.removeprefix("minecraft:")
    if tag not in table:
        sug = schema.suggest(tag, list(table), 5)
        print(f"#minecraft:{tag} is not a vanilla {registry} tag" + ("; did you mean " + ", ".join("#minecraft:" + s for s in sug) if sug else ""))
        return 1
    raw = table[tag]
    vals = data.tag_values(registry, "minecraft:" + tag) or []
    if a.json:
        out_json({"tag": "#minecraft:" + tag, "entries": raw, "resolved": ["minecraft:" + v if ":" not in v else v for v in vals]})
        return 0
    print(f"#minecraft:{tag} ({len(vals)} resolved values)")
    print("  entries: " + ", ".join(e["id"] if isinstance(e, dict) else e for e in raw))
    print("  resolved: " + ", ".join(vals))
    return 0


def parser_label(node):
    parser = str(node.get("parser", "?")).removeprefix("minecraft:").removeprefix("brigadier:")
    props = node.get("properties") or {}
    if parser in ("integer", "long", "float", "double"):
        lo, hi = props.get("min"), props.get("max")
        if lo is not None or hi is not None:
            parser += f" {'' if lo is None else lo}..{'' if hi is None else hi}"
    elif parser in ("resource", "resource_key", "resource_or_tag", "resource_or_tag_key", "resource_selector"):
        reg = str(props.get("registry", "")).removeprefix("minecraft:")
        parser += f"({reg})" if reg else ""
    elif parser == "entity":
        parser += f"({props.get('amount', '?')} {props.get('type', '')})".replace(" )", ")")
    elif parser == "string":
        parser += f"({props.get('type', '')})"
    return parser


def token(name, node, types):
    if node.get("type") == "literal":
        return name
    return f"<{name}: {parser_label(node)}>" if types else f"<{name}>"


def form(name, child, depth, types):
    text = token(name, child, types)
    if isinstance(child.get("redirect"), list):
        return text + " ..."
    if is_run(child):
        return text + " <command>"
    rest = smart(child, depth + 1, types)
    return f"{text} {rest}" if rest else text


def smart(node, depth, types):
    kids = node.get("children") or {}
    if not kids or depth >= 8:
        return ""
    forms = [form(n, c, depth, types) for n, c in kids.items()]
    body = forms[0] if len(forms) == 1 else "(" + "|".join(forms) + ")"
    return f"[{body}]" if node.get("executable") else body


def cmd_usage(a):
    words = " ".join(a.words).split()
    root = tree()
    if not words:
        names = sorted(root.get("children", {}))
        print(" ".join(names))
        print(f"{len(names)} commands; pw usage <command> [subcommand ...]")
        return 0
    if words[0].startswith("/"):
        words[0] = words[0][1:]
    node = (root.get("children") or {}).get(words[0])
    if node is None:
        sug = schema.suggest(words[0], list(root.get("children", {})))
        print(f"{words[0]!r} is not a 1.21.8 command" + ("; did you mean " + ", ".join(sug) if sug else ""))
        return 1
    path = [words[0]]
    lines = []
    if isinstance(node.get("redirect"), list):
        target = resolve_path(node["redirect"])
        if target is not None:
            lines.append(f"{words[0]} is an alias of {' '.join(node['redirect'])}")
            node, path = target, list(node["redirect"])
    for w in words[1:]:
        child = (node.get("children") or {}).get(w)
        if child is None:
            args = [k for k, v in (node.get("children") or {}).items() if v.get("type") == "argument"]
            if len(args) == 1:
                child = node["children"][args[0]]
                w = f"<{args[0]}>"
        if child is None:
            opts = [k for k, v in (node.get("children") or {}).items() if v.get("type") == "literal"]
            print(f"{' '.join(path)!r} has no subcommand {w!r}" + ("; options: " + ", ".join(opts) if opts else ""))
            return 1
        if isinstance(child.get("redirect"), list):
            node = resolve_path(child["redirect"]) or child
            path.append(w)
            continue
        node = child
        path.append(w)
    prefix = " ".join(path)
    if node.get("executable"):
        lines.append(prefix)
    for name, child in (node.get("children") or {}).items():
        lines.append(f"{prefix} {form(name, child, 0, a.types)}")
    if a.json:
        out_json(lines)
    else:
        print("\n".join(lines))
    return 0


def find_dispatch(kind):
    k = kind.lower().strip()
    if k in SCHEMA_KINDS:
        return SCHEMA_KINDS[k]
    full = k if ":" in k else "minecraft:" + k
    if full in schema.dispatchers() and full not in HIDDEN_DISPATCH:
        return full
    return None


def visible_keys(reg):
    return sorted(k for k in schema.dispatchers().get(reg, {}) if not k.startswith("%") and k not in HIDDEN_KEYS)


def cmd_schema(a):
    pr = schema.Printer(depth=a.depth, docs=not a.no_docs, flat=a.flat)
    if not a.kind:
        print("kinds: " + ", ".join(sorted(set(SCHEMA_KINDS))))
        print("also: pw schema type <TypeName>, or pw schema <any dispatcher> such as loot_pool_entry")
        return 0
    if a.kind == "type":
        if not a.key:
            print("give a type name, e.g. pw schema type Text")
            return 2
        hits = schema.lookup_type(a.key)
        if not hits:
            low = a.key.lower()
            close = sorted({p.rsplit("::", 1)[-1] for p in schema.types() if low in p.rsplit("::", 1)[-1].lower()})
            print(f"no type named {a.key!r}" + ("; similar: " + ", ".join(close[:20]) if close else ""))
            return 1
        for p, e in hits[:3]:
            print(f"{p}:")
            print(pr.ty(e["type"], "", 0))
        return 0
    reg = find_dispatch(a.kind)
    key = a.key
    if reg is None:
        guess = []
        for r, entries in schema.dispatchers().items():
            if r in HIDDEN_DISPATCH or r.startswith("mcdoc:"):
                continue
            if a.kind in entries or ("minecraft:" + a.kind) in entries:
                guess.append(r)
        if len(guess) == 1 or (guess and "minecraft:data_component" in guess):
            reg = "minecraft:data_component" if "minecraft:data_component" in guess else guess[0]
            key = a.kind
        elif guess:
            print(f"{a.kind!r} exists in several schemas: " + ", ".join(g.removeprefix("minecraft:") for g in guess))
            print(f"use: pw schema <kind> {a.kind}")
            return 1
        else:
            hits = schema.lookup_type(a.kind)
            if hits:
                for p, e in hits[:3]:
                    print(f"{p}:")
                    print(pr.ty(e["type"], "", 0))
                return 0
            print(f"unknown schema kind {a.kind!r}; kinds: " + ", ".join(sorted(SCHEMA_KINDS)))
            return 1
    keys = visible_keys(reg)
    if not key:
        if a.json:
            out_json(keys)
        else:
            print(f"{reg} ({len(keys)}): " + ", ".join(keys))
            print(f"pw schema {a.kind} <key> for one of them")
        return 0
    key = key.removeprefix("minecraft:")
    entries = schema.dispatchers()[reg]
    if key not in entries or key in HIDDEN_KEYS:
        sug = schema.suggest(key, keys, 5)
        print(f"{key!r} is not in {reg} for 1.21.8" + ("; did you mean " + ", ".join(sug) if sug else ""))
        return 1
    entry = entries[key]
    if a.json:
        out_json(entry)
        return 0
    print(f"{reg}[{key}]:")
    if entry.get("doc") and not a.no_docs:
        for line in entry["doc"].split("\n"):
            print("// " + line)
    print(pr.ty(entry["type"], "", 0))
    return 0


def vanilla_key(q):
    q = q.strip().removeprefix("minecraft:").removeprefix("data/").removeprefix("minecraft/")
    if not q.endswith(".json"):
        q += ".json"
    return "minecraft/" + q


def cmd_vanilla(a):
    v = data.vanilla()
    if a.grep:
        needle = a.grep.lower()
        hits = [p for p, val in v.items() if needle in json.dumps(val, ensure_ascii=False).lower() and all(t in p for t in a.query)]
        for p in hits[: a.limit]:
            print(p)
        print(f"{len(hits)} vanilla files contain {a.grep!r}" + (f" (showing {a.limit})" if len(hits) > a.limit else ""))
        return 0 if hits else 1
    if not a.query:
        dirs = {}
        for p in v:
            parts = p.split("/")
            d = parts[1] if parts[1] not in ("tags", "worldgen") else "/".join(parts[1:3])
            dirs[d] = dirs.get(d, 0) + 1
        for d, n in sorted(dirs.items()):
            print(f"{d:<40} {n}")
        return 0
    key = vanilla_key(a.query[0]) if len(a.query) == 1 else None
    if key and key in v:
        print(json.dumps(v[key], ensure_ascii=False, indent=2))
        return 0
    hits = [p for p in v if all(t.lower() in p for t in a.query)]
    if len(hits) == 1:
        print(f"// {hits[0]}")
        print(json.dumps(v[hits[0]], ensure_ascii=False, indent=2))
        return 0
    for p in hits[: a.limit]:
        print(p)
    print(f"{len(hits)} matches" + (f" (showing {a.limit})" if len(hits) > a.limit else ""))
    return 0 if hits else 1


def cmd_lang(a):
    q = " ".join(a.query).lower()
    hits = [(k, t) for k, t in data.lang().items() if q in k.lower() or q in t.lower()]
    hits.sort(key=lambda kt: (q not in kt[0].lower(), len(kt[0])))
    if a.json:
        out_json(dict(hits[: a.limit]))
        return 0 if hits else 1
    for k, t in hits[: a.limit]:
        print(f"{k} = {t}")
    print(f"{len(hits)} matches")
    return 0 if hits else 1


def finish(rep, a):
    if a.json:
        out_json(rep.to_dict())
    else:
        print_report(rep, show_info=not a.quiet)
    return 1 if rep.counts()["error"] else 0


def cmd_check(a):
    if a.merge:
        if len(a.paths) < 2:
            print("--merge needs two or more data pack folders or zips, e.g. pw check --merge packs/*")
            return 2
        return finish(check_merged(a.paths), a)
    reports = []
    for p in a.paths:
        path = Path(p)
        try:
            found = path.exists()
        except (OSError, ValueError):
            found = False
        if not found:
            rep = Report(p)
            rep.diags.append(Diag("error", "NOT_FOUND", f"{p} does not exist"))
            reports.append(rep)
            continue
        reports.append(check_path(path))
    code = 0
    if a.json:
        out_json([r.to_dict() for r in reports] if len(reports) > 1 else reports[0].to_dict())
        return 1 if any(r.counts()["error"] for r in reports) else 0
    for rep in reports:
        print_report(rep, show_info=not a.quiet)
        if rep.counts()["error"]:
            code = 1
    return code


def is_file(p):
    try:
        return Path(p).is_file()
    except (OSError, ValueError):
        return False


def cmd_check_json(a):
    src = a.source
    if src == "-":
        text = read_stdin()
        target = "<stdin>"
    elif not src.lstrip().startswith(("{", "[", '"')) and is_file(src):
        text = Path(src).read_text(encoding="utf-8-sig")
        target = src
    else:
        text = src
        target = "<inline>"
    kind = a.type.strip().removeprefix("minecraft:")
    alias = {"loot": "loot_table", "modifier": "item_modifier", "advancements": "advancement", "tag": "tags/item"}
    kind = alias.get(kind, kind)
    if kind != "pack_mcmeta" and not kind.startswith("tags/") and kind not in schema.dispatchers().get("minecraft:resource", {}):
        print(f"unknown resource type {kind!r}; use one of: " + ", ".join(sorted(k for k in schema.dispatchers()["minecraft:resource"] if not k.startswith("%"))) + ", pack_mcmeta, tags/<registry>")
        return 2
    return finish(check_json_as(kind, text, target), a)


def cmd_cmd(a):
    if a.commands == ["-"]:
        text = read_stdin()
    else:
        text = "\n".join(a.commands)
    return finish(check_commands_text(text, "<commands>"), a)


def cmd_new(a):
    root = Path(a.dir)
    ns = a.namespace or re.sub(r"[^a-z0-9_]", "_", root.name.lower()) or "pack"
    if not re.fullmatch(r"[a-z0-9_.\-]+", ns):
        print(f"invalid namespace {ns!r}; use a-z 0-9 _ - .")
        return 2
    if root.exists() and any(root.iterdir()) and not a.force:
        print(f"{root} is not empty; use --force to add files anyway (existing files are kept)")
        return 1
    files = {
        "pack.mcmeta": json.dumps({"pack": {"pack_format": data.profile()["pack_format"], "description": a.description or ns}}, ensure_ascii=False, indent=2) + "\n",
        "data/minecraft/tags/function/load.json": json.dumps({"values": [f"{ns}:load"]}, indent=2) + "\n",
        "data/minecraft/tags/function/tick.json": json.dumps({"values": [f"{ns}:tick"]}, indent=2) + "\n",
        f"data/{ns}/function/load.mcfunction": f"scoreboard objectives add {ns}.tmp dummy\nscoreboard objectives add {ns}.const dummy\n",
        f"data/{ns}/function/tick.mcfunction": "",
    }
    made = []
    for rel, body in files.items():
        p = root / rel
        if p.exists():
            continue
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(body)
        made.append(rel)
    if a.json:
        out_json({"dir": str(root), "namespace": ns, "pack_format": data.profile()["pack_format"], "created": made})
        return 0
    print(f"created {len(made)} files in {root} (namespace {ns}, pack_format {data.profile()['pack_format']})")
    for m in made:
        print("  " + m)
    return 0


def cmd_pack(a):
    root = Path(a.dir)

    def done(code, message, rep=None, **extra):
        if a.json:
            obj = {"ok": code == 0, "message": message}
            obj.update(extra)
            if rep is not None:
                obj["report"] = rep.to_dict()
            out_json(obj)
        else:
            print(message)
        return code

    if not (root / "pack.mcmeta").is_file():
        return done(1, f"{root} has no pack.mcmeta at its top level")
    rep = PackChecker(load_dir(root), str(root)).run()
    if not a.json:
        print_report(rep, show_info=False)
    if rep.counts()["error"] and not a.force:
        return done(1, "not packed because of errors; fix them or use --force", rep)
    out = Path(a.output) if a.output else root.with_suffix(".zip")
    if out.resolve().is_relative_to(root.resolve()):
        return done(2, "the output zip must be outside the pack folder", rep)
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            rel = p.relative_to(root).as_posix()
            if p.is_dir() or any(part.startswith(".") for part in rel.split("/")):
                continue
            z.write(p, rel)
            n += 1
    return done(0, f"wrote {out} ({n} files); put it in <world>/datapacks/ and run /reload", rep, output=str(out), files=n)


def build():
    ap = argparse.ArgumentParser(prog="pw", description="PackWright tools for Minecraft Java 1.21.8 commands and data packs")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_, aliases=()):
        p = sub.add_parser(name, help=help_, aliases=list(aliases))
        p.set_defaults(fn=fn)
        p.add_argument("--json", action="store_true", help="machine-readable output")
        return p

    add("doctor", cmd_doctor, "verify the toolkit")
    p = add("find", cmd_find, "search the knowledge base, schema keys and ids", ["search"])
    p.add_argument("query", nargs="+")
    p.add_argument("--limit", type=int, default=8)
    p = add("id", cmd_id, "look up ids by id, English or Chinese name; list a registry")
    p.add_argument("query", nargs="*")
    p.add_argument("--limit", type=int, default=25)
    p.add_argument("--all", action="store_true")
    p = add("block", cmd_block, "block states, defaults and tags")
    p.add_argument("id")
    p = add("item", cmd_item, "an item's default components and tags")
    p.add_argument("id")
    p = add("tag", cmd_tag, "list vanilla tags of a registry or expand one tag")
    p.add_argument("registry")
    p.add_argument("tag", nargs="?")
    p = add("usage", cmd_usage, "official command syntax from the 1.21.8 command tree", ["syntax"])
    p.add_argument("words", nargs="*")
    p.add_argument("--types", action="store_true", help="show argument types")
    p = add("schema", cmd_schema, "fields of a component, trigger, loot function, entity, dialog, ...")
    p.add_argument("kind", nargs="?")
    p.add_argument("key", nargs="?")
    p.add_argument("--depth", type=int, default=2)
    p.add_argument("--no-docs", action="store_true")
    p.add_argument("--flat", action="store_true", help="inline inherited fields (...Base) so every field is listed")
    p = add("vanilla", cmd_vanilla, "print or search vanilla 1.21.8 data files")
    p.add_argument("query", nargs="*")
    p.add_argument("--grep", help="list files whose content contains this text")
    p.add_argument("--limit", type=int, default=40)
    p = add("lang", cmd_lang, "search English translation keys and texts")
    p.add_argument("query", nargs="+")
    p.add_argument("--limit", type=int, default=30)
    strict_help = "allow only A-Z a-z 0-9 _ - . + in objective, team and tag names (default: any characters)"
    p = add("check", cmd_check, "check a data pack folder or zip, a .mcfunction, a commands .txt, or a data .json")
    p.add_argument("paths", nargs="+")
    p.add_argument("--quiet", action="store_true", help="hide notes")
    p.add_argument("--merge", action="store_true", help="check several packs together as one world (references between packs resolve, tick and load of all packs are followed)")
    p.add_argument("--strict-names", action="store_true", help=strict_help)
    p = add("check-json", cmd_check_json, "check JSON as a resource type: pw check-json loot_table file.json | - | '{...}'")
    p.add_argument("type")
    p.add_argument("source")
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--strict-names", action="store_true", help=strict_help)
    p = add("cmd", cmd_cmd, "check one or more commands: pw cmd \"give @s stone\" | pw cmd -")
    p.add_argument("commands", nargs="+")
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--strict-names", action="store_true", help=strict_help)
    p = add("new", cmd_new, "create a data pack skeleton")
    p.add_argument("dir")
    p.add_argument("--namespace", "--ns")
    p.add_argument("--description")
    p.add_argument("--force", action="store_true")
    p = add("pack", cmd_pack, "check a pack folder and zip it for <world>/datapacks/")
    p.add_argument("dir")
    p.add_argument("-o", "--output")
    p.add_argument("--force", action="store_true")
    p.add_argument("--strict-names", action="store_true", help=strict_help)
    return ap


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    ap = build()
    a = ap.parse_args(argv)
    if getattr(a, "strict_names", False):
        argmod.OPTIONS["strict_names"] = True
    try:
        return a.fn(a)
    except BrokenPipeError:
        return 0
    except KeyboardInterrupt:
        return 130
