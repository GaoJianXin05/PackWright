import difflib
import re

from . import data
from .snbt import N, Arr, Wild, WILD, SnbtError
from .snbt import parse as snbt_parse

RL_RE = re.compile(r"^(?:[a-z0-9_.\-]+:)?[a-z0-9_.\-/]+$")
RL_RE_W = re.compile(r"^(?:[a-z0-9_.\-" + WILD + r"]+:)?[a-z0-9_.\-/" + WILD + r"]+$")

DATA_DRIVEN = {
    "advancement", "banner_pattern", "cat_variant", "chat_type", "chicken_variant", "cow_variant",
    "damage_type", "dialog", "dimension", "dimension_type", "enchantment", "enchantment_provider",
    "frog_variant", "function", "instrument", "item_modifier", "jukebox_song", "loot_table",
    "painting_variant", "pig_variant", "predicate", "recipe", "structure", "test_environment",
    "test_instance", "trial_spawner", "trim_material", "trim_pattern", "wolf_sound_variant",
    "wolf_variant", "worldgen/biome", "worldgen/configured_carver", "worldgen/configured_feature",
    "worldgen/density_function", "worldgen/flat_level_generator_preset",
    "worldgen/multi_noise_biome_source_parameter_list", "worldgen/noise", "worldgen/noise_settings",
    "worldgen/placed_feature", "worldgen/processor_list", "worldgen/structure",
    "worldgen/structure_set", "worldgen/template_pool", "worldgen/world_preset",
}
OPEN_IDS = {"sound_event", "texture", "model", "item_model", "equipment", "storage", "font", "atlas",
            "attribute_modifier", "shader", "shader_target", "weighed_sound_event", "bossbar",
            "waypoint_style", "tooltip_style", "item_definition", "random_sequence", "lang", "post_effect"}

RENAMED = {
    ("loot_function_type", "set_nbt"): "renamed to minecraft:set_custom_data in 1.20.5",
    ("loot_function_type", "copy_nbt"): "renamed to minecraft:copy_custom_data in 1.20.5",
    ("loot_condition_type", "alternative"): "renamed to minecraft:any_of",
    ("block", "grass"): "renamed to minecraft:short_grass in 1.20.3",
    ("item", "grass"): "renamed to minecraft:short_grass in 1.20.3",
    ("item", "scute"): "renamed to minecraft:turtle_scute in 1.20.5",
    ("enchantment", "sweeping"): "renamed to minecraft:sweeping_edge in 1.20.5",
    ("data_component_type", "hide_tooltip"): "replaced by tooltip_display={hide_tooltip:true} in 1.21.5",
    ("data_component_type", "hide_additional_tooltip"): "replaced by tooltip_display={hidden_components:[...]} in 1.21.5",
    ("data_component_type", "fire_resistant"): "replaced by damage_resistant={types:'#minecraft:is_fire'} in 1.21.2",
}


def renamed_hint(registry, path):
    if registry == "attribute":
        for pre in ("generic.", "player.", "zombie."):
            if path.startswith(pre):
                return f"attribute ids lost their '{pre}' prefix in 1.21.2: use minecraft:{path[len(pre):]}"
    return RENAMED.get((registry, path)) or ""


LEGACY_HINTS = {
    "Count": "item stacks use lower-case 'count' since 1.20.5",
    "tag": "item NBT 'tag' was replaced by 'components' (1.20.5+)",
    "display": "use the custom_name / item_name / lore components",
    "Enchantments": "use the enchantments component, e.g. enchantments={sharpness:5}",
    "HandItems": "use equipment:{mainhand:{...},offhand:{...}} (1.21.5+)",
    "ArmorItems": "use equipment:{head:{...},chest:{...},legs:{...},feet:{...}} (1.21.5+)",
    "body_armor_item": "use equipment:{body:{...}} (1.21.5+)",
    "HandDropChances": "use drop_chances:{mainhand:0.0f,...} (1.21.5+)",
    "ArmorDropChances": "use drop_chances:{head:0.0f,...} (1.21.5+)",
    "body_armor_drop_chance": "use drop_chances:{body:...} (1.21.5+)",
    "Attributes": "use attributes:[{id:'minecraft:max_health',base:40.0}] (1.20.5+)",
    "clickEvent": "renamed to click_event in 1.21.5 (with url / command / page instead of value)",
    "hoverEvent": "renamed to hover_event in 1.21.5 (show_text uses value)",
    "hide_tooltip": "replaced by tooltip_display={hide_tooltip:true} in 1.21.5",
    "hide_additional_tooltip": "replaced by tooltip_display={hidden_components:[...]} in 1.21.5",
    "fire_resistant": "replaced by damage_resistant={types:'#minecraft:is_fire'} in 1.21.2",
    "HideFlags": "use tooltip_display={hidden_components:[...]}",
    "CustomModelData": "use the custom_model_data component, e.g. custom_model_data={floats:[1.0f]}",
    "Unbreakable": "use the unbreakable component: unbreakable={}",
    "SkullOwner": "use the profile component",
    "BlockEntityTag": "use the block_entity_data component (needs an id field)",
    "EntityTag": "use the entity_data component (needs an id field)",
    "CustomPotionEffects": "use potion_contents={custom_effects:[...]}",
    "Potion": "use potion_contents={potion:'minecraft:...'}",
    "show_in_tooltip": "removed in 1.21.5; hide parts of the tooltip with tooltip_display={hidden_components:[...]}",
    "SaddleItem": "use equipment:{saddle:{id:'minecraft:saddle'}} (1.21.5+)",
    "Saddle": "use equipment:{saddle:{id:'minecraft:saddle'}} (1.21.5+)",
    "FallDistance": "renamed to fall_distance in 1.21.5",
    "Particle": "renamed to custom_particle in 1.21.6 (area_effect_cloud)",
    "LifeTicks": "renamed to life_ticks in 1.21.5",
    "contents": "1.21.5 hover events: show_text uses value; show_item/show_entity fields are inlined",
    "item": "advancement icons and item stacks use id (1.20.5+)",
    "nbt": "item predicates match components/predicates since 1.20.5",
    "Name": "attributes use id instead of Name; block states in NBT keep Name",
    "Base": "attributes use base instead of Base (1.20.5+)",
    "Modifiers": "attributes use modifiers instead of Modifiers (1.20.5+)",
    "UUID": "attribute modifiers use id (a resource location) instead of UUID (1.21+)",
    "AttributeName": "attribute modifiers use type instead of AttributeName",
    "food": "food is a component; nutrition/saturation/can_always_eat only, eating time moved to consumable",
}


class Issue:
    __slots__ = ("kind", "path", "message", "hint", "code")

    def __init__(self, kind, path, message, hint="", code=""):
        self.kind = kind
        self.path = path
        self.message = message
        self.hint = hint
        self.code = code

    def where(self):
        out = ""
        for p in self.path:
            out += f"[{p}]" if isinstance(p, int) else (("." if out else "") + str(p))
        return out


class Ref:
    __slots__ = ("registry", "id", "tag", "path")

    def __init__(self, registry, id_, tag, path):
        self.registry = registry
        self.id = id_
        self.tag = tag
        self.path = path


class Ctx:
    def __init__(self, strict=True, snbt=False):
        self.strict = strict
        self.snbt = snbt
        self.refs = []
        self.budget = 20000


class Scope:
    __slots__ = ("value", "key", "parent")

    def __init__(self, value, key=None, parent=None):
        self.value = value
        self.key = key
        self.parent = parent


ANY = {"k": "any"}

TEXT_PATH = "::java::util::text::Text"
# a string that looks like JSON/SNBT text component source: {"text":...}, [{"text":...}], {text:...}
TEXT_SOURCE_RE = re.compile(r"""^\s*[\[{].*["']?\b(?:text|translate|selector|keybind|score|nbt|extra)\b["']?\s*:""", re.S)


def is_text_type(ty, depth=0):
    k = ty.get("k")
    if k == "ref":
        return ty.get("path") == TEXT_PATH
    if k == "union" and depth < 4:
        return any(is_text_type(m, depth + 1) for m in ty.get("of", []))
    return False


def text_source_issue(value, path, ctx, issues):
    """A string used as a text component is shown literally; JSON written inside it is a classic mistake."""
    if len(value) < 6 or value.rstrip()[-1] not in "}]" or not TEXT_SOURCE_RE.match(value):
        return
    shown = value if len(value) <= 40 else value[:37] + "..."
    if ctx.snbt:
        hint = "since 1.21.5 write the component itself, without the outer quotes, e.g. {text:'Name',color:'gold'}"
    else:
        hint = "write the component as a JSON object or list, not as a string that contains JSON"
    issues.append(Issue("text_json", path, f"{shown!r} is a plain string, so the game shows it as literal text including the braces", hint, "TEXT_JSON_STRING"))


def snbt_string_issue(value, path, issues):
    """Strings marked #[nbt] hold an SNBT compound, which the game parses when the file loads."""
    if WILD in value:
        return
    try:
        parsed, _ = snbt_parse(value)
    except SnbtError as e:
        issues.append(Issue("snbt", path, f"this string is not valid SNBT: {e.message}", f"the game parses it with the SNBT rules (at character {e.pos}); the whole {{...}} must be well formed", "NBT_STRING"))
        return
    if not isinstance(parsed, dict) and not isinstance(parsed, Wild):
        issues.append(Issue("snbt", path, "this string must hold an NBT compound like {key:value}", "", "NBT_STRING"))


def types():
    return data.schema()["types"]


def dispatchers():
    return data.schema()["dispatch"]


def dispatch_entry(reg, key):
    table = dispatchers().get(reg)
    if table is None:
        return None
    if key is not None:
        k = data.strip_ns(str(key))
        if k in table:
            return table[k]
    if key is None and "%none" in table:
        return table["%none"]
    if "%unknown" in table:
        return table["%unknown"]
    return None


def scope_lookup(scope, path):
    parts = path.split(".")
    cur = scope
    value = None
    for i, part in enumerate(parts):
        if cur is None:
            return None
        if part == "%parent":
            cur = cur.parent
            continue
        if part == "%key":
            value = cur.key
            break
        v = cur.value
        if isinstance(v, dict):
            value = v.get(part)
        else:
            value = None
        rest = parts[i + 1 :]
        for r in rest:
            if isinstance(value, dict):
                value = value.get(r)
            else:
                value = None
        break
    if isinstance(value, str) and not isinstance(value, Wild):
        return value
    return None


def resolve(ty, env, scope=None, depth=0):
    while True:
        if depth > 60:
            return ANY, {}
        depth += 1
        k = ty.get("k")
        if k == "ref":
            entry = types().get(ty["path"])
            if entry is None:
                return ANY, {}
            params = entry.get("params") or []
            new_env = {}
            args = ty.get("args") or []
            for i, p in enumerate(params):
                if i < len(args):
                    new_env[p] = (args[i], env)
            ty, env = entry["type"], new_env
            continue
        if k == "param":
            bound = env.get(ty["name"])
            if bound is None:
                return ANY, {}
            ty, env = bound
            continue
        if k == "dispatch":
            if "dyn" in ty:
                if scope is None:
                    return ANY, {}
                if ty["dyn"] == "%key":
                    key = scope.key if isinstance(scope.key, str) else None
                else:
                    key = scope_lookup(scope, ty["dyn"])
                entry = dispatch_entry(ty["reg"], key)
            else:
                keys = ty.get("keys") or []
                if not keys or keys[0] in ("%fallback", "%unknown", "%parent"):
                    return ANY, {}
                entry = dispatch_entry(ty["reg"], keys[0])
            if entry is None:
                return ANY, {}
            ty, env = entry["type"], {}
            continue
        if k in ("index", "constrained"):
            if k == "constrained":
                ty = ty["of"]
                continue
            return ANY, {}
        return ty, env


def is_num(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)) or isinstance(v, N)


def num_value(v):
    if isinstance(v, N):
        return None if v.wild else v.value
    return v


def kind_of(v):
    if isinstance(v, Wild):
        return "wild"
    if isinstance(v, dict):
        return "object"
    if isinstance(v, list):
        return "list"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, N):
        return "boolean" if v.boolean else "number"
    if is_num(v):
        return "number"
    if isinstance(v, str):
        return "text"
    if v is None:
        return "null"
    return "value"


def base_kinds(ty, env, depth=0):
    ty, env = resolve(ty, env)
    k = ty.get("k")
    if k == "any":
        return {"*"}
    if k == "struct":
        return {"object"}
    if k in ("list", "tuple", "arr"):
        return {"list"}
    if k == "str":
        return {"text"}
    if k == "num":
        return {"number"}
    if k == "bool":
        return {"boolean", "number"}
    if k == "enum":
        return {"text"} if ty.get("t") == "string" else {"number"}
    if k == "lit":
        v = ty.get("v")
        if isinstance(v, bool):
            return {"boolean"}
        if isinstance(v, (int, float)):
            return {"number"}
        return {"text"}
    if k == "union":
        if depth > 8:
            return {"*"}
        out = set()
        for m in ty.get("of", []):
            out |= base_kinds(m, env, depth + 1)
        return out
    return {"*"}


def kind_ok(vk, kinds, ctx):
    if "*" in kinds or vk == "wild":
        return True
    if vk in kinds:
        return True
    if vk == "number" and "boolean" in kinds:
        return True
    if vk == "boolean" and "number" in kinds and ctx.snbt:
        return True
    if vk == "boolean" and "boolean" in kinds:
        return True
    return False


KIND_WORDS = {"object": "an object {...}", "list": "a list [...]", "text": "a string", "number": "a number", "boolean": "true/false"}


def expect_words(kinds):
    words = [KIND_WORDS.get(k, k) for k in sorted(kinds) if k != "*"]
    if "boolean" in kinds and "number" in kinds and len(kinds) == 2:
        words = [KIND_WORDS["boolean"]]
    return " or ".join(words) or "a value"


def check_range(value, rng):
    if not rng:
        return True
    lo, hi = rng.get("lo"), rng.get("hi")
    if lo is not None:
        if rng.get("lx") and not value > lo:
            return False
        if not rng.get("lx") and value < lo:
            return False
    if hi is not None:
        if rng.get("hx") and not value < hi:
            return False
        if not rng.get("hx") and value > hi:
            return False
    return True


def range_text(rng):
    lo, hi = rng.get("lo"), rng.get("hi")
    a = "" if lo is None else str(lo)
    b = "" if hi is None else str(hi)
    if lo is not None and lo == hi:
        return f"exactly {a}"
    return f"{a}{'<' if rng.get('lx') else ''}..{'<' if rng.get('hx') else ''}{b}"


def id_attr(ty):
    for a in ty.get("attrs", []) or []:
        if a.get("name") == "id":
            return a.get("id", {})
    return None


def has_attr(ty, name):
    return any(a.get("name") == name for a in ty.get("attrs", []) or [])


def suggest(value, pool, n=3):
    return difflib.get_close_matches(value, pool, n=n, cutoff=0.6)


def check_id(value, info, ctx, path, issues):
    if isinstance(value, Wild) or WILD in value:
        return
    registry = (info.get("registry") or "").removeprefix("minecraft:")
    tags_mode = info.get("tags")
    raw = value
    prefix = info.get("prefix")
    if prefix and raw.startswith(prefix):
        raw = raw[len(prefix) :]
    if raw == "" and info.get("empty") == "allowed":
        return
    is_tag = raw.startswith("#")
    body = raw[1:] if is_tag else raw
    if tags_mode == "implicit":
        is_tag = True
    if is_tag and tags_mode not in ("allowed", "required", "implicit"):
        issues.append(Issue("id", path, f"{value!r}: a tag (#...) is not allowed here"))
        return
    if not is_tag and tags_mode == "required":
        issues.append(Issue("id", path, f"{value!r}: this field needs a tag reference starting with '#'"))
        return
    if not RL_RE.match(body):
        hint = ""
        if any(c.isupper() for c in body):
            hint = "resource locations are lower-case"
        elif not body.isascii():
            hint = "resource locations allow only a-z 0-9 _ - . / (and one ':')"
        issues.append(Issue("id", path, f"{value!r} is not a valid resource location", hint))
        return
    ns, p = data.split_id(body)
    if info.get("exclude") and p in info["exclude"] and ns == "minecraft":
        issues.append(Issue("id", path, f"{value!r} is not allowed here"))
        return
    if not registry:
        return
    if is_tag:
        if ns == "minecraft":
            known = data.has_tag(registry, body)
            if known is False:
                pool = list(data.tags().get(registry, {}))
                sug = suggest(p, pool)
                ctx.refs.append(Ref(registry, f"{ns}:{p}", True, path))
                issues.append(Issue("id_soft", path, f"tag #{ns}:{p} is not a vanilla {registry} tag", ("did you mean " + ", ".join("#minecraft:" + s for s in sug)) if sug else ""))
        else:
            ctx.refs.append(Ref(registry, f"{ns}:{p}", True, path))
        return
    if registry in OPEN_IDS:
        if ns == "minecraft" and registry in data.registry_sets() and p not in data.registry_sets()[registry]:
            sug = suggest(p, list(data.registry_sets()[registry]))
            issues.append(Issue("id_soft", path, f"minecraft:{p} is not a vanilla {registry}", ("did you mean " + ", ".join(sug)) if sug else ""))
        return
    if registry in DATA_DRIVEN:
        if ns == "minecraft" and data.in_registry(registry, body):
            return
        ctx.refs.append(Ref(registry, f"{ns}:{p}", False, path))
        return
    if ns != "minecraft":
        return
    known = data.in_registry(registry, body)
    if known is False:
        sug = suggest(p, list(data.registry_sets()[registry]))
        hint = renamed_hint(registry, p) or (("did you mean " + ", ".join(sug)) if sug else f"run: pw id {registry} {p}")
        issues.append(Issue("id", path, f"minecraft:{p} does not exist in the 1.21.8 {registry} registry", hint))


def validate(value, ty, ctx, path=(), env=None, scope=None, depth=0):
    issues = []
    _v(value, ty, env or {}, ctx, list(path), scope, issues, depth)
    return issues


def _v(value, ty, env, ctx, path, scope, issues, depth):
    ctx.budget -= 1
    if ctx.budget < 0 or depth > 120:
        return
    if isinstance(value, Wild):
        return
    raw_ty = ty
    ty, env = resolve(ty, env, scope)
    k = ty.get("k")
    if k == "any":
        return
    if isinstance(value, str) and (is_text_type(raw_ty) or is_text_type(ty)):
        text_source_issue(value, path, ctx, issues)
    attrs_ty = raw_ty if raw_ty.get("attrs") else ty
    if k == "union":
        _union(value, ty, env, ctx, path, scope, issues, depth)
        return
    vk = kind_of(value)
    if k == "struct":
        if not isinstance(value, dict):
            issues.append(Issue("type", path, f"expected an object {{...}}, found {vk}"))
            return
        _struct(value, ty, env, ctx, path, scope, issues, depth)
        return
    if k == "list":
        if not isinstance(value, list):
            issues.append(Issue("type", path, f"expected a list [...], found {vk}"))
            return
        rng = ty.get("len") or ty.get("range")
        if rng and not check_range(len(value), rng):
            issues.append(Issue("range", path, f"list has {len(value)} entries; expected {range_text(rng)}"))
        sc = Scope(value, None, scope)
        for i, item in enumerate(value[:512]):
            _v(item, ty["of"], env, ctx, path + [i], sc, issues, depth + 1)
        return
    if k == "tuple":
        if not isinstance(value, list):
            issues.append(Issue("type", path, f"expected a list of {len(ty['items'])} values, found {vk}"))
            return
        if len(value) != len(ty["items"]):
            issues.append(Issue("type", path, f"expected exactly {len(ty['items'])} values, found {len(value)}"))
            return
        sc = Scope(value, None, scope)
        for i, (item, t) in enumerate(zip(value, ty["items"])):
            _v(item, t, env, ctx, path + [i], sc, issues, depth + 1)
        return
    if k == "arr":
        if not isinstance(value, list):
            issues.append(Issue("type", path, f"expected an array of numbers, found {vk}"))
            return
        rng = ty.get("len")
        if rng and not check_range(len(value), rng):
            issues.append(Issue("range", path, f"array has {len(value)} entries; expected {range_text(rng)}"))
        for i, item in enumerate(value):
            if not is_num(item) and not isinstance(item, Wild):
                issues.append(Issue("type", path + [i], f"expected a number, found {kind_of(item)}"))
                break
        return
    if k == "num":
        if not is_num(value):
            if isinstance(value, bool) or (isinstance(value, N) and value.boolean):
                if ctx.snbt or isinstance(value, N):
                    return
            issues.append(Issue("type", path, f"expected a number ({ty.get('t')}), found {vk}" + (f" {value!r}" if isinstance(value, str) else "")))
            return
        nv = num_value(value)
        if nv is None:
            return
        if ty.get("t") in ("byte", "short", "int", "long") and isinstance(nv, float) and not float(nv).is_integer():
            issues.append(Issue("range", path, f"{nv} will be truncated: this field is an integer ({ty['t']})"))
        rng = ty.get("range")
        if rng and not check_range(nv, rng):
            issues.append(Issue("range", path, f"{nv} is outside the allowed range {range_text(rng)}"))
        return
    if k == "bool":
        if isinstance(value, bool) or (isinstance(value, N)) or (is_num(value)):
            return
        issues.append(Issue("type", path, f"expected true/false, found {vk}" + (f" {value!r}" if isinstance(value, str) else "")))
        return
    if k == "str":
        if not isinstance(value, str):
            issues.append(Issue("type", path, f"expected a string, found {vk}"))
            return
        rng = ty.get("len")
        if rng and not check_range(len(value), rng):
            issues.append(Issue("range", path, f"text length {len(value)} is outside {range_text(rng)}"))
        info = id_attr(attrs_ty) or id_attr(ty)
        if info is not None:
            check_id(value, info, ctx, path, issues)
        elif has_attr(attrs_ty, "nbt") or has_attr(ty, "nbt"):
            snbt_string_issue(value, path, issues)
        return
    if k == "lit":
        lv = ty.get("v")
        if isinstance(lv, str):
            if isinstance(value, str) and (value == lv or data.strip_ns(value) == lv):
                return
            issues.append(Issue("enum", path, f"expected {lv!r}, found {value!r}"))
            return
        if isinstance(lv, bool):
            if value == lv or (isinstance(value, N) and bool(value.value) == lv):
                return
            issues.append(Issue("enum", path, f"expected {str(lv).lower()}, found {value!r}"))
            return
        if is_num(value) and num_value(value) == lv:
            return
        issues.append(Issue("enum", path, f"expected {lv!r}, found {value!r}"))
        return
    if k == "enum":
        vals = [e["v"] for e in ty.get("vals", [])]
        if ty.get("t") == "string":
            if not isinstance(value, str):
                issues.append(Issue("type", path, f"expected one of {', '.join(map(str, vals[:12]))}; found {vk}"))
                return
            if value in vals or data.strip_ns(value) in vals:
                return
            sug = suggest(data.strip_ns(value), [str(v) for v in vals])
            issues.append(Issue("enum", path, f"{value!r} is not one of: {', '.join(map(str, vals[:24]))}{' ...' if len(vals) > 24 else ''}", ("did you mean " + ", ".join(sug)) if sug else ""))
            return
        if not is_num(value):
            issues.append(Issue("type", path, f"expected a number, found {vk}"))
            return
        nv = num_value(value)
        if nv is not None and nv not in vals:
            issues.append(Issue("enum", path, f"{nv} is not one of: {', '.join(map(str, vals[:24]))}"))
        return


def flatten_union(ty, env, depth=0):
    out = []
    for m in ty.get("of", []):
        r, e = resolve(m, env)
        if r.get("k") == "union" and depth < 6:
            out.extend(flatten_union(r, e, depth + 1))
        else:
            out.append((m, env, r, e))
    return out


def _union(value, ty, env, ctx, path, scope, issues, depth):
    members = flatten_union(ty, env)
    if not members:
        return
    vk = kind_of(value)
    if vk == "wild":
        return
    compatible = [m for m in members if kind_ok(vk, base_kinds(m[2], m[3]), ctx)]
    if not compatible:
        kinds = set()
        for m in members:
            kinds |= base_kinds(m[2], m[3])
        hint = ""
        if isinstance(value, dict) and value and set(value) <= {"item", "tag", "count", "data"}:
            hint = "since 1.21.2 a recipe ingredient is \"minecraft:stone\", \"#minecraft:logs\" or a list of item ids"
        issues.append(Issue("type", path, f"expected {expect_words(kinds)}, found {vk}" + (f" {value!r}" if isinstance(value, str) and len(value) < 60 else ""), hint))
        return
    best = None
    start = len(ctx.refs)
    for m, menv, r, renv in compatible:
        sub = []
        _v(value, m, menv, ctx, path, scope, sub, depth + 1)
        got = ctx.refs[start:]
        del ctx.refs[start:]
        errs = sum(1 for i in sub if i.kind in ("type", "missing", "enum", "id", "snbt"))
        score = (errs, len(sub) - errs)
        if best is None or score < best[0]:
            best = (score, sub, got)
        if score == (0, 0):
            break
    issues.extend(best[1])
    ctx.refs.extend(best[2])


def struct_shape(ty, env, value, scope, depth=0):
    static = {}
    computed = []
    open_ = False
    for f in ty.get("fields", []):
        if "spread" in f:
            if depth > 12:
                open_ = True
                continue
            r, renv = resolve(f["spread"], env, Scope(value, None, scope.parent if scope else None) if False else scope)
            rk = r.get("k")
            if rk == "struct":
                s2, c2, o2 = struct_shape(r, renv, value, scope, depth + 1)
                for key, val in s2.items():
                    static.setdefault(key, val)
                computed.extend(c2)
                open_ = open_ or o2
            elif rk == "union":
                open_ = True
                for m, menv, mr, mrenv in flatten_union(r, renv):
                    if mr.get("k") == "struct":
                        s2, c2, o2 = struct_shape(mr, mrenv, value, scope, depth + 1)
                        for key, val in s2.items():
                            static.setdefault(key, (val[0], val[1], True))
            else:
                open_ = True
        elif "key" in f:
            static[f["key"]] = (f, env, False)
        else:
            computed.append((f, env))
    return static, computed, open_


def key_fits(key, kty, kenv, ctx):
    r, renv = resolve(kty, kenv)
    k = r.get("k")
    if k == "any":
        return True
    if k == "union":
        return any(key_fits(key, m, renv, ctx) for m in r.get("of", []))
    if k == "str":
        info = id_attr(kty) or id_attr(r)
        if info is None or not info.get("registry"):
            if has_attr(kty, "dispatcher_key") or has_attr(r, "dispatcher_key"):
                return True
            if info is not None and info.get("prefix"):
                return key.startswith(info["prefix"])
            if info is not None:
                return bool(RL_RE.match(key.removeprefix("#")))
            return True
        raw = key
        prefix = info.get("prefix")
        if prefix:
            if not raw.startswith(prefix):
                return False
            raw = raw[len(prefix) :]
        elif raw.startswith("!"):
            return False
        reg = info["registry"].removeprefix("minecraft:")
        if raw.startswith("#"):
            return info.get("tags") in ("allowed", "required")
        if not RL_RE.match(raw):
            return False
        if info.get("exclude") and data.strip_ns(raw) in info["exclude"]:
            return False
        if reg in data.registry_sets() and reg not in DATA_DRIVEN and reg not in OPEN_IDS:
            ns, p = data.split_id(raw)
            if ns == "minecraft":
                return p in data.registry_sets()[reg]
        return True
    if k == "enum":
        return key in [str(e["v"]) for e in r.get("vals", [])] or data.strip_ns(key) in [str(e["v"]) for e in r.get("vals", [])]
    if k == "lit":
        return key == r.get("v") or data.strip_ns(key) == r.get("v")
    return True


def _struct(value, ty, env, ctx, path, scope, issues, depth):
    here = Scope(value, None, scope)
    static, computed, open_ = struct_shape(ty, env, value, here)
    seen = set()
    for key, v in value.items():
        if isinstance(key, Wild) or WILD in key:
            open_ = True
            continue
        hit = static.get(key)
        if hit is None and ":" in key:
            hit = static.get(data.strip_ns(key))
        if hit is not None:
            seen.add(hit[0]["key"])
            _v(v, hit[0]["type"], hit[1], ctx, path + [key], Scope(value, key, scope), issues, depth + 1)
            continue
        matched = False
        for f, fenv in computed:
            if key_fits(key, f["computed"], fenv, ctx):
                matched = True
                _v(v, f["type"], fenv, ctx, path + [key], Scope(value, key, scope), issues, depth + 1)
                break
        if matched:
            continue
        if open_:
            continue
        reg_key = None
        for f, fenv in computed:
            r, _ = resolve(f["computed"], fenv)
            info = id_attr(f["computed"]) or id_attr(r)
            if info and info.get("registry"):
                reg_key = info["registry"].removeprefix("minecraft:")
                break
        if reg_key and not static:
            pool = list(data.registry_sets().get(reg_key, []))
            sug = suggest(data.strip_ns(key.lstrip("!")), pool)
            issues.append(Issue("id", path + [key], f"{key!r} is not a known {reg_key}", ("did you mean " + ", ".join(sug)) if sug else LEGACY_HINTS.get(key, "")))
            continue
        hint = LEGACY_HINTS.get(key, "")
        if not hint:
            sug = suggest(key, list(static))
            hint = ("did you mean " + ", ".join(sug)) if sug else ""
        if key in LEGACY_HINTS:
            issues.append(Issue("legacy", path + [key], f"{key!r} is old syntax and is silently ignored in 1.21.8", hint))
        else:
            issues.append(Issue("unknown_key", path + [key], f"unknown field {key!r} (ignored by the game)", hint))
    for key, (f, fenv, weak) in static.items():
        if weak or f.get("opt") or key in seen or key in value or f"minecraft:{key}" in value:
            continue
        if any(isinstance(k, Wild) or WILD in k for k in value):
            continue
        r, _ = resolve(f["type"], fenv)
        if r.get("k") == "any":
            continue
        issues.append(Issue("missing", path + [key], f"required field {key!r} is missing"))


def severity(issue, ctx):
    if issue.kind == "legacy":
        return "error"
    if issue.kind in ("unknown_key", "range", "id_soft", "text_json"):
        return "warning"
    if issue.kind == "snbt":
        return "error"
    if not ctx.strict:
        return "warning"
    return "error"


def lookup_type(query):
    q = query.strip()
    t = types()
    if q in t:
        return [(q, t[q])]
    hits = [(p, e) for p, e in t.items() if p.rsplit("::", 1)[-1] == q]
    if hits:
        return hits
    low = q.lower()
    return [(p, e) for p, e in t.items() if p.rsplit("::", 1)[-1].lower() == low]


class Printer:
    def __init__(self, depth=2, docs=True, flat=False):
        self.max = depth
        self.docs = docs
        self.flat = flat

    def spread_fields(self, spread, seen):
        if spread.get("k") != "ref":
            return None
        path = spread["path"]
        entry = types().get(path)
        if entry is None or path in seen:
            return None
        inner = entry["type"]
        if inner.get("k") != "struct":
            return None
        seen.add(path)
        out = []
        for f in inner.get("fields", []):
            if "spread" in f:
                sub = self.spread_fields(f["spread"], seen)
                if sub is not None:
                    out.extend(sub)
                    continue
            out.append((path.rsplit("::", 1)[-1], f))
        return out

    def doc_lines(self, doc, ind):
        if not doc or not self.docs:
            return []
        out = []
        for line in doc.split("\n"):
            line = line.rstrip(" \\")
            out.append(f"{ind}// {line}" if line.strip() else f"{ind}//")
        return out

    def ty(self, ty, ind, d, env=None):
        k = ty.get("k")
        attrs = ty.get("attrs") or []
        pre = ""
        info = id_attr(ty)
        if info is not None:
            reg = info.get("registry", "")
            extra = []
            if info.get("tags"):
                extra.append(f"tags={info['tags']}")
            if info.get("prefix"):
                extra.append(f"prefix={info['prefix']}")
            pre = f"#[id{'=' + reg if reg else ''}{(' ' + ' '.join(extra)) if extra else ''}] "
        if k == "any":
            return pre + "any"
        if k == "bool":
            return pre + "boolean"
        if k == "str":
            return pre + "string" + self.rng(ty.get("len"))
        if k == "num":
            return pre + ty.get("t", "number") + self.rng(ty.get("range"))
        if k == "arr":
            return pre + f"{ty['t']}[]" + self.rng(ty.get("len"))
        if k == "lit":
            v = ty.get("v")
            return pre + (f'"{v}"' if isinstance(v, str) else str(v).lower())
        if k == "list":
            return pre + "[" + self.ty(ty["of"], ind, d, env) + "]" + self.rng(ty.get("len"))
        if k == "tuple":
            return pre + "[" + ", ".join(self.ty(t, ind, d, env) for t in ty["items"]) + "]"
        if k == "enum":
            vals = [e["v"] for e in ty.get("vals", [])]
            body = " | ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in vals)
            return pre + ("(" + body + ")" if len(body) < 400 else f"enum({len(vals)} values: " + ", ".join(map(str, vals[:30])) + ", ...)")
        if k == "union":
            parts = [self.ty(m, ind + "  ", d, env) for m in ty.get("of", [])]
            if sum(len(p) for p in parts) < 100 and all("\n" not in p for p in parts):
                return pre + "(" + " | ".join(parts) + ")"
            return pre + "(\n" + "\n".join(f"{ind}  | {p}" for p in parts) + f"\n{ind})"
        if k == "ref":
            name = ty["path"].rsplit("::", 1)[-1]
            args = ty.get("args")
            label = name + ("<" + ", ".join(self.ty(a, ind, d, env) for a in args) + ">" if args else "")
            entry = types().get(ty["path"])
            if entry is not None and d < self.max:
                inner = entry["type"]
                if inner.get("k") in ("struct", "union", "enum") or d == 0:
                    return pre + label + " = " + self.ty(inner, ind, d + 1, env)
                return pre + label + " = " + self.ty(inner, ind, d + 1, env)
            return pre + label
        if k == "param":
            return pre + ty["name"]
        if k == "dispatch":
            if "dyn" in ty:
                return pre + f"<{ty['reg']} chosen by {ty['dyn']}>"
            return pre + f"{ty['reg']}[{', '.join(ty.get('keys', []))}]"
        if k == "struct":
            if d > self.max + 1:
                return pre + "struct {...}"
            lines = [pre + "struct " + (ty.get("name", "") + " " if ty.get("name") else "") + "{"]
            fields = []
            for f in ty.get("fields", []):
                if self.flat and "spread" in f:
                    sub = self.spread_fields(f["spread"], set())
                    if sub is not None:
                        last = None
                        for origin, g in sub:
                            if origin != last:
                                fields.append({"_from": origin})
                                last = origin
                            fields.append(g)
                        fields.append({"_from": ""})
                        continue
                fields.append(f)
            for f in fields:
                if "_from" in f:
                    if f["_from"]:
                        lines.append(f"{ind}  // fields from {f['_from']}:")
                    continue
                lines.extend(self.doc_lines(f.get("doc"), ind + "  "))
                if "spread" in f:
                    lines.append(f"{ind}  ...{self.ty(f['spread'], ind + '  ', d + 1, env)},")
                elif "key" in f:
                    lines.append(f"{ind}  {f['key']}{'?' if f.get('opt') else ''}: {self.ty(f['type'], ind + '  ', d + 1, env)},")
                else:
                    lines.append(f"{ind}  [{self.ty(f['computed'], ind + '  ', d + 1, env)}]: {self.ty(f['type'], ind + '  ', d + 1, env)},")
            lines.append(ind + "}")
            return "\n".join(lines)
        if k == "index":
            return pre + "any"
        if k == "constrained":
            return pre + self.ty(ty["of"], ind, d, env)
        return pre + str(k)

    def rng(self, r):
        if not r:
            return ""
        return " @ " + range_text(r).replace("exactly ", "")
