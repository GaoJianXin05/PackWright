import re

from . import data, schema
from .analysis import LIMITERS, legacy_stacks, seq_add
from .snbt import WILD, SnbtError, SnbtParser, Wild, N

UNQUOTED = set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_-.+" + WILD)
RL_CHARS = set("0123456789abcdefghijklmnopqrstuvwxyz_:/.-" + WILD)
NUM_CHARS = set("0123456789.-" + WILD)
COLORS = ["black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"]
GAMEMODES = ["survival", "creative", "adventure", "spectator"]
HEIGHTMAPS = ["world_surface", "motion_blocking", "motion_blocking_no_leaves", "ocean_floor"]
OPERATIONS = ["=", "+=", "-=", "*=", "/=", "%=", "<", ">", "><"]
SIMPLE_CRITERIA = ["dummy", "trigger", "deathCount", "playerKillCount", "totalKillCount", "health", "xp", "level", "food", "air", "armor"]
STAT_TYPES = {"mined": "block", "crafted": "item", "used": "item", "broken": "item", "picked_up": "item", "dropped": "item", "killed": "entity_type", "killed_by": "entity_type", "custom": "custom_stat"}
SORTS = ["nearest", "furthest", "random", "arbitrary"]
SLOT_RE = re.compile(
    r"^(?:container\.(?:[0-9]|[1-4][0-9]|5[0-3])|enderchest\.(?:[0-9]|1[0-9]|2[0-6])|inventory\.(?:[0-9]|1[0-9]|2[0-6])"
    r"|hotbar\.[0-8]|weapon(?:\.mainhand|\.offhand)?|armor\.(?:head|chest|legs|feet|body)|horse\.(?:chest|[0-9]|1[0-4])"
    r"|villager\.[0-7]|player\.cursor|player\.crafting\.[0-3]|contents|saddle)$"
)
SLOTS_RE = re.compile(r"^(?:container|enderchest|inventory|hotbar|armor|weapon|horse|villager|player\.crafting)\.\*$")
SLOT_SHAPE = re.compile(r"^[a-z_]+(?:\.[a-z_0-9]+)*(?:\.\*)?$")
UUID_RE = re.compile(r"^[0-9a-fA-F]{1,8}-[0-9a-fA-F]{1,4}-[0-9a-fA-F]{1,4}-[0-9a-fA-F]{1,4}-[0-9a-fA-F]{1,12}$")
PLAYER_NAME_RE = re.compile(r"^[A-Za-z0-9_]{1,16}$")

# Names of objectives, teams, tags, fake players and selector values may contain any non-ASCII
# letters. `--strict-names` limits them to A-Z a-z 0-9 _ - . +.
OPTIONS = {"strict_names": False}
# non-ASCII characters that are never part of a name: spaces and invisible characters
NAME_BREAKERS = set("\u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u200b\u200c\u200d\u2028\u2029\u202f\u205f\u2060\u3000\ufeff")
# full-width punctuation and look-alikes that usually mean the IME was in Chinese mode
FULLWIDTH_RE = re.compile("[\u2018-\u201f\u3001-\u3003\u3008-\u3011\uff01-\uff0f\uff1a-\uff20\uff3b-\uff40\uff5b-\uff65]")


class Fail(Exception):
    def __init__(self, pos, message, hint="", code="SYNTAX"):
        super().__init__(message)
        self.pos = pos
        self.message = message
        self.hint = hint
        self.code = code


class R:
    __slots__ = ("s", "i")

    def __init__(self, s, i=0):
        self.s = s
        self.i = i

    def can(self, n=1):
        return self.i + n <= len(self.s)

    def peek(self, o=0):
        j = self.i + o
        return self.s[j] if j < len(self.s) else ""

    def skip_ws(self):
        while self.i < len(self.s) and self.s[self.i] == " ":
            self.i += 1

    def rest(self):
        return self.s[self.i :]

    def word(self):
        j = self.s.find(" ", self.i)
        return self.s[self.i :] if j < 0 else self.s[self.i : j]

    def unquoted(self):
        start = self.i
        s = self.s
        n = len(s)
        loose = not OPTIONS["strict_names"]
        while self.i < n:
            c = s[self.i]
            if c in UNQUOTED or (loose and c > "\x7f" and c not in NAME_BREAKERS):
                self.i += 1
            else:
                break
        return s[start : self.i]

    def quoted(self):
        q = self.peek()
        if q not in "\"'":
            raise Fail(self.i, "expected a quote to start a string")
        start = self.i
        self.i += 1
        out = []
        while self.i < len(self.s):
            c = self.s[self.i]
            if c == "\\":
                nxt = self.peek(1)
                if nxt in ("\\", q):
                    out.append(nxt)
                    self.i += 2
                    continue
                raise Fail(self.i, f"invalid escape sequence \\{nxt} in quoted string")
            if c == q:
                self.i += 1
                return "".join(out)
            out.append(c)
            self.i += 1
        raise Fail(start, "unclosed quoted string")

    def string(self):
        if self.peek() in "\"'":
            return self.quoted()
        return self.unquoted()

    def number_text(self):
        start = self.i
        while self.i < len(self.s) and self.s[self.i] in NUM_CHARS:
            self.i += 1
        return self.s[start : self.i], start

    def rl(self):
        start = self.i
        while self.i < len(self.s) and self.s[self.i] in RL_CHARS:
            self.i += 1
        text = self.s[start : self.i]
        if not text:
            c = self.peek()
            hint = "IDs are lower-case" if c.isupper() else ("IDs allow only a-z 0-9 _ - . / :" if c and not c.isascii() else "")
            raise Fail(start, "expected a resource location (namespace:path)", hint, "INVALID_ID")
        if WILD not in text:
            if text.count(":") > 1:
                raise Fail(start, f"invalid resource location {text!r}", "only one ':' is allowed", "INVALID_ID")
            ns, _, path = text.rpartition(":")
            if (ns and not re.fullmatch(r"[a-z0-9_.\-]+", ns)) or not path or ("/" in ns):
                raise Fail(start, f"invalid resource location {text!r}", code="INVALID_ID")
        nxt = self.peek()
        if nxt and nxt.isupper():
            raise Fail(self.i, f"resource locations are lower-case: {text + self.word()[0:0]}{nxt}...", "use lower-case ids, e.g. minecraft:diamond_sword", "INVALID_ID")
        return text


class CmdCtx:
    def __init__(self, macro=False):
        self.diags = []
        self.refs = []
        self.args = {}
        self.path = []
        self.macro = macro
        self.uses = []
        self.frames = []
        self.chain = None
        self.sticky = []  # warnings that stay even when the parser backtracks; they explain why a command failed

    def warn(self, pos, code, message, hint=""):
        self.diags.append(("warning", code, message, hint, pos))

    def note(self, pos, code, message, hint=""):
        self.diags.append(("info", code, message, hint, pos))

    def error(self, pos, code, message, hint=""):
        self.diags.append(("error", code, message, hint, pos))

    def use(self, kind, value, pos, role="use"):
        self.uses.append((kind, value, role, pos))

    def snapshot(self):
        return (len(self.diags), len(self.refs), len(self.uses), dict(self.args), len(self.frames))

    def restore(self, snap):
        del self.diags[snap[0] :]
        del self.refs[snap[1] :]
        del self.uses[snap[2] :]
        del self.frames[snap[4] :]
        self.args.clear()
        self.args.update(snap[3])


def has_wild(text):
    return WILD in text


def parse_int(r, props, kind="integer"):
    text, start = r.number_text()
    if not text:
        raise Fail(start, f"expected {kind}" + (f", found {r.word()!r}" if r.word() else ""))
    if has_wild(text):
        return None
    try:
        v = int(text)
    except ValueError:
        raise Fail(start, f"invalid integer {text!r}", "this argument must be a whole number")
    lo, hi = props.get("min"), props.get("max")
    if lo is not None and v < lo:
        raise Fail(start, f"integer must not be less than {lo}, found {v}")
    if hi is not None and v > hi:
        raise Fail(start, f"integer must not be more than {hi}, found {v}")
    return v


def parse_float(r, props, kind="number"):
    text, start = r.number_text()
    if not text:
        raise Fail(start, f"expected a {kind}" + (f", found {r.word()!r}" if r.word() else ""))
    if has_wild(text):
        return None
    try:
        v = float(text)
    except ValueError:
        raise Fail(start, f"invalid number {text!r}")
    if r.peek() and r.peek() in "fFdD":
        raise Fail(r.i, f"number suffix '{r.peek()}' is not allowed in command arguments", "write the plain number, e.g. 1.5")
    lo, hi = props.get("min"), props.get("max")
    if lo is not None and v < lo:
        raise Fail(start, f"number must not be less than {lo}, found {v}")
    if hi is not None and v > hi:
        raise Fail(start, f"number must not be more than {hi}, found {v}")
    return v


def parse_bool(r):
    start = r.i
    w = r.unquoted()
    if has_wild(w):
        return None
    if w not in ("true", "false"):
        raise Fail(start, f"expected true or false, found {w!r}")
    return w == "true"


def parse_string(r, props, ctx):
    kind = props.get("type")
    start = r.i
    if kind == "greedy":
        r.i = len(r.s)
        return r.s[start:]
    if kind == "word":
        w = r.unquoted()
        if not w:
            c = r.peek()
            raise Fail(start, f"expected a plain word, found {c!r}", word_hint(c))
        name_warn(ctx, start, w)
        return w
    if r.peek() in "\"'":
        return r.quoted()
    w = r.unquoted()
    if not w and r.peek():
        raise Fail(start, f"expected a word or a quoted string, found {r.peek()!r}", word_hint(r.peek()))
    name_warn(ctx, start, w)
    return w


def word_hint(c):
    if c and not c.isascii():
        if c in NAME_BREAKERS:
            if c in "\u200b\u200c\u200d\u2060\ufeff":
                return f"U+{ord(c):04X} is an invisible character; delete it or retype the name (copying from chat or documents often adds it)"
            return f"U+{ord(c):04X} looks like a space but is not one; use a plain space between arguments"
        if OPTIONS["strict_names"]:
            return "--strict-names: plain words allow only A-Z a-z 0-9 _ - . +; put other text in a display name (text component) or in quotes where allowed"
    return ""


def name_warn(ctx, pos, text):
    """Warn about full-width punctuation or spaces typed by a Chinese IME inside a name."""
    if not text or text.isascii():
        return
    m = FULLWIDTH_RE.search(text)
    if m:
        item = (pos + m.start(), "FULLWIDTH_CHAR", f"the name {text!r} contains the full-width character {m.group()!r} (U+{ord(m.group()):04X})", "it is probably a typo from a Chinese input method; commands use half-width , = : and quotes")
        ctx.warn(item[0], item[1], item[2], item[3])
        ctx.sticky.append(item)
        return
    bad = next((c for c in text if c in NAME_BREAKERS), None)
    if bad:
        item = (pos, "INVISIBLE_CHAR", f"the name {text!r} contains an invisible character (U+{ord(bad):04X})", "retype the name; copy-pasting from chat or documents can add zero-width characters")
        ctx.warn(item[0], item[1], item[2], item[3])
        ctx.sticky.append(item)


def parse_coord(r, allow_local=True, integer=False):
    start = r.i
    c = r.peek()
    if c == "^":
        if not allow_local:
            raise Fail(start, "local coordinates (^) are not allowed here")
        r.i += 1
        if r.peek() and r.peek() not in " ":
            text, _ = r.number_text()
            if text and not has_wild(text):
                try:
                    float(text)
                except ValueError:
                    raise Fail(start, f"invalid coordinate {'^' + text!r}")
        return "^"
    if c == "~":
        r.i += 1
        if r.peek() and r.peek() not in " ":
            text, _ = r.number_text()
            if text and not has_wild(text):
                try:
                    float(text)
                except ValueError:
                    raise Fail(start, f"invalid coordinate {'~' + text!r}")
        return "~"
    text, _ = r.number_text()
    if not text:
        raise Fail(start, f"expected a coordinate, found {r.word()!r}" if r.word() else "expected a coordinate")
    if has_wild(text):
        return "n"
    try:
        v = float(text)
    except ValueError:
        raise Fail(start, f"invalid coordinate {text!r}")
    if integer and not re.fullmatch(r"-?\d+", text):
        raise Fail(start, f"block positions need whole numbers, found {text!r}", "use an integer like 10 or a relative ~0.5")
    return "n"


def parse_coords(r, n, allow_local=True, integer=False):
    start = r.i
    kinds = []
    for idx in range(n):
        if idx:
            if r.peek() != " ":
                raise Fail(r.i, f"expected {n} coordinates")
            r.i += 1
        kinds.append(parse_coord(r, allow_local, integer))
    if "^" in kinds and any(k != "^" for k in kinds):
        raise Fail(start, "cannot mix local (^) and world (~ or absolute) coordinates")
    return kinds


def parse_range(r, integer):
    start = r.i
    text = ""
    while r.i < len(r.s) and (r.s[r.i] in NUM_CHARS):
        text += r.s[r.i]
        r.i += 1
    if not text:
        raise Fail(start, "expected a value or range like 1, 1..5, ..5 or 3..")
    if has_wild(text):
        return
    if ".." in text:
        lo, _, hi = text.partition("..")
    else:
        lo = hi = text
    if not lo and not hi:
        raise Fail(start, f"invalid range {text!r}")

    def conv(x):
        if not x:
            return None
        try:
            return int(x) if integer else float(x)
        except ValueError:
            raise Fail(start, f"invalid {'integer ' if integer else ''}range value {x!r}")

    a, b = conv(lo), conv(hi)
    if a is not None and b is not None and a > b:
        raise Fail(start, f"range {text!r} has min greater than max", "write the smaller value first")
    return (a, b)


def parse_snbt(r, compound=False):
    start = r.i
    p = SnbtParser(r.s, r.i)
    try:
        v = p.value()
    except SnbtError as e:
        raise Fail(e.pos, f"invalid SNBT: {e.message}", code="SNBT")
    if compound and not isinstance(v, dict) and not isinstance(v, Wild):
        raise Fail(start, "expected an NBT compound {...}", code="SNBT")
    r.i = p.i
    return v


def schema_check(value, ty, ctx, pos, strict, label, snbt=True, code="SCHEMA"):
    sc = schema.Ctx(strict=strict, snbt=snbt)
    issues = schema.validate(value, ty, sc)
    for ref in sc.refs:
        ctx.refs.append((ref.registry, ref.id, ref.tag, pos))
    for iss in issues:
        sev = schema.severity(iss, sc)
        where = iss.where()
        msg = f"{label}{(' ' + where) if where else ''}: {iss.message}"
        if sev == "error":
            ctx.error(pos, iss.code or code, msg, iss.hint)
        else:
            ctx.warn(pos, iss.code or code, msg, iss.hint)


def check_registry(ctx, pos, registry, ident, what, strict=True):
    if has_wild(ident):
        return
    ns, path = data.split_id(ident)
    if ns != "minecraft":
        ctx.refs.append((registry, f"{ns}:{path}", False, pos))
        return
    reg = data.registry_sets().get(registry)
    if reg is None:
        return
    if path in reg:
        return
    if registry in schema.DATA_DRIVEN:
        if registry in ("function", "predicate", "item_modifier") or not reg:
            ctx.refs.append((registry, f"{ns}:{path}", False, pos))
            return
        sug = schema.suggest(path, list(reg))
        hint = schema.renamed_hint(registry, path) or (("did you mean " + ", ".join(sug)) if sug else "")
        ctx.warn(pos, "UNKNOWN_ID", f"'minecraft:{path}' is not a vanilla {what}; it works only if a data pack adds it", hint)
        return
    sug = schema.suggest(path, list(reg))
    msg = f"unknown {what} 'minecraft:{path}'"
    hint = schema.renamed_hint(registry, path) or (("did you mean " + ", ".join(sug)) if sug else f"run: pw id {registry} {path}")
    if strict:
        raise Fail(pos, msg, hint, "UNKNOWN_ID")
    ctx.warn(pos, "UNKNOWN_ID", msg, hint)


def check_tag(ctx, pos, registry, ident):
    if has_wild(ident):
        return
    ns, path = data.split_id(ident)
    if ns != "minecraft":
        ctx.refs.append((registry, f"{ns}:{path}", True, pos))
        return
    known = data.has_tag(registry, ident)
    if known is False:
        ctx.refs.append((registry, f"{ns}:{path}", True, pos))
        sug = schema.suggest(path, list(data.tags().get(registry, {})))
        ctx.warn(pos, "UNKNOWN_TAG", f"#minecraft:{path} is not a vanilla {registry} tag", ("did you mean " + ", ".join("#minecraft:" + s for s in sug)) if sug else "unless your pack defines it")


def parse_selector(r, props, ctx):
    start = r.i
    amount = props.get("amount", "multiple")
    ptype = props.get("type", "entities")
    if r.peek() == "@":
        r.i += 1
        kind = r.peek()
        if kind not in "parsen" or not kind:
            raise Fail(start, f"unknown selector type '@{kind}'", "use @p @a @r @s @e or @n")
        r.i += 1
        opts = {}
        if r.peek() == "[":
            opts = parse_selector_options(r, ctx, kind)
        single = kind in "psn" or ("limit" in opts and opts["limit"] == 1) or (kind == "r" and "limit" not in opts)
        if kind == "r" and "limit" in opts and opts["limit"] != 1:
            single = False
        players_only = kind in "par" or opts.get("type") == "player" or kind == "s"
        if amount == "single" and not single:
            raise Fail(start, "only one entity is allowed here, but this selector can match more", "add limit=1 or use @p / @s / @n", "SELECTOR_SINGLE")
        if ptype == "players" and not players_only:
            raise Fail(start, "only players are allowed here, but this selector can match other entities", "use @a / @p / @r / @s, or add type=player", "SELECTOR_PLAYERS")
        ctx.args["_selectors"] = ctx.args.get("_selectors", ()) + ((kind, opts),)
        seq_add(ctx, ("sel", kind, any(k in opts for k in LIMITERS), start))
        return ("@" + kind, opts)
    if r.peek() == "\"":
        raise Fail(start, "player names are not quoted here")
    w = r.unquoted()
    if not w:
        c = r.peek()
        raise Fail(start, f"expected a selector, player name or UUID, found {c!r}", word_hint(c), "SELECTOR")
    if has_wild(w):
        return (w, {})
    if UUID_RE.match(w):
        return (w, {})
    if len(w) > 16:
        ctx.warn(start, "PLAYER_NAME", f"{w!r} is longer than 16 characters, so it cannot be a player name")
    return (w, {})


SELECTOR_KEYS = {"name", "distance", "level", "x", "y", "z", "dx", "dy", "dz", "x_rotation", "y_rotation", "limit", "sort", "gamemode", "team", "type", "tag", "nbt", "scores", "advancements", "predicate"}
NEGATABLE = {"name", "gamemode", "team", "type", "tag", "nbt", "predicate"}
REPEATABLE_NEG = {"name", "gamemode", "team", "type"}


def parse_selector_options(r, ctx, kind):
    r.i += 1
    opts = {}
    seen = {}
    r.skip_ws()
    if r.peek() == "]":
        r.i += 1
        return opts
    while True:
        r.skip_ws()
        kpos = r.i
        key = r.unquoted()
        if not key:
            raise Fail(kpos, f"expected a selector option, found {r.peek()!r}")
        if key not in SELECTOR_KEYS and not has_wild(key):
            sug = schema.suggest(key, list(SELECTOR_KEYS))
            raise Fail(kpos, f"unknown selector option {key!r}", ("did you mean " + ", ".join(sug)) if sug else "", "SELECTOR_OPTION")
        r.skip_ws()
        if r.peek() != "=":
            raise Fail(r.i, f"expected '=' after selector option {key!r}")
        r.i += 1
        r.skip_ws()
        neg = False
        if r.peek() == "!":
            if key not in NEGATABLE:
                raise Fail(r.i, f"selector option {key!r} cannot be negated with '!'")
            neg = True
            r.i += 1
            r.skip_ws()
        vpos = r.i
        opts["_any"] = True
        if key in seen and not (neg and seen[key]) and key not in ("tag", "nbt", "predicate"):
            if not (key in REPEATABLE_NEG and neg):
                raise Fail(kpos, f"selector option {key!r} is not applicable here (given twice)")
        seen[key] = neg
        if key == "name":
            first = r.peek()
            if OPTIONS["strict_names"] and first and first not in "\"'" and not first.isascii() and first not in NAME_BREAKERS:
                raise Fail(vpos, "non-ASCII names must be quoted (--strict-names)", "write name=\"...\"")
            v = r.string()
            if r.s[vpos] not in "\"'":
                name_warn(ctx, vpos, v)
            opts.setdefault("name", []).append((neg, v))
        elif key in ("distance", "x_rotation", "y_rotation"):
            rg = parse_range(r, False)
            if key == "distance" and rg and rg[0] is not None and rg[0] < 0:
                raise Fail(vpos, "distance cannot be negative")
            opts[key] = rg
        elif key == "level":
            rg = parse_range(r, True)
            if rg and rg[0] is not None and rg[0] < 0:
                raise Fail(vpos, "level cannot be negative")
            opts[key] = rg
        elif key in ("x", "y", "z", "dx", "dy", "dz"):
            parse_float(r, {})
            opts[key] = True
        elif key == "limit":
            v = parse_int(r, {"min": 1})
            if kind in "sn" and False:
                pass
            opts["limit"] = v
        elif key == "sort":
            w = r.unquoted()
            if w not in SORTS and not has_wild(w):
                raise Fail(vpos, f"unknown sort {w!r}", "use nearest, furthest, random or arbitrary")
            opts["sort"] = w
        elif key == "gamemode":
            w = r.unquoted()
            if w not in GAMEMODES and not has_wild(w):
                raise Fail(vpos, f"invalid game mode {w!r}", "use survival, creative, adventure or spectator")
        elif key in ("team", "tag"):
            if r.peek() in "\"'":
                v = r.quoted()
            else:
                v = r.unquoted()
                if r.peek() and r.peek() not in ",] " and not r.peek().isascii():
                    raise Fail(r.i, f"{key} names must be plain words (A-Z a-z 0-9 _ - . +)", word_hint(r.peek()))
                name_warn(ctx, vpos, v)
            if v:
                ctx.use("tag" if key == "tag" else "team", v, vpos)
            opts.setdefault(key, []).append((neg, v))
        elif key == "type":
            if kind in "par" and not has_wild(r.word()):
                raise Fail(kpos, f"option 'type' is not applicable to @{kind} (it only selects players)", "use @e[type=...] instead")
            if r.peek() == "#":
                r.i += 1
                t = r.rl()
                check_tag(ctx, vpos, "entity_type", t)
            else:
                t = r.rl()
                check_registry(ctx, vpos, "entity_type", t, "entity type")
                if not neg:
                    opts["type"] = data.strip_ns(t)
        elif key == "nbt":
            legacy_count_check(ctx, vpos, parse_snbt(r, compound=True), "selector nbt")
        elif key == "scores":
            parse_scores(r, ctx)
        elif key == "advancements":
            parse_advancements(r, ctx)
        elif key == "predicate":
            p = r.rl()
            ctx.refs.append(("predicate", p if ":" in p else "minecraft:" + p, False, vpos))
        r.skip_ws()
        c = r.peek()
        if c == ",":
            r.i += 1
            continue
        if c == "]":
            r.i += 1
            return opts
        raise Fail(r.i, "expected ',' or ']' in selector" if c else "unclosed selector: missing ']'")


def legacy_count_check(ctx, pos, value, label):
    """NBT that is matched or written as-is is not run through a schema, so catch the old item stack format here."""
    bad = legacy_stacks(value)
    if bad:
        more = f" (and {len(bad) - 1} more)" if len(bad) > 1 else ""
        where = "the value" if bad[0] == "<root>" else bad[0]
        ctx.error(pos, "LEGACY_ITEM_COUNT", f"{label}: {where} is an item stack in the pre-1.20.5 format with 'Count'{more}", "item stacks use lower-case count as an int since 1.20.5: {id:'minecraft:stone',count:1}; 'Count:1b' never matches and is ignored when written")


def parse_scores(r, ctx):
    if r.peek() != "{":
        raise Fail(r.i, "scores must look like scores={objective=1..}")
    r.i += 1
    r.skip_ws()
    if r.peek() == "}":
        r.i += 1
        return
    while True:
        r.skip_ws()
        pos = r.i
        obj = r.unquoted()
        if not obj:
            raise Fail(pos, "expected an objective name in scores", word_hint(r.peek()))
        name_warn(ctx, pos, obj)
        ctx.use("objective", obj, pos)
        r.skip_ws()
        if r.peek() != "=":
            raise Fail(r.i, "expected '=' in scores")
        r.i += 1
        r.skip_ws()
        parse_range(r, True)
        r.skip_ws()
        c = r.peek()
        if c == ",":
            r.i += 1
            continue
        if c == "}":
            r.i += 1
            return
        raise Fail(r.i, "expected ',' or '}' in scores")


def parse_advancements(r, ctx):
    if r.peek() != "{":
        raise Fail(r.i, "advancements must look like advancements={ns:id=true}")
    r.i += 1
    r.skip_ws()
    if r.peek() == "}":
        r.i += 1
        return
    while True:
        r.skip_ws()
        pos = r.i
        adv = r.rl()
        ctx.refs.append(("advancement", adv if ":" in adv else "minecraft:" + adv, False, pos))
        r.skip_ws()
        if r.peek() != "=":
            raise Fail(r.i, "expected '=' in advancements")
        r.i += 1
        r.skip_ws()
        if r.peek() == "{":
            r.i += 1
            while True:
                r.skip_ws()
                r.unquoted()
                r.skip_ws()
                if r.peek() != "=":
                    raise Fail(r.i, "expected '=' in advancement criteria")
                r.i += 1
                r.skip_ws()
                parse_bool(r)
                r.skip_ws()
                if r.peek() == ",":
                    r.i += 1
                    continue
                if r.peek() == "}":
                    r.i += 1
                    break
                raise Fail(r.i, "expected ',' or '}'")
        else:
            parse_bool(r)
        r.skip_ws()
        c = r.peek()
        if c == ",":
            r.i += 1
            continue
        if c == "}":
            r.i += 1
            return
        raise Fail(r.i, "expected ',' or '}' in advancements")


def parse_block(r, ctx, allow_tag, strict_props=True):
    start = r.i
    is_tag = False
    if r.peek() == "#":
        if not allow_tag:
            raise Fail(start, "block tags are not allowed here", "use a block id")
        is_tag = True
        r.i += 1
    bid = r.rl()
    block = None
    if is_tag:
        check_tag(ctx, start, "block", bid)
    else:
        if not has_wild(bid):
            check_registry(ctx, start, "block", bid, "block")
            ns, path = data.split_id(bid)
            if ns == "minecraft":
                block = path
    if r.peek() == "[":
        r.i += 1
        seen = set()
        r.skip_ws()
        if r.peek() == "]":
            r.i += 1
        else:
            while True:
                r.skip_ws()
                ppos = r.i
                name = r.string()
                r.skip_ws()
                if r.peek() != "=":
                    raise Fail(r.i, f"expected '=' after block property {name!r}")
                r.i += 1
                r.skip_ws()
                vpos = r.i
                val = r.string()
                if name in seen:
                    raise Fail(ppos, f"block property {name!r} is given twice")
                seen.add(name)
                if block and not has_wild(name + val):
                    info = data.blocks().get(block)
                    if info is not None:
                        props = info["p"]
                        if name not in props:
                            sug = schema.suggest(name, list(props))
                            raise Fail(ppos, f"block {block} has no property {name!r}", ("did you mean " + ", ".join(sug)) if sug else ("properties: " + ", ".join(props) if props else "this block has no properties"), "BLOCK_STATE")
                        if val not in props[name]:
                            raise Fail(vpos, f"{val!r} is not a valid value for {block}[{name}]", "allowed: " + ", ".join(props[name]), "BLOCK_STATE")
                r.skip_ws()
                c = r.peek()
                if c == ",":
                    r.i += 1
                    continue
                if c == "]":
                    r.i += 1
                    break
                raise Fail(r.i, "expected ',' or ']' in block properties")
    nbt = None
    if r.peek() == "{":
        npos = r.i
        nbt = parse_snbt(r, compound=True)
        if block:
            for reg in ("minecraft:block", "minecraft:block_entity"):
                if block in schema.dispatchers().get(reg, {}):
                    schema_check(nbt, {"k": "dispatch", "reg": reg, "keys": [block]}, ctx, npos, False, f"block entity data of {block}")
                    break
    return block, nbt


COMPONENT = {"k": "dispatch", "reg": "minecraft:data_component"}


def parse_components(r, ctx, item, predicate=False):
    r.i += 1
    seen = set()
    r.skip_ws()
    if r.peek() == "]":
        r.i += 1
        return
    while True:
        r.skip_ws()
        cpos = r.i
        neg = False
        if r.peek() == "!":
            neg = True
            r.i += 1
        name = r.rl()
        short = data.strip_ns(name)
        if not has_wild(name):
            known = short in data.registry_sets().get("data_component_type", ())
            pred_known = short in data.registry_sets().get("data_component_predicate_type", ())
            if not known and not (predicate and pred_known) and name.startswith("minecraft:") or (":" not in name and not known and not (predicate and pred_known)):
                if not (predicate and short == "count"):
                    sug = schema.suggest(short, list(data.registry_sets().get("data_component_type", ())))
                    raise Fail(cpos, f"unknown item component {name!r}", ("did you mean " + ", ".join(sug)) if sug else schema.LEGACY_HINTS.get(name, "run: pw id component"), "UNKNOWN_COMPONENT")
            if short in seen and not predicate:
                raise Fail(cpos, f"component {name!r} is given twice")
            seen.add(short)
        r.skip_ws()
        op = r.peek()
        if predicate and op in ("=", "~"):
            r.i += 1
            r.skip_ws()
            vpos = r.i
            val = parse_snbt(r)
            if short == "count" and not has_wild(name):
                ty = {"k": "num", "t": "int"} if op == "=" else {"k": "ref", "path": "::java::data::util::MinMaxBounds", "args": [{"k": "num", "t": "int"}]}
                if "::java::data::util::MinMaxBounds" in schema.types():
                    schema_check(val, ty, ctx, vpos, True, "count test")
            elif op == "=":
                schema_check(val, dict(COMPONENT, keys=[short]), ctx, vpos, True, f"component {short}")
            else:
                ty = {"k": "dispatch", "reg": "minecraft:data_component_predicate", "keys": [short]}
                if short in schema.dispatchers().get("minecraft:data_component_predicate", {}):
                    schema_check(val, ty, ctx, vpos, True, f"predicate {short}")
        elif not predicate and op == "=":
            if neg:
                raise Fail(cpos, "a removed component (!name) cannot have a value")
            r.i += 1
            r.skip_ws()
            vpos = r.i
            val = parse_snbt(r)
            schema_check(val, dict(COMPONENT, keys=[short]), ctx, vpos, True, f"component {short}")
            if short == "custom_data" and isinstance(val, dict):
                pass
        elif not predicate and not neg:
            raise Fail(r.i, f"expected '=' after component {name!r}", "write name=value, or !name to remove a default component")
        r.skip_ws()
        c = r.peek()
        if c == "," or (predicate and c == "|"):
            r.i += 1
            continue
        if c == "]":
            r.i += 1
            return
        raise Fail(r.i, "expected ',' or ']' in item components" if c else "unclosed component list: missing ']'")


def parse_item_stack(r, ctx):
    start = r.i
    iid = r.rl()
    item = None
    if not has_wild(iid):
        check_registry(ctx, start, "item", iid, "item")
        ns, item = data.split_id(iid)
        if ns != "minecraft":
            item = None
        if item == "air":
            seq = ctx.args.get("_seq", ())
            if not (ctx.args.get("_cmd") == "item" and seq and seq[-1] == ("lit", "with")):
                ctx.warn(start, "AIR_ITEM", "air is not a real item stack", "to empty a slot use: item replace entity @s <slot> with minecraft:air")
    if r.peek() == "[":
        parse_components(r, ctx, item)
    if r.peek() == "{":
        raise Fail(r.i, "item NBT in curly braces was removed in 1.20.5", "use components in square brackets, e.g. diamond_sword[custom_name='x']", "LEGACY_ITEM_NBT")
    return item


def parse_item_predicate(r, ctx):
    start = r.i
    if r.peek() == "*":
        r.i += 1
    elif r.peek() == "#":
        r.i += 1
        t = r.rl()
        check_tag(ctx, start, "item", t)
    else:
        iid = r.rl()
        check_registry(ctx, start, "item", iid, "item")
    if r.peek() == "[":
        parse_components(r, ctx, None, predicate=True)
    if r.peek() == "{":
        raise Fail(r.i, "item NBT in curly braces was removed in 1.20.5", "match components instead, e.g. *[custom_data~{key:1b}]", "LEGACY_ITEM_NBT")


def parse_particle(r, ctx):
    start = r.i
    pid = r.rl()
    if has_wild(pid):
        if r.peek() == "{":
            parse_snbt(r, compound=True)
        return
    check_registry(ctx, start, "particle_type", pid, "particle")
    short = data.strip_ns(pid)
    table = schema.dispatchers().get("minecraft:particle", {})
    if r.peek() == "{":
        opos = r.i
        val = parse_snbt(r, compound=True)
        if short in table:
            schema_check(val, {"k": "dispatch", "reg": "minecraft:particle", "keys": [short]}, ctx, opos, True, f"particle {short} options")
        else:
            ctx.warn(opos, "PARTICLE_OPTIONS", f"particle {short} takes no options; they are ignored")
    elif short in table:
        ty, env = schema.resolve({"k": "dispatch", "reg": "minecraft:particle", "keys": [short]}, {})
        if ty.get("k") == "struct":
            static, _, _ = schema.struct_shape(ty, env, {}, schema.Scope({}))
            req = [k for k, (f, _, weak) in static.items() if not f.get("opt") and not weak]
            if req:
                raise Fail(start, f"particle {short} needs options: {short}{{{', '.join(k + ':...' for k in req)}}}", f"run: pw schema particle {short}", "PARTICLE_OPTIONS")


def parse_nbt_path(r):
    start = r.i
    first = True
    while True:
        c = r.peek()
        if c == "{":
            parse_snbt(r, compound=True)
        elif c == "[":
            r.i += 1
            if r.peek() == "]":
                r.i += 1
            elif r.peek() == "{":
                parse_snbt(r, compound=True)
                if r.peek() != "]":
                    raise Fail(r.i, "expected ']' in NBT path")
                r.i += 1
            else:
                text, p = r.number_text()
                if not text:
                    raise Fail(p, "expected an index, [] or [{...}] in NBT path")
                if not has_wild(text) and not re.fullmatch(r"-?\d+", text):
                    raise Fail(p, f"invalid list index {text!r}")
                if r.peek() != "]":
                    raise Fail(r.i, "expected ']' in NBT path")
                r.i += 1
        elif c in "\"'":
            r.quoted()
        elif not first and c == ".":
            r.i += 1
            nc = r.peek()
            if not nc or nc in " .[]{}":
                raise Fail(r.i, "expected a name after '.' in NBT path")
            if nc in "\"'":
                r.quoted()
            else:
                while r.peek() and r.peek() not in " .[]{}\"'":
                    r.i += 1
        elif first and c and c not in " ":
            while r.peek() and r.peek() not in " .[]{}\"'":
                r.i += 1
        else:
            break
        first = False
        if not r.peek() or r.peek() == " ":
            break
    if r.i == start:
        raise Fail(start, "expected an NBT path")


TEXT = {"k": "ref", "path": "::java::util::text::Text"}


def parse_component(r, ctx):
    start = r.i
    val = parse_snbt(r)
    schema_check(val, TEXT, ctx, start, True, "text component", code="TEXT")
    scan_text(val, ctx, start)
    return val


def scan_text(val, ctx, pos, depth=0):
    if depth > 40:
        return
    if isinstance(val, dict):
        ce = val.get("click_event")
        if isinstance(ce, dict) and isinstance(ce.get("command"), str) and data.strip_ns(str(ce.get("action", ""))) in ("run_command", "suggest_command"):
            cmd = ce["command"]
            if cmd.startswith("/"):
                cmd = cmd[1:]
            if data.strip_ns(str(ce.get("action"))) == "run_command" and cmd and WILD not in cmd:
                ctx.args["_nested_commands"] = ctx.args.get("_nested_commands", ()) + ((cmd, pos),)
        sc = val.get("score")
        if isinstance(sc, dict) and isinstance(sc.get("objective"), str):
            ctx.use("objective", sc["objective"], pos)
        for v in val.values():
            scan_text(v, ctx, pos, depth + 1)
    elif isinstance(val, list):
        for v in val:
            scan_text(v, ctx, pos, depth + 1)


def parse_style(r, ctx):
    start = r.i
    val = parse_snbt(r, compound=True)
    hits = schema.lookup_type("TextStyle") or schema.lookup_type("Style")
    if hits:
        schema_check(val, {"k": "ref", "path": hits[0][0]}, ctx, start, True, "style")


def parse_inline_or_id(r, ctx, registry, dir_key):
    start = r.i
    if r.peek() in "{[":
        val = parse_snbt(r)
        schema_check(val, {"k": "dispatch", "reg": "minecraft:resource", "keys": [dir_key]}, ctx, start, True, f"inline {dir_key}")
        return None
    rid = r.rl()
    full = rid if ":" in rid else "minecraft:" + rid
    if not has_wild(rid):
        ns, path = data.split_id(rid)
        if ns == "minecraft" and registry in data.registry_sets() and path in data.registry_sets()[registry]:
            return full
        ctx.refs.append((registry, full, False, start))
    return full


def parse_objective_criteria(r, ctx):
    start = r.i
    text = ""
    while r.peek() and r.peek() != " ":
        text += r.peek()
        r.i += 1
    if has_wild(text):
        return
    if text in SIMPLE_CRITERIA:
        return
    m = re.fullmatch(r"(teamkill|killedByTeam)\.([a-z_]+)", text)
    if m:
        if m.group(2) not in COLORS:
            raise Fail(start, f"unknown team color {m.group(2)!r}", "colors: " + ", ".join(COLORS))
        return
    m = re.fullmatch(r"(?:minecraft\.)?([a-z_]+):(?:minecraft\.)?([a-z0-9_./-]+)", text)
    if m:
        stype, sid = m.group(1), m.group(2)
        if stype not in STAT_TYPES:
            raise Fail(start, f"unknown statistic type {stype!r}", "use one of: " + ", ".join("minecraft." + s for s in STAT_TYPES), "CRITERIA")
        reg = STAT_TYPES[stype]
        if sid not in data.registry_sets().get(reg, ()):
            sug = schema.suggest(sid, list(data.registry_sets().get(reg, ())))
            raise Fail(start, f"unknown {reg} {sid!r} in criterion {text!r}", ("did you mean " + ", ".join(sug)) if sug else "", "CRITERIA")
        if not text.startswith("minecraft."):
            ctx.warn(start, "CRITERIA", f"write the criterion as minecraft.{stype}:minecraft.{sid}")
        return
    sug = schema.suggest(text, SIMPLE_CRITERIA)
    raise Fail(start, f"unknown scoreboard criterion {text!r}", ("did you mean " + ", ".join(sug)) if sug else "e.g. dummy, trigger, minecraft.used:minecraft.carrot_on_a_stick", "CRITERIA")


def parse_time(r, props):
    start = r.i
    text, _ = r.number_text()
    if not text:
        raise Fail(start, "expected a time like 20, 1s or 2d")
    if has_wild(text):
        if r.peek() in ("d", "s", "t"):
            r.i += 1
        return
    try:
        v = float(text)
    except ValueError:
        raise Fail(start, f"invalid time {text!r}")
    unit = r.peek()
    mult = 1
    if unit in ("d", "s", "t"):
        r.i += 1
        mult = {"d": 24000, "s": 20, "t": 1}[unit]
    ticks = round(v * mult)
    if props.get("min") is not None and ticks < props["min"]:
        raise Fail(start, f"time must not be less than {props['min']} ticks")


def parse_hex_color(r):
    start = r.i
    w = r.unquoted()
    if has_wild(w):
        return
    if not re.fullmatch(r"[0-9a-fA-F]{6}", w):
        raise Fail(start, f"invalid hex color {w!r}", "use six hex digits like FF8800")


def parse_resource_selector(r):
    start = r.i
    while r.peek() and r.peek() != " ":
        r.i += 1
    if r.i == start:
        raise Fail(start, "expected a resource selector")


def parse_argument(parser, props, r, ctx, name, cmd):
    start = r.i
    p = parser.removeprefix("minecraft:").removeprefix("brigadier:")
    if p == "bool":
        return parse_bool(r)
    if p in ("integer", "long"):
        return parse_int(r, props)
    if p in ("float", "double"):
        return parse_float(r, props)
    if p == "string":
        return parse_string(r, props, ctx)
    if p == "entity":
        return parse_selector(r, props, ctx)
    if p == "game_profile":
        return parse_selector(r, {"amount": "multiple", "type": "players"}, ctx)
    if p == "score_holder":
        if r.peek() == "@":
            return parse_selector(r, {"amount": props.get("amount", "multiple"), "type": "entities"}, ctx)
        if r.peek() == "*":
            r.i += 1
            return "*"
        while r.peek() and r.peek() != " ":
            r.i += 1
        if r.i == start:
            raise Fail(start, "expected a score holder")
        holder = r.s[start : r.i]
        if not has_wild(holder):
            name_warn(ctx, start, holder)
        return holder
    if p in ("vec3", "block_pos"):
        kinds = parse_coords(r, 3, True, p == "block_pos")
        seq_add(ctx, ("pos", tuple(kinds), start))
        return kinds
    if p == "vec2":
        return parse_coords(r, 2, False, False)
    if p == "column_pos":
        return parse_coords(r, 2, False, True)
    if p == "rotation":
        return parse_coords(r, 2, False, False)
    if p == "angle":
        return parse_coord(r, False, False)
    if p == "block_state":
        return parse_block(r, ctx, False)
    if p == "block_predicate":
        return parse_block(r, ctx, True)
    if p == "item_stack":
        return parse_item_stack(r, ctx)
    if p == "item_predicate":
        return parse_item_predicate(r, ctx)
    if p == "particle":
        return parse_particle(r, ctx)
    if p == "nbt_compound_tag":
        return (start, parse_snbt(r, compound=True))
    if p == "nbt_tag":
        return (start, parse_snbt(r))
    if p == "nbt_path":
        return parse_nbt_path(r)
    if p == "component":
        return parse_component(r, ctx)
    if p == "style":
        return parse_style(r, ctx)
    if p == "message":
        r.i = len(r.s)
        return r.s[start:]
    if p == "objective":
        w = r.unquoted()
        if not w:
            raise Fail(start, f"expected an objective name, found {r.peek()!r}", word_hint(r.peek()) or "objective names are plain words without spaces", "OBJECTIVE_NAME")
        name_warn(ctx, start, w)
        ctx.use("objective", w, start)
        return w
    if p == "team":
        w = r.unquoted()
        if not w:
            raise Fail(start, f"expected a team name, found {r.peek()!r}", word_hint(r.peek()) or "team names are plain words", "TEAM_NAME")
        name_warn(ctx, start, w)
        ctx.use("team", w, start)
        return w
    if p == "objective_criteria":
        return parse_objective_criteria(r, ctx)
    if p == "scoreboard_slot":
        w = r.unquoted()
        if has_wild(w):
            return w
        if w in ("list", "sidebar", "below_name") or (w.startswith("sidebar.team.") and w[13:] in COLORS):
            return w
        if w == "belowName":
            raise Fail(start, "belowName was renamed to below_name")
        raise Fail(start, f"unknown display slot {w!r}", "use list, sidebar, below_name or sidebar.team.<color>")
    if p == "operation":
        w = ""
        while r.peek() and r.peek() != " ":
            w += r.peek()
            r.i += 1
        if w not in OPERATIONS and not has_wild(w):
            raise Fail(start, f"unknown operation {w!r}", "use = += -= *= /= %= < > ><")
        return w
    if p == "swizzle":
        w = r.unquoted()
        if not has_wild(w) and (not re.fullmatch(r"[xyz]{1,3}", w) or len(set(w)) != len(w)):
            raise Fail(start, f"invalid swizzle {w!r}", "use a combination of x, y and z, each at most once")
        return w
    if p == "entity_anchor":
        w = r.unquoted()
        if w not in ("eyes", "feet") and not has_wild(w):
            raise Fail(start, f"invalid entity anchor {w!r}", "use eyes or feet")
        return w
    if p == "color":
        w = r.unquoted()
        if w not in COLORS + ["reset"] and not has_wild(w):
            raise Fail(start, f"unknown color {w!r}", "colors: " + ", ".join(COLORS) + ", reset")
        return w
    if p == "hex_color":
        return parse_hex_color(r)
    if p == "gamemode":
        w = r.unquoted()
        if w not in GAMEMODES and not has_wild(w):
            raise Fail(start, f"invalid game mode {w!r}", "use survival, creative, adventure or spectator")
        return w
    if p == "heightmap":
        w = r.unquoted()
        if w not in HEIGHTMAPS and not has_wild(w):
            raise Fail(start, f"invalid heightmap {w!r}", "use " + ", ".join(HEIGHTMAPS))
        return w
    if p == "template_mirror":
        w = r.unquoted()
        if w not in ("none", "front_back", "left_right") and not has_wild(w):
            raise Fail(start, f"invalid mirror {w!r}", "use none, front_back or left_right")
        return w
    if p == "template_rotation":
        w = r.unquoted()
        if w not in ("none", "clockwise_90", "180", "counterclockwise_90") and not has_wild(w):
            raise Fail(start, f"invalid rotation {w!r}", "use none, clockwise_90, 180 or counterclockwise_90")
        return w
    if p == "int_range":
        return parse_range(r, True)
    if p == "float_range":
        return parse_range(r, False)
    if p in ("item_slot", "item_slots"):
        while r.can() and (r.peek().isalnum() or r.peek() in "_.*" or r.peek() == WILD):
            r.i += 1
        w = r.s[start : r.i]
        if has_wild(w) or SLOT_RE.match(w) or (p == "item_slots" and SLOTS_RE.match(w)):
            return w
        if w == "horse.saddle":
            ctx.warn(start, "SLOT", "horse.saddle became the 'saddle' slot in 1.21.5", "use saddle")
            return w
        if not w or not SLOT_SHAPE.match(w):
            raise Fail(start, f"invalid slot {w!r}", "e.g. weapon.mainhand, armor.head, hotbar.0, container.5, inventory.0" + (", container.*, armor.*" if p == "item_slots" else ""), "SLOT")
        ctx.warn(start, "SLOT", f"{w!r} is not a known 1.21.8 slot name", "known: weapon(.mainhand/.offhand), armor.head/chest/legs/feet/body, saddle, hotbar.N, inventory.N, container.N, enderchest.N, horse.N, villager.N, player.cursor, player.crafting.N, contents" + ("; ranges end with .*" if p == "item_slots" else ""))
        return w
    if p == "uuid":
        w = r.unquoted()
        if not has_wild(w) and not UUID_RE.match(w):
            raise Fail(start, f"invalid UUID {w!r}")
        return w
    if p == "time":
        return parse_time(r, props)
    if p == "function":
        is_tag = r.peek() == "#"
        if is_tag:
            r.i += 1
        fid = r.rl()
        full = fid if ":" in fid else "minecraft:" + fid
        ctx.refs.append(("function", full, is_tag, start))
        if not has_wild(fid):
            seq_add(ctx, ("fn", full, is_tag))
        return full
    if p == "dimension":
        did = r.rl()
        ns, path = data.split_id(did)
        if not has_wild(did) and not (ns == "minecraft" and path in data.registry_sets().get("dimension", ())):
            ctx.refs.append(("dimension", f"{ns}:{path}", False, start))
        return did
    if p == "loot_table":
        return parse_inline_or_id(r, ctx, "loot_table", "loot_table")
    if p == "loot_predicate":
        return parse_inline_or_id(r, ctx, "predicate", "predicate")
    if p == "loot_modifier":
        return parse_inline_or_id(r, ctx, "item_modifier", "item_modifier")
    if p == "dialog":
        return parse_inline_or_id(r, ctx, "dialog", "dialog")
    if p in ("resource", "resource_key", "resource_or_tag", "resource_or_tag_key"):
        registry = str(props.get("registry", "")).removeprefix("minecraft:")
        if r.peek() == "#":
            if p not in ("resource_or_tag", "resource_or_tag_key"):
                raise Fail(start, "a tag is not allowed here")
            r.i += 1
            tid = r.rl()
            check_tag(ctx, start, registry, tid)
            return "#" + tid
        rid = r.rl()
        if p in ("resource",) or registry in ("entity_type", "mob_effect", "attribute"):
            check_registry(ctx, start, registry, rid, registry.replace("_", " ").replace("mob effect", "effect"))
        else:
            check_registry(ctx, start, registry, rid, registry, strict=False)
        return rid
    if p == "resource_location":
        rid = r.rl()
        return rid
    if p == "resource_selector":
        return parse_resource_selector(r)
    while r.peek() and r.peek() != " ":
        r.i += 1
    ctx.note(start, "ARGUMENT_UNCHECKED", f"argument type {parser} is not checked")
    return None
