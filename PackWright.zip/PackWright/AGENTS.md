# PackWright

This folder is a toolkit for Minecraft Java Edition 1.21.8 commands and data packs. For any Minecraft request, read `SKILL.md` in this folder first and work the way it describes.

Quick start:

1. `python3 tools/pw.py doctor`
2. `knowledge/INDEX.md` lists the knowledge files and when to read each.
3. Look up syntax, ids and fields with `pw usage`, `pw id`, `pw schema`, `pw vanilla`, `pw find` instead of relying on memory from other versions.
4. Write the pack outside this folder, check it with `pw check <dir>`, fix errors, weigh warnings, then `pw pack <dir>`.
5. `examples/storm-blade/` (multi-skill weapon) and `examples/storm-king/` (boss) are complete packs to learn from.
