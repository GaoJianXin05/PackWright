scoreboard players set #phase king.data 2
bossbar set king:hp color purple
title @a[distance=..48] title {text:"Phase II",color:"dark_purple",bold:true}
title @a[distance=..48] subtitle {text:"The storm rages",color:"gray"}
playsound minecraft:entity.ender_dragon.growl hostile @a[distance=..64] ~ ~ ~ 1 0.6
attribute @s minecraft:movement_speed base set 0.34
attribute @s minecraft:attack_damage base set 14
effect give @s minecraft:resistance 3 4 true
summon minecraft:lightning_bolt ~ ~ ~
function king:attack/minions
