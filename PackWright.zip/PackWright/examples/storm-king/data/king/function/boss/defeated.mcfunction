scoreboard players set #alive king.data 0
bossbar set king:hp visible false
execute if score #slain king.data matches 1 at @e[type=minecraft:marker,tag=king.arena,limit=1] run title @a[distance=..64] title {text:"Victory",color:"gold",bold:true}
execute if score #slain king.data matches 1 at @e[type=minecraft:marker,tag=king.arena,limit=1] run playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~ ~ 1 1
execute unless score #slain king.data matches 1 at @e[type=minecraft:marker,tag=king.arena,limit=1] run tellraw @a[distance=..64] {text:"The Storm King fell without a victor.",color:"gray"}
scoreboard players set #slain king.data 0
function king:boss/cleanup
