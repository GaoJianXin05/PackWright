execute unless entity @e[type=minecraft:wither_skeleton,tag=king.boss] if entity @e[type=minecraft:marker,tag=king.arena] run return run function king:boss/defeated
execute as @e[type=minecraft:wither_skeleton,tag=king.boss,limit=1] at @s run function king:boss/tick
