scoreboard players set #slain king.data 1
advancement revoke @s only king:events/slain
