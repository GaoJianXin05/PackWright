scoreboard players set #attack king.timer 0
execute store result score #pick king.data run random value 1..3
execute if score #pick king.data matches 1 run return run function king:attack/lightning
execute if score #pick king.data matches 2 run return run function king:attack/shockwave
execute if score #phase king.data matches 2 run return run function king:attack/minions
function king:attack/lightning
