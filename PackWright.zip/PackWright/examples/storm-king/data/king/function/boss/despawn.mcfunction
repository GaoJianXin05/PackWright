tellraw @a[distance=..64] {text:"Nobody was fighting the Storm King, so it left.",color:"gray"}
data merge entity @s {DeathLootTable:"king:empty"}
kill @s
scoreboard players set #alive king.data 0
bossbar set king:hp visible false
function king:boss/cleanup
