kill @e[type=minecraft:vex,tag=king.minion]
kill @e[type=minecraft:marker,tag=king.strike]
kill @e[type=minecraft:marker,tag=king.arena]
execute if score #weather king.data matches 0 run weather clear
execute if score #weather king.data matches 1 run weather rain
execute if score #weather king.data matches 2 run weather thunder
scoreboard players set #weather king.data -1
