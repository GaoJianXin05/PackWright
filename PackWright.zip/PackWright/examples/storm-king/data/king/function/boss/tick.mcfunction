execute store result bossbar king:hp value run data get entity @s Health
bossbar set king:hp players @a[distance=..48]
execute if score #phase king.data matches 1 store result score #hp king.data run data get entity @s Health
execute if score #phase king.data matches 1 if score #hp king.data matches ..200 run function king:boss/phase2
scoreboard players add #attack king.timer 1
execute if score #phase king.data matches 1 if score #attack king.timer matches 100.. run function king:boss/choose_attack
execute if score #phase king.data matches 2 if score #attack king.timer matches 60.. run function king:boss/choose_attack
execute unless entity @e[type=minecraft:marker,tag=king.arena,distance=..24] at @e[type=minecraft:marker,tag=king.arena,limit=1] run tp @s ~ ~ ~
scoreboard players add #idle king.timer 1
execute if entity @a[distance=..48,gamemode=!spectator,gamemode=!creative] run scoreboard players set #idle king.timer 0
execute if score #idle king.timer matches 600.. run return run function king:boss/despawn
particle minecraft:electric_spark ~ ~2 ~ 0.4 0.6 0.4 0.05 3
