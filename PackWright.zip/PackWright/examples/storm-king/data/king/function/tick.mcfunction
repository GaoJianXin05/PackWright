execute if score #alive king.data matches 1 run function king:boss/tick_global
execute as @e[type=minecraft:marker,tag=king.strike] at @s run function king:attack/strike_tick
