execute if score #alive king.data matches 1 run return run tellraw @s {text:"The Storm King is already awake.",color:"red"}
summon minecraft:marker ~ ~ ~ {Tags:["king.arena"]}
summon minecraft:wither_skeleton ~ ~ ~ {Tags:["king.boss"],CustomName:{text:"Storm King",color:"aqua",bold:true},PersistenceRequired:true,Health:400f,attributes:[{id:"minecraft:max_health",base:400d},{id:"minecraft:attack_damage",base:10d},{id:"minecraft:movement_speed",base:0.28d},{id:"minecraft:knockback_resistance",base:0.8d},{id:"minecraft:scale",base:1.6d},{id:"minecraft:follow_range",base:48d}],equipment:{mainhand:{id:"minecraft:trident",count:1},head:{id:"minecraft:lightning_rod",count:1}},drop_chances:{mainhand:0.0f,head:0.0f},DeathLootTable:"king:boss_drops"}
scoreboard players set #alive king.data 1
scoreboard players set #slain king.data 0
scoreboard players set #weather king.data 0
execute if predicate king:raining run scoreboard players set #weather king.data 1
execute if predicate king:thundering run scoreboard players set #weather king.data 2
execute if entity @s[gamemode=creative] run tellraw @s {text:"The Storm King ignores creative players. Switch to survival to fight it.",color:"yellow"}
scoreboard players set #phase king.data 1
scoreboard players set #attack king.timer 0
scoreboard players set #idle king.timer 0
bossbar set king:hp value 400
bossbar set king:hp color blue
bossbar set king:hp visible true
title @a[distance=..48] times 10 50 10
title @a[distance=..48] title {text:"Storm King",color:"aqua",bold:true}
title @a[distance=..48] subtitle {text:"has awakened",color:"gray"}
playsound minecraft:entity.wither.spawn hostile @a[distance=..64] ~ ~ ~ 1 0.8
weather thunder 6000
