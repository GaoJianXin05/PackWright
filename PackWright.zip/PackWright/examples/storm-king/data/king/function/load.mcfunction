scoreboard objectives add king.data dummy
scoreboard objectives add king.timer dummy
bossbar add king:hp {text:"Storm King",color:"aqua",bold:true}
bossbar set king:hp max 400
bossbar set king:hp style notched_10
execute unless score #alive king.data matches 1 run bossbar set king:hp visible false
