execute as @e[type=minecraft:wither_skeleton,tag=king.boss] run data merge entity @s {DeathLootTable:"king:empty"}
kill @e[type=minecraft:wither_skeleton,tag=king.boss]
function king:boss/cleanup
bossbar remove king:hp
scoreboard objectives remove king.data
scoreboard objectives remove king.timer
