playsound minecraft:entity.warden.sonic_boom hostile @a[distance=..32] ~ ~ ~ 1 0.6
particle minecraft:explosion ~ ~0.5 ~ 3 0.2 3 0 20
scoreboard players set #i king.data 0
execute rotated 0 0 run function king:fx/ring
execute as @a[distance=..7,gamemode=!spectator,gamemode=!creative] run function king:attack/shockwave_hit
