damage @s 8 minecraft:mob_attack by @e[type=minecraft:wither_skeleton,tag=king.boss,limit=1]
effect give @s minecraft:levitation 1 4 true
effect give @s minecraft:slowness 3 1
