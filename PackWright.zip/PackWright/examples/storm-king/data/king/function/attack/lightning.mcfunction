playsound minecraft:entity.evoker.prepare_attack hostile @a[distance=..48] ~ ~ ~ 1 0.7
execute as @a[distance=..32,gamemode=!spectator,gamemode=!creative] at @s run summon minecraft:marker ~ ~ ~ {Tags:["king.strike"]}
