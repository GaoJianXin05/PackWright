execute store result score #n king.data if entity @e[type=minecraft:vex,tag=king.minion]
execute if score #n king.data matches 4.. run return run function king:attack/lightning
playsound minecraft:entity.evoker.prepare_summon hostile @a[distance=..48] ~ ~ ~ 1 1
summon minecraft:vex ~1.5 ~2 ~ {Tags:["king.minion"],life_ticks:600,CustomName:{text:"Storm Wisp",color:"aqua"}}
summon minecraft:vex ~-1.5 ~2 ~ {Tags:["king.minion"],life_ticks:600,CustomName:{text:"Storm Wisp",color:"aqua"}}
particle minecraft:electric_spark ~ ~2 ~ 1.5 0.5 1.5 0.1 40
