summon minecraft:lightning_bolt ~ ~ ~
particle minecraft:explosion ~ ~0.5 ~ 0.5 0.2 0.5 0 3
kill @s
