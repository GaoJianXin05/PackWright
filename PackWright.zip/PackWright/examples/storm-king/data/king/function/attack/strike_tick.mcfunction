scoreboard players add @s king.timer 1
particle minecraft:dust{color:[0.4,0.8,1.0],scale:1.2} ~ ~0.1 ~ 1 0 1 0 8
execute if score @s king.timer matches 25.. run function king:attack/strike_hit
