scoreboard players add #i king.data 1
particle minecraft:cloud ^ ^0.3 ^6 0 0 0 0 1 force
particle minecraft:electric_spark ^ ^0.3 ^4 0 0 0 0 1 force
execute if score #i king.data matches ..35 rotated ~10 0 run function king:fx/ring
