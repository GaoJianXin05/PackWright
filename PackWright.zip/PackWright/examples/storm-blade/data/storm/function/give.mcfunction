loot give @s loot storm:items/blade
