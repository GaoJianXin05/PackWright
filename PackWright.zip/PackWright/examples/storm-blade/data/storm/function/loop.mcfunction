execute as @a unless score @s storm.msg matches 1.. if items entity @s weapon.mainhand *[custom_data~{storm:{id:"blade"}}] run function storm:ui/hud
schedule function storm:loop 5t replace
