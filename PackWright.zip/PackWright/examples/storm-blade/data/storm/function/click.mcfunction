scoreboard players reset @s storm.click
execute unless items entity @s weapon.mainhand *[custom_data~{storm:{id:"blade"}}] run return fail
execute if predicate storm:sneaking run return run function storm:skill/nova/try
function storm:skill/dash/try
