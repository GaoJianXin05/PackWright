execute as @a[scores={storm.click=1..}] at @s run function storm:click
scoreboard players remove @a[scores={storm.cd1=1..}] storm.cd1 1
scoreboard players remove @a[scores={storm.cd2=1..}] storm.cd2 1
scoreboard players remove @a[scores={storm.msg=1..}] storm.msg 1
