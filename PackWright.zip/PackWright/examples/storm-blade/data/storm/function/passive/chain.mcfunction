particle minecraft:electric_spark ~ ~1 ~ 0.3 0.5 0.3 0.1 20
execute as @e[type=!#storm:ignore,type=!minecraft:player,distance=0.5..6,limit=1,sort=nearest] at @s run function storm:passive/chain_hit
