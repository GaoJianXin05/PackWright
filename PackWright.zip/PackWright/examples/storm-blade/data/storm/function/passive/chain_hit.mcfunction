damage @s 5 minecraft:lightning_bolt
particle minecraft:electric_spark ~ ~1 ~ 0.3 0.6 0.3 0.2 25
playsound minecraft:entity.lightning_bolt.thunder hostile @a ~ ~ ~ 0.4 1.8
