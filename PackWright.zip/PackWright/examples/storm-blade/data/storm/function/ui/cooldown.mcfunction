$scoreboard players operation @s storm.tmp = @s $(objective)
scoreboard players operation @s storm.tmp += #19 storm.const
scoreboard players operation @s storm.tmp /= #20 storm.const
$title @s actionbar [{text:"$(name) ",color:"gray"},{score:{name:"@s",objective:"storm.tmp"},color:"red"},{text:"s",color:"gray"}]
scoreboard players set @s storm.msg 30
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
