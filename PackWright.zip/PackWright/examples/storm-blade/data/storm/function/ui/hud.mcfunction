scoreboard players operation @s storm.s1 = @s storm.cd1
scoreboard players operation @s storm.s1 += #19 storm.const
scoreboard players operation @s storm.s1 /= #20 storm.const
scoreboard players operation @s storm.s2 = @s storm.cd2
scoreboard players operation @s storm.s2 += #19 storm.const
scoreboard players operation @s storm.s2 /= #20 storm.const
title @s actionbar [{text:"Dash ",color:"aqua"},{score:{name:"@s",objective:"storm.s1"},color:"white"},{text:"s   ",color:"gray"},{text:"Nova ",color:"blue"},{score:{name:"@s",objective:"storm.s2"},color:"white"},{text:"s",color:"gray"}]
