scoreboard objectives remove storm.click
scoreboard objectives remove storm.cd1
scoreboard objectives remove storm.cd2
scoreboard objectives remove storm.s1
scoreboard objectives remove storm.s2
scoreboard objectives remove storm.tmp
scoreboard objectives remove storm.msg
scoreboard objectives remove storm.const
schedule clear storm:loop
