scoreboard players add #i storm.tmp 1
particle minecraft:dust{color:[0.6,0.9,1.0],scale:1.5} ^ ^0.2 ^6 0 0 0 0 1 force
execute if score #i storm.tmp matches ..71 rotated ~5 0 run function storm:fx/ring
