scoreboard players add #steps storm.tmp 1
execute unless block ^ ^ ^0.5 #storm:passable run return 0
execute unless block ^ ^1 ^0.5 #storm:passable run return 0
tp @s ^ ^ ^0.5
particle minecraft:electric_spark ~ ~1 ~ 0.1 0.3 0.1 0 3
execute at @s as @e[type=!#storm:ignore,type=!minecraft:player,tag=!storm.hit,distance=..1.6] run function storm:skill/dash/hit
execute if score #steps storm.tmp matches ..13 at @s rotated ~ 0 run function storm:skill/dash/step
