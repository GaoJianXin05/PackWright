execute if score @s storm.cd1 matches 1.. run return run function storm:ui/cooldown {objective:"storm.cd1",name:"Thunder Dash"}
scoreboard players set @s storm.cd1 60
tag @s add storm.caster
playsound minecraft:entity.breeze.wind_burst player @a ~ ~ ~ 1 1.2
particle minecraft:cloud ~ ~0.5 ~ 0.3 0.2 0.3 0.05 15
scoreboard players set #steps storm.tmp 0
execute rotated ~ 0 run function storm:skill/dash/step
execute at @s run particle minecraft:electric_spark ~ ~1 ~ 0.5 0.5 0.5 0.2 30
execute at @s run playsound minecraft:entity.lightning_bolt.impact player @a ~ ~ ~ 0.8 1.4
tag @e[tag=storm.hit] remove storm.hit
tag @s remove storm.caster
