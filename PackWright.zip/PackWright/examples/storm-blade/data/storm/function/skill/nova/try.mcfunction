execute if score @s storm.cd2 matches 1.. run return run function storm:ui/cooldown {objective:"storm.cd2",name:"Frost Nova"}
scoreboard players set @s storm.cd2 200
tag @s add storm.caster
playsound minecraft:block.glass.break player @a ~ ~ ~ 1 0.6
playsound minecraft:entity.player.hurt_freeze player @a ~ ~ ~ 1 0.8
particle minecraft:snowflake ~ ~1 ~ 3 0.5 3 0.05 150
scoreboard players set #i storm.tmp 0
execute rotated 0 0 run function storm:fx/ring
execute as @e[type=!#storm:ignore,type=!minecraft:player,distance=..6] run function storm:skill/nova/hit
tag @s remove storm.caster
