tag @s add storm.hit
damage @s 8 minecraft:lightning_bolt by @p[tag=storm.caster]
particle minecraft:flash ~ ~1 ~ 0 0 0 0 1
