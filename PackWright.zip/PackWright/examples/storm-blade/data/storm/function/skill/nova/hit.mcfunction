damage @s 4 minecraft:freeze by @p[tag=storm.caster]
effect give @s minecraft:slowness 5 3
data merge entity @s {TicksFrozen:300}
