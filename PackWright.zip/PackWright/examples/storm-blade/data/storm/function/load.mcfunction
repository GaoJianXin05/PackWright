scoreboard objectives add storm.click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add storm.cd1 dummy
scoreboard objectives add storm.cd2 dummy
scoreboard objectives add storm.s1 dummy
scoreboard objectives add storm.s2 dummy
scoreboard objectives add storm.tmp dummy
scoreboard objectives add storm.msg dummy
scoreboard objectives add storm.const dummy
scoreboard players set #19 storm.const 19
scoreboard players set #20 storm.const 20
schedule function storm:loop 5t replace
